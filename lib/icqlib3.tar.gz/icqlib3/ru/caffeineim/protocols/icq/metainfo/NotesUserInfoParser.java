/*    */ package ru.caffeineim.protocols.icq.metainfo;
/*    */ 
/*    */ import java.util.EventListener;
/*    */ import java.util.EventObject;
/*    */ import ru.caffeineim.protocols.icq.RawData;
/*    */ import ru.caffeineim.protocols.icq.exceptions.ConvertStringException;
/*    */ import ru.caffeineim.protocols.icq.integration.events.MetaNoteUserInfoEvent;
/*    */ import ru.caffeineim.protocols.icq.integration.listeners.MetaInfoListener;
/*    */ import ru.caffeineim.protocols.icq.tool.StringTools;
/*    */ 
/*    */ public class NotesUserInfoParser extends BaseMetaInfoParser
/*    */ {
/*    */   private String note;
/*    */ 
/*    */   protected EventObject getNewEvent()
/*    */   {
/* 36 */     return new MetaNoteUserInfoEvent(this);
/*    */   }
/*    */ 
/*    */   protected void sendMessage(EventListener listener, EventObject e) {
/* 40 */     ((MetaInfoListener)listener).onNotesUserInfo((MetaNoteUserInfoEvent)e);
/*    */   }
/*    */ 
/*    */   public void parse(byte[] data, int position) throws ConvertStringException {
/* 44 */     position += 3;
/*    */ 
/* 47 */     RawData rStrLen = new RawData(data, position, 2);
/* 48 */     rStrLen.invertIndianness();
/* 49 */     position += 2;
/*    */ 
/* 52 */     this.note = StringTools.byteArrayToString(data, position, rStrLen.getValue() - 1);
/*    */   }
/*    */ 
/*    */   public String getNote() {
/* 56 */     return this.note;
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.metainfo.NotesUserInfoParser
 * JD-Core Version:    0.6.0
 */