/*     */ package ru.caffeineim.protocols.icq.metainfo;
/*     */ 
/*     */ import java.util.EventListener;
/*     */ import java.util.EventObject;
/*     */ import ru.caffeineim.protocols.icq.RawData;
/*     */ import ru.caffeineim.protocols.icq.exceptions.ConvertStringException;
/*     */ import ru.caffeineim.protocols.icq.integration.events.MetaBasicUserInfoEvent;
/*     */ import ru.caffeineim.protocols.icq.integration.listeners.MetaInfoListener;
/*     */ import ru.caffeineim.protocols.icq.setting.enumerations.CountryEnum;
/*     */ import ru.caffeineim.protocols.icq.setting.enumerations.TimeZoneEnum;
/*     */ import ru.caffeineim.protocols.icq.tool.StringTools;
/*     */ 
/*     */ public class BasicUserInfoParser extends BaseMetaInfoParser
/*     */ {
/*     */   private String nickName;
/*     */   private String firstName;
/*     */   private String lastName;
/*     */   private String email;
/*     */   private String homeCity;
/*     */   private String homeState;
/*     */   private String homePhone;
/*     */   private String homeFax;
/*     */   private String homeAddress;
/*     */   private String cellPhone;
/*     */   private String zipCode;
/*     */   private int homeCountry;
/*     */   private byte timezone;
/*     */   private boolean authFlag;
/*     */   private boolean webawareFlag;
/*     */   private boolean directConnection;
/*     */   private boolean publishPrimaryEmail;
/*     */ 
/*     */   protected EventObject getNewEvent()
/*     */   {
/*  55 */     return new MetaBasicUserInfoEvent(this);
/*     */   }
/*     */ 
/*     */   protected void sendMessage(EventListener listener, EventObject e)
/*     */   {
/*  60 */     ((MetaInfoListener)listener).onBasicUserInfo((MetaBasicUserInfoEvent)e);
/*     */   }
/*     */ 
/*     */   public void parse(byte[] data, int position) throws ConvertStringException
/*     */   {
/*  65 */     position += 3;
/*     */ 
/*  68 */     RawData rStrLen = new RawData(data, position, 2);
/*  69 */     rStrLen.invertIndianness();
/*  70 */     position += 2;
/*     */ 
/*  73 */     this.nickName = StringTools.byteArrayToString(data, position, rStrLen.getValue() - 1);
/*  74 */     position += rStrLen.getValue();
/*     */ 
/*  77 */     rStrLen = new RawData(data, position, 2);
/*  78 */     rStrLen.invertIndianness();
/*  79 */     position += 2;
/*     */ 
/*  82 */     this.firstName = StringTools.byteArrayToString(data, position, rStrLen.getValue() - 1);
/*  83 */     position += rStrLen.getValue();
/*     */ 
/*  86 */     rStrLen = new RawData(data, position, 2);
/*  87 */     rStrLen.invertIndianness();
/*  88 */     position += 2;
/*     */ 
/*  91 */     this.lastName = StringTools.byteArrayToString(data, position, rStrLen.getValue() - 1);
/*  92 */     position += rStrLen.getValue();
/*     */ 
/*  95 */     rStrLen = new RawData(data, position, 2);
/*  96 */     rStrLen.invertIndianness();
/*  97 */     position += 2;
/*     */ 
/* 100 */     this.email = new RawData(data, position, rStrLen.getValue() - 1).getStringValue();
/* 101 */     position += rStrLen.getValue();
/*     */ 
/* 104 */     rStrLen = new RawData(data, position, 2);
/* 105 */     rStrLen.invertIndianness();
/* 106 */     position += 2;
/*     */ 
/* 109 */     this.homeCity = StringTools.byteArrayToString(data, position, rStrLen.getValue() - 1);
/* 110 */     position += rStrLen.getValue();
/*     */ 
/* 113 */     rStrLen = new RawData(data, position, 2);
/* 114 */     rStrLen.invertIndianness();
/* 115 */     position += 2;
/*     */ 
/* 118 */     this.homeState = StringTools.byteArrayToString(data, position, rStrLen.getValue() - 1);
/* 119 */     position += rStrLen.getValue();
/*     */ 
/* 122 */     rStrLen = new RawData(data, position, 2);
/* 123 */     rStrLen.invertIndianness();
/* 124 */     position += 2;
/*     */ 
/* 127 */     this.homePhone = new RawData(data, position, rStrLen.getValue() - 1).getStringValue();
/* 128 */     position += rStrLen.getValue();
/*     */ 
/* 131 */     rStrLen = new RawData(data, position, 2);
/* 132 */     rStrLen.invertIndianness();
/* 133 */     position += 2;
/*     */ 
/* 136 */     this.homeFax = new RawData(data, position, rStrLen.getValue() - 1).getStringValue();
/* 137 */     position += rStrLen.getValue();
/*     */ 
/* 140 */     rStrLen = new RawData(data, position, 2);
/* 141 */     rStrLen.invertIndianness();
/* 142 */     position += 2;
/*     */ 
/* 145 */     this.homeAddress = StringTools.byteArrayToString(data, position, rStrLen.getValue() - 1);
/* 146 */     position += rStrLen.getValue();
/*     */ 
/* 149 */     rStrLen = new RawData(data, position, 2);
/* 150 */     rStrLen.invertIndianness();
/* 151 */     position += 2;
/*     */ 
/* 154 */     this.cellPhone = new RawData(data, position, rStrLen.getValue() - 1).getStringValue();
/* 155 */     position += rStrLen.getValue();
/*     */ 
/* 158 */     rStrLen = new RawData(data, position, 2);
/* 159 */     rStrLen.invertIndianness();
/* 160 */     position += 2;
/*     */ 
/* 163 */     this.zipCode = new RawData(data, position, rStrLen.getValue() - 1).getStringValue();
/* 164 */     position += rStrLen.getValue();
/*     */ 
/* 167 */     RawData homeCountryRD = new RawData(data, position, 2);
/* 168 */     homeCountryRD.invertIndianness();
/* 169 */     this.homeCountry = homeCountryRD.getValue();
/* 170 */     position += 2;
/*     */ 
/* 173 */     this.timezone = (byte)new RawData(data, position, 1).getValue();
/* 174 */     position++;
/*     */ 
/* 177 */     RawData authdata = new RawData(data, position, 1);
/* 178 */     this.authFlag = (authdata.getValue() == 0);
/* 179 */     position++;
/*     */ 
/* 182 */     RawData webawaredata = new RawData(data, position, 1);
/* 183 */     this.webawareFlag = (webawaredata.getValue() == 0);
/* 184 */     position++;
/*     */ 
/* 187 */     RawData directdata = new RawData(data, position, 1);
/* 188 */     this.directConnection = (directdata.getValue() == 0);
/* 189 */     position++;
/*     */ 
/* 192 */     RawData publishemaildata = new RawData(data, position, 1);
/* 193 */     this.publishPrimaryEmail = (publishemaildata.getValue() == 0);
/* 194 */     position++;
/*     */ 
/* 197 */     if (position + 6 < data.length) {
/* 198 */       position++;
/* 199 */       this.zipCode = new RawData(data, position, 6).getStringValue();
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getNickName() {
/* 204 */     return this.nickName;
/*     */   }
/*     */ 
/*     */   public String getFirstName() {
/* 208 */     return this.firstName;
/*     */   }
/*     */ 
/*     */   public String getLastName() {
/* 212 */     return this.lastName;
/*     */   }
/*     */ 
/*     */   public String getEmail() {
/* 216 */     return this.email;
/*     */   }
/*     */ 
/*     */   public String getHomeCity() {
/* 220 */     return this.homeCity;
/*     */   }
/*     */ 
/*     */   public String getHomeState() {
/* 224 */     return this.homeState;
/*     */   }
/*     */ 
/*     */   public String getHomePhone() {
/* 228 */     return this.homePhone;
/*     */   }
/*     */ 
/*     */   public String getHomeFax() {
/* 232 */     return this.homeFax;
/*     */   }
/*     */ 
/*     */   public String getHomeAddress() {
/* 236 */     return this.homeAddress;
/*     */   }
/*     */ 
/*     */   public String getCellPhone() {
/* 240 */     return this.cellPhone;
/*     */   }
/*     */ 
/*     */   public String getZipCode() {
/* 244 */     return this.zipCode;
/*     */   }
/*     */ 
/*     */   public CountryEnum getHomeCountry() {
/* 248 */     return new CountryEnum(this.homeCountry);
/*     */   }
/*     */ 
/*     */   public TimeZoneEnum getTimeZone() {
/* 252 */     return new TimeZoneEnum(this.timezone);
/*     */   }
/*     */ 
/*     */   public boolean isAuthFlag() {
/* 256 */     return this.authFlag;
/*     */   }
/*     */ 
/*     */   public boolean isWebawareFlag() {
/* 260 */     return this.webawareFlag;
/*     */   }
/*     */ 
/*     */   public boolean isDirectConnection() {
/* 264 */     return this.directConnection;
/*     */   }
/*     */ 
/*     */   public boolean isPublishPrimaryEmail() {
/* 268 */     return this.publishPrimaryEmail;
/*     */   }
/*     */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.metainfo.BasicUserInfoParser
 * JD-Core Version:    0.6.0
 */