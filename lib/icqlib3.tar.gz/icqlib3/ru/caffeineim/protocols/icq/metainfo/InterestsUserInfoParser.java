/*    */ package ru.caffeineim.protocols.icq.metainfo;
/*    */ 
/*    */ import java.util.EventListener;
/*    */ import java.util.EventObject;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import ru.caffeineim.protocols.icq.RawData;
/*    */ import ru.caffeineim.protocols.icq.exceptions.ConvertStringException;
/*    */ import ru.caffeineim.protocols.icq.integration.events.MetaInterestsUserInfoEvent;
/*    */ import ru.caffeineim.protocols.icq.integration.listeners.MetaInfoListener;
/*    */ import ru.caffeineim.protocols.icq.setting.enumerations.InterestsEnum;
/*    */ import ru.caffeineim.protocols.icq.tool.StringTools;
/*    */ 
/*    */ public class InterestsUserInfoParser extends BaseMetaInfoParser
/*    */ {
/* 36 */   private Map interests = new HashMap();
/*    */ 
/*    */   protected EventObject getNewEvent() {
/* 39 */     return new MetaInterestsUserInfoEvent(this);
/*    */   }
/*    */ 
/*    */   protected void sendMessage(EventListener listener, EventObject e) {
/* 43 */     ((MetaInfoListener)listener).onInterestsUserInfo((MetaInterestsUserInfoEvent)e);
/*    */   }
/*    */ 
/*    */   public void parse(byte[] data, int position) throws ConvertStringException {
/* 47 */     position += 3;
/*    */ 
/* 49 */     int len = new RawData(data, position, 1).getValue();
/* 50 */     position++;
/*    */ 
/* 52 */     for (int i = 0; i < len; i++)
/*    */     {
/* 55 */       RawData rStrLen = new RawData(data, position, 2);
/* 56 */       rStrLen.invertIndianness();
/* 57 */       position += 2;
/* 58 */       int code = rStrLen.getValue();
/*    */ 
/* 61 */       rStrLen = new RawData(data, position, 2);
/* 62 */       rStrLen.invertIndianness();
/* 63 */       position += 2;
/*    */ 
/* 66 */       String interest = StringTools.byteArrayToString(data, position, rStrLen.getValue() - 1);
/* 67 */       position += rStrLen.getValue();
/*    */ 
/* 69 */       this.interests.put(new InterestsEnum(code), interest);
/*    */     }
/*    */   }
/*    */ 
/*    */   public Map getInterests() {
/* 74 */     return this.interests;
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.metainfo.InterestsUserInfoParser
 * JD-Core Version:    0.6.0
 */