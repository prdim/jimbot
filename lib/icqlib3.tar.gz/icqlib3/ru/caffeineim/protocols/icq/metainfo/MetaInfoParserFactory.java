/*    */ package ru.caffeineim.protocols.icq.metainfo;
/*    */ 
/*    */ public class MetaInfoParserFactory
/*    */ {
/*    */   public static IMetaInfoParser buildMetaInfoParser(int metaType, int metaSubType)
/*    */   {
/* 36 */     IMetaInfoParser parser = null;
/*    */ 
/* 38 */     switch (metaType) {
/*    */     case 65:
/* 40 */       parser = new OfflineMessageParser();
/* 41 */       break;
/*    */     case 66:
/* 44 */       parser = new ServerEndOfOflineMessageParser();
/* 45 */       break;
/*    */     case 2010:
/* 48 */       switch (metaSubType)
/*    */       {
/*    */       case 420:
/*    */       case 430:
/* 52 */         break;
/*    */       case 260:
/* 55 */         parser = new ShortUserInfoParser();
/* 56 */         break;
/*    */       case 200:
/* 59 */         parser = new BasicUserInfoParser();
/* 60 */         break;
/*    */       case 235:
/* 63 */         parser = new EmailUserInfoParser();
/* 64 */         break;
/*    */       case 210:
/* 67 */         parser = new WorkUserInfoParser();
/* 68 */         break;
/*    */       case 240:
/* 71 */         parser = new InterestsUserInfoParser();
/* 72 */         break;
/*    */       case 220:
/* 75 */         parser = new MoreUserInfoParser();
/* 76 */         break;
/*    */       case 230:
/* 79 */         parser = new NotesUserInfoParser();
/* 80 */         break;
/*    */       case 250:
/* 83 */         parser = new AffilationsUserInfoParser();
/* 84 */         break;
/*    */       case 170:
/* 87 */         parser = new MetaAckParser();
/*    */       }
/*    */ 
/*    */     }
/*    */ 
/* 92 */     return parser;
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.metainfo.MetaInfoParserFactory
 * JD-Core Version:    0.6.0
 */