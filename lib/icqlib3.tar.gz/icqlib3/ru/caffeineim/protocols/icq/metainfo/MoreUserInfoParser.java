/*     */ package ru.caffeineim.protocols.icq.metainfo;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.EventListener;
/*     */ import java.util.EventObject;
/*     */ import java.util.List;
/*     */ import ru.caffeineim.protocols.icq.RawData;
/*     */ import ru.caffeineim.protocols.icq.exceptions.ConvertStringException;
/*     */ import ru.caffeineim.protocols.icq.integration.events.MetaMoreUserInfoEvent;
/*     */ import ru.caffeineim.protocols.icq.integration.listeners.MetaInfoListener;
/*     */ import ru.caffeineim.protocols.icq.setting.enumerations.CountryEnum;
/*     */ import ru.caffeineim.protocols.icq.setting.enumerations.GenderEnum;
/*     */ import ru.caffeineim.protocols.icq.setting.enumerations.LanguagesEnum;
/*     */ import ru.caffeineim.protocols.icq.setting.enumerations.MaritalStatusEnum;
/*     */ import ru.caffeineim.protocols.icq.setting.enumerations.TimeZoneEnum;
/*     */ import ru.caffeineim.protocols.icq.tool.DateTools;
/*     */ import ru.caffeineim.protocols.icq.tool.StringTools;
/*     */ 
/*     */ public class MoreUserInfoParser extends BaseMetaInfoParser
/*     */ {
/*     */   private int age;
/*     */   private GenderEnum gender;
/*     */   private String homePage;
/*     */   private Date birth;
/*     */   private List languages;
/*     */   private String originalCity;
/*     */   private String originalState;
/*     */   private CountryEnum originalCountry;
/*     */   private TimeZoneEnum userTimeZone;
/*     */   private MaritalStatusEnum maritalStatus;
/*     */ 
/*     */   protected EventObject getNewEvent()
/*     */   {
/*  54 */     return new MetaMoreUserInfoEvent(this);
/*     */   }
/*     */ 
/*     */   protected void sendMessage(EventListener listener, EventObject e) {
/*  58 */     ((MetaInfoListener)listener).onMoreUserInfo((MetaMoreUserInfoEvent)e);
/*     */   }
/*     */ 
/*     */   public void parse(byte[] data, int position) throws ConvertStringException {
/*  62 */     position += 3;
/*     */ 
/*  65 */     RawData ageRD = new RawData(data, position, 2);
/*  66 */     ageRD.invertIndianness();
/*  67 */     this.age = ageRD.getValue();
/*  68 */     position += 2;
/*     */ 
/*  71 */     this.gender = new GenderEnum(new RawData(data, position, 1).getValue());
/*  72 */     position++;
/*     */ 
/*  75 */     RawData rStrLen = new RawData(data, position, 2);
/*  76 */     rStrLen.invertIndianness();
/*  77 */     position += 2;
/*     */ 
/*  80 */     this.homePage = new RawData(data, position, rStrLen.getValue() - 1).getStringValue();
/*  81 */     position += rStrLen.getValue();
/*     */ 
/*  84 */     RawData year = new RawData(data, position, 2);
/*  85 */     year.invertIndianness();
/*  86 */     position += 2;
/*     */ 
/*  89 */     RawData month = new RawData(data, position, 1);
/*  90 */     position++;
/*     */ 
/*  93 */     RawData day = new RawData(data, position, 1);
/*  94 */     position++;
/*     */ 
/*  96 */     this.birth = DateTools.makeDate(year.getValue(), month.getValue(), day.getValue(), 0, 0);
/*     */ 
/*  99 */     this.languages = new ArrayList();
/* 100 */     int lang = new RawData(data, position, 1).getValue();
/* 101 */     position++;
/* 102 */     this.languages.add(new LanguagesEnum(lang));
/*     */ 
/* 104 */     lang = new RawData(data, position, 1).getValue();
/* 105 */     position++;
/* 106 */     this.languages.add(new LanguagesEnum(lang));
/*     */ 
/* 108 */     lang = new RawData(data, position, 1).getValue();
/* 109 */     position++;
/* 110 */     this.languages.add(new LanguagesEnum(lang));
/*     */ 
/* 113 */     position += 2;
/*     */ 
/* 116 */     rStrLen = new RawData(data, position, 2);
/* 117 */     rStrLen.invertIndianness();
/* 118 */     position += 2;
/*     */ 
/* 121 */     this.originalCity = StringTools.byteArrayToString(data, position, rStrLen.getValue() - 1);
/* 122 */     position += rStrLen.getValue();
/*     */ 
/* 125 */     rStrLen = new RawData(data, position, 2);
/* 126 */     rStrLen.invertIndianness();
/* 127 */     position += 2;
/*     */ 
/* 130 */     this.originalState = StringTools.byteArrayToString(data, position, rStrLen.getValue() - 1);
/* 131 */     position += rStrLen.getValue();
/*     */ 
/* 134 */     RawData originalCountryRD = new RawData(data, position, 2);
/* 135 */     originalCountryRD.invertIndianness();
/* 136 */     this.originalCountry = new CountryEnum(originalCountryRD.getValue());
/* 137 */     position += 2;
/*     */ 
/* 140 */     RawData maritalStatusRD = new RawData(data, position, 2);
/* 141 */     maritalStatusRD.invertIndianness();
/* 142 */     this.maritalStatus = new MaritalStatusEnum(maritalStatusRD.getValue());
/* 143 */     position += 2;
/*     */ 
/* 146 */     this.userTimeZone = new TimeZoneEnum(new RawData(data, position, 1).getValue());
/*     */   }
/*     */ 
/*     */   public int getAge() {
/* 150 */     return this.age;
/*     */   }
/*     */ 
/*     */   public GenderEnum getGender() {
/* 154 */     return this.gender;
/*     */   }
/*     */ 
/*     */   public String getHomePage() {
/* 158 */     return this.homePage;
/*     */   }
/*     */ 
/*     */   public Date getBirth() {
/* 162 */     return this.birth;
/*     */   }
/*     */ 
/*     */   public List getLanguages() {
/* 166 */     return this.languages;
/*     */   }
/*     */ 
/*     */   public String getOriginalCity() {
/* 170 */     return this.originalCity;
/*     */   }
/*     */ 
/*     */   public String getOriginalState() {
/* 174 */     return this.originalState;
/*     */   }
/*     */ 
/*     */   public CountryEnum getOriginalCountry() {
/* 178 */     return this.originalCountry;
/*     */   }
/*     */ 
/*     */   public TimeZoneEnum getUserTimeZone() {
/* 182 */     return this.userTimeZone;
/*     */   }
/*     */ 
/*     */   public MaritalStatusEnum getMaritalStatus() {
/* 186 */     return this.maritalStatus;
/*     */   }
/*     */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.metainfo.MoreUserInfoParser
 * JD-Core Version:    0.6.0
 */