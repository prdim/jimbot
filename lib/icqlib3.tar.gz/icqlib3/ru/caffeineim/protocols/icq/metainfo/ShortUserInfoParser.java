/*     */ package ru.caffeineim.protocols.icq.metainfo;
/*     */ 
/*     */ import java.util.EventListener;
/*     */ import java.util.EventObject;
/*     */ import ru.caffeineim.protocols.icq.RawData;
/*     */ import ru.caffeineim.protocols.icq.exceptions.ConvertStringException;
/*     */ import ru.caffeineim.protocols.icq.integration.events.MetaShortUserInfoEvent;
/*     */ import ru.caffeineim.protocols.icq.integration.listeners.MetaInfoListener;
/*     */ import ru.caffeineim.protocols.icq.tool.StringTools;
/*     */ 
/*     */ public class ShortUserInfoParser extends BaseMetaInfoParser
/*     */ {
/*     */   private String nickName;
/*     */   private String firstName;
/*     */   private String lastName;
/*     */   private String email;
/*     */   private boolean authFlag;
/*     */ 
/*     */   protected EventObject getNewEvent()
/*     */   {
/*  40 */     return new MetaShortUserInfoEvent(this);
/*     */   }
/*     */ 
/*     */   protected void sendMessage(EventListener listener, EventObject e) {
/*  44 */     ((MetaInfoListener)listener).onShortUserInfo((MetaShortUserInfoEvent)e);
/*     */   }
/*     */ 
/*     */   public void parse(byte[] data, int position) throws ConvertStringException {
/*  48 */     position += 3;
/*     */ 
/*  51 */     RawData rStrLen = new RawData(data, position, 2);
/*  52 */     rStrLen.invertIndianness();
/*  53 */     position += 2;
/*     */ 
/*  56 */     this.nickName = StringTools.byteArrayToString(data, position, rStrLen.getValue() - 1);
/*  57 */     position += rStrLen.getValue();
/*     */ 
/*  60 */     rStrLen = new RawData(data, position, 2);
/*  61 */     rStrLen.invertIndianness();
/*  62 */     position += 2;
/*     */ 
/*  65 */     this.firstName = StringTools.byteArrayToString(data, position, rStrLen.getValue() - 1);
/*  66 */     position += rStrLen.getValue();
/*     */ 
/*  69 */     rStrLen = new RawData(data, position, 2);
/*  70 */     rStrLen.invertIndianness();
/*  71 */     position += 2;
/*     */ 
/*  74 */     this.lastName = StringTools.byteArrayToString(data, position, rStrLen.getValue() - 1);
/*  75 */     position += rStrLen.getValue();
/*     */ 
/*  78 */     rStrLen = new RawData(data, position, 2);
/*  79 */     rStrLen.invertIndianness();
/*  80 */     position += 2;
/*     */ 
/*  83 */     this.email = new RawData(data, position, rStrLen.getValue() - 1).getStringValue();
/*  84 */     position += rStrLen.getValue();
/*     */ 
/*  87 */     RawData authdata = new RawData(data, position, 1);
/*  88 */     this.authFlag = (authdata.getValue() == 0);
/*     */   }
/*     */ 
/*     */   public String getNickName() {
/*  92 */     return this.nickName;
/*     */   }
/*     */ 
/*     */   public String getFirstName() {
/*  96 */     return this.firstName;
/*     */   }
/*     */ 
/*     */   public String getLastName() {
/* 100 */     return this.lastName;
/*     */   }
/*     */ 
/*     */   public String getEmail() {
/* 104 */     return this.email;
/*     */   }
/*     */ 
/*     */   public boolean isAuthFlag() {
/* 108 */     return this.authFlag;
/*     */   }
/*     */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.metainfo.ShortUserInfoParser
 * JD-Core Version:    0.6.0
 */