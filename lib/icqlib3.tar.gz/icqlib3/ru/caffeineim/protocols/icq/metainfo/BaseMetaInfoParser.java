/*    */ package ru.caffeineim.protocols.icq.metainfo;
/*    */ 
/*    */ import java.util.EventListener;
/*    */ import java.util.EventObject;
/*    */ import java.util.List;
/*    */ import ru.caffeineim.protocols.icq.core.OscarConnection;
/*    */ 
/*    */ public abstract class BaseMetaInfoParser
/*    */   implements IMetaInfoParser
/*    */ {
/*    */   public void notifyEvent(OscarConnection connection)
/*    */   {
/* 32 */     EventObject e = getNewEvent();
/*    */ 
/* 34 */     for (int i = 0; i < getListenersList(connection).size(); i++) {
/* 35 */       EventListener l = (EventListener)getListenersList(connection).get(i);
/* 36 */       sendMessage(l, e);
/*    */     }
/*    */   }
/*    */ 
/*    */   public void execute(OscarConnection connection)
/*    */   {
/*    */   }
/*    */ 
/*    */   protected abstract EventObject getNewEvent();
/*    */ 
/*    */   protected abstract void sendMessage(EventListener paramEventListener, EventObject paramEventObject);
/*    */ 
/*    */   protected List getListenersList(OscarConnection connection)
/*    */   {
/* 59 */     return connection.getMetaInfoListeners();
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.metainfo.BaseMetaInfoParser
 * JD-Core Version:    0.6.0
 */