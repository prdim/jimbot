/*    */ package ru.caffeineim.protocols.icq.metainfo;
/*    */ 
/*    */ import ru.caffeineim.protocols.icq.core.OscarConnection;
/*    */ import ru.caffeineim.protocols.icq.exceptions.ConvertStringException;
/*    */ import ru.caffeineim.protocols.icq.packet.sent.meta.AckOfflineMessages;
/*    */ 
/*    */ public class ServerEndOfOflineMessageParser
/*    */   implements IMetaInfoParser
/*    */ {
/*    */   public void execute(OscarConnection connection)
/*    */   {
/* 29 */     connection.sendFlap(new AckOfflineMessages(connection.getUserId()));
/*    */   }
/*    */ 
/*    */   public void notifyEvent(OscarConnection connection)
/*    */   {
/*    */   }
/*    */ 
/*    */   public void parse(byte[] data, int position)
/*    */     throws ConvertStringException
/*    */   {
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.metainfo.ServerEndOfOflineMessageParser
 * JD-Core Version:    0.6.0
 */