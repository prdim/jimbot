/*    */ package ru.caffeineim.protocols.icq.metainfo;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.EventListener;
/*    */ import java.util.EventObject;
/*    */ import java.util.List;
/*    */ import ru.caffeineim.protocols.icq.RawData;
/*    */ import ru.caffeineim.protocols.icq.exceptions.ConvertStringException;
/*    */ import ru.caffeineim.protocols.icq.integration.events.MetaEmailUserInfoEvent;
/*    */ import ru.caffeineim.protocols.icq.integration.listeners.MetaInfoListener;
/*    */ 
/*    */ public class EmailUserInfoParser extends BaseMetaInfoParser
/*    */ {
/* 34 */   private List emails = new ArrayList();
/*    */ 
/*    */   protected EventObject getNewEvent() {
/* 37 */     return new MetaEmailUserInfoEvent(this);
/*    */   }
/*    */ 
/*    */   protected void sendMessage(EventListener listener, EventObject e)
/*    */   {
/* 42 */     ((MetaInfoListener)listener).onEmailUserInfo((MetaEmailUserInfoEvent)e);
/*    */   }
/*    */ 
/*    */   public void parse(byte[] data, int position) throws ConvertStringException
/*    */   {
/* 47 */     position += 3;
/*    */ 
/* 49 */     int len = new RawData(data, position, 1).getValue();
/* 50 */     position++;
/*    */ 
/* 52 */     for (int i = 0; i < len; i++)
/*    */     {
/* 54 */       position++;
/*    */ 
/* 57 */       RawData rStrLen = new RawData(data, position, 2);
/* 58 */       rStrLen.invertIndianness();
/* 59 */       position += 2;
/*    */ 
/* 62 */       String email = new RawData(data, position, rStrLen.getValue() - 1).getStringValue();
/* 63 */       position += rStrLen.getValue();
/*    */ 
/* 65 */       this.emails.add(email);
/*    */     }
/*    */   }
/*    */ 
/*    */   public List getEmails() {
/* 70 */     return this.emails;
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.metainfo.EmailUserInfoParser
 * JD-Core Version:    0.6.0
 */