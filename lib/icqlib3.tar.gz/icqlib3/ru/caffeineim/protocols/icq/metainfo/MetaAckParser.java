/*    */ package ru.caffeineim.protocols.icq.metainfo;
/*    */ 
/*    */ import java.util.EventListener;
/*    */ import java.util.EventObject;
/*    */ import java.util.List;
/*    */ import ru.caffeineim.protocols.icq.RawData;
/*    */ import ru.caffeineim.protocols.icq.core.OscarConnection;
/*    */ import ru.caffeineim.protocols.icq.exceptions.ConvertStringException;
/*    */ import ru.caffeineim.protocols.icq.integration.events.MetaAckEvent;
/*    */ import ru.caffeineim.protocols.icq.integration.listeners.MetaAckListener;
/*    */ 
/*    */ public class MetaAckParser extends BaseMetaInfoParser
/*    */ {
/*    */   private boolean isOk;
/*    */ 
/*    */   protected EventObject getNewEvent()
/*    */   {
/* 37 */     return new MetaAckEvent(this);
/*    */   }
/*    */ 
/*    */   protected void sendMessage(EventListener listener, EventObject e) {
/* 41 */     ((MetaAckListener)listener).onMetaAck((MetaAckEvent)e);
/*    */   }
/*    */ 
/*    */   public void parse(byte[] data, int position) throws ConvertStringException
/*    */   {
/* 46 */     position += 2;
/*    */ 
/* 49 */     int code = new RawData(data, position, 1).getValue();
/* 50 */     this.isOk = (code == 10);
/*    */   }
/*    */ 
/*    */   protected List getListenersList(OscarConnection connection) {
/* 54 */     return connection.getMetaAckListeners();
/*    */   }
/*    */ 
/*    */   public boolean isOk() {
/* 58 */     return this.isOk;
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.metainfo.MetaAckParser
 * JD-Core Version:    0.6.0
 */