/*     */ package ru.caffeineim.protocols.icq.metainfo;
/*     */ 
/*     */ import java.util.EventListener;
/*     */ import java.util.EventObject;
/*     */ import ru.caffeineim.protocols.icq.RawData;
/*     */ import ru.caffeineim.protocols.icq.exceptions.ConvertStringException;
/*     */ import ru.caffeineim.protocols.icq.integration.events.MetaWorkUserInfoEvent;
/*     */ import ru.caffeineim.protocols.icq.integration.listeners.MetaInfoListener;
/*     */ import ru.caffeineim.protocols.icq.setting.enumerations.CountryEnum;
/*     */ import ru.caffeineim.protocols.icq.setting.enumerations.OccupationEnum;
/*     */ import ru.caffeineim.protocols.icq.tool.StringTools;
/*     */ 
/*     */ public class WorkUserInfoParser extends BaseMetaInfoParser
/*     */ {
/*     */   private String workCity;
/*     */   private String workState;
/*     */   private String workPhone;
/*     */   private String workFax;
/*     */   private String workAddress;
/*     */   private String workZip;
/*     */   private int workCountry;
/*     */   private String workCompany;
/*     */   private String workDepartment;
/*     */   private String workPosition;
/*     */   private String workWebPage;
/*     */   private int workOccupationCode;
/*     */ 
/*     */   protected EventObject getNewEvent()
/*     */   {
/*  50 */     return new MetaWorkUserInfoEvent(this);
/*     */   }
/*     */ 
/*     */   protected void sendMessage(EventListener listener, EventObject e) {
/*  54 */     ((MetaInfoListener)listener).onWorkUserInfo((MetaWorkUserInfoEvent)e);
/*     */   }
/*     */ 
/*     */   public void parse(byte[] data, int position) throws ConvertStringException {
/*  58 */     position += 3;
/*     */ 
/*  61 */     RawData rStrLen = new RawData(data, position, 2);
/*  62 */     rStrLen.invertIndianness();
/*  63 */     position += 2;
/*     */ 
/*  66 */     this.workCity = StringTools.byteArrayToString(data, position, rStrLen.getValue() - 1);
/*  67 */     position += rStrLen.getValue();
/*     */ 
/*  70 */     rStrLen = new RawData(data, position, 2);
/*  71 */     rStrLen.invertIndianness();
/*  72 */     position += 2;
/*     */ 
/*  75 */     this.workState = StringTools.byteArrayToString(data, position, rStrLen.getValue() - 1);
/*  76 */     position += rStrLen.getValue();
/*     */ 
/*  79 */     rStrLen = new RawData(data, position, 2);
/*  80 */     rStrLen.invertIndianness();
/*  81 */     position += 2;
/*     */ 
/*  84 */     this.workPhone = StringTools.byteArrayToString(data, position, rStrLen.getValue() - 1);
/*  85 */     position += rStrLen.getValue();
/*     */ 
/*  88 */     rStrLen = new RawData(data, position, 2);
/*  89 */     rStrLen.invertIndianness();
/*  90 */     position += 2;
/*     */ 
/*  93 */     this.workFax = StringTools.byteArrayToString(data, position, rStrLen.getValue() - 1);
/*  94 */     position += rStrLen.getValue();
/*     */ 
/*  97 */     rStrLen = new RawData(data, position, 2);
/*  98 */     rStrLen.invertIndianness();
/*  99 */     position += 2;
/*     */ 
/* 102 */     this.workAddress = StringTools.byteArrayToString(data, position, rStrLen.getValue() - 1);
/* 103 */     position += rStrLen.getValue();
/*     */ 
/* 106 */     rStrLen = new RawData(data, position, 2);
/* 107 */     rStrLen.invertIndianness();
/* 108 */     position += 2;
/*     */ 
/* 111 */     this.workZip = new RawData(data, position, rStrLen.getValue() - 1).getStringValue();
/* 112 */     position += rStrLen.getValue();
/*     */ 
/* 115 */     RawData country = new RawData(data, position, 2);
/* 116 */     country.invertIndianness();
/* 117 */     position += 2;
/* 118 */     this.workCountry = country.getValue();
/*     */ 
/* 121 */     rStrLen = new RawData(data, position, 2);
/* 122 */     rStrLen.invertIndianness();
/* 123 */     position += 2;
/*     */ 
/* 126 */     this.workCompany = StringTools.byteArrayToString(data, position, rStrLen.getValue() - 1);
/* 127 */     position += rStrLen.getValue();
/*     */ 
/* 130 */     rStrLen = new RawData(data, position, 2);
/* 131 */     rStrLen.invertIndianness();
/* 132 */     position += 2;
/*     */ 
/* 135 */     this.workDepartment = StringTools.byteArrayToString(data, position, rStrLen.getValue() - 1);
/* 136 */     position += rStrLen.getValue();
/*     */ 
/* 139 */     rStrLen = new RawData(data, position, 2);
/* 140 */     rStrLen.invertIndianness();
/* 141 */     position += 2;
/*     */ 
/* 144 */     this.workPosition = StringTools.byteArrayToString(data, position, rStrLen.getValue() - 1);
/* 145 */     position += rStrLen.getValue();
/*     */ 
/* 148 */     RawData occup = new RawData(data, position, 2);
/* 149 */     occup.invertIndianness();
/* 150 */     position += 2;
/* 151 */     this.workOccupationCode = occup.getValue();
/*     */ 
/* 154 */     rStrLen = new RawData(data, position, 2);
/* 155 */     rStrLen.invertIndianness();
/* 156 */     position += 2;
/*     */ 
/* 159 */     this.workWebPage = StringTools.byteArrayToString(data, position, rStrLen.getValue() - 1);
/* 160 */     position += rStrLen.getValue();
/*     */ 
/* 163 */     if (position + 1 <= data.length) {
/* 164 */       position++;
/*     */     }
/*     */ 
/* 168 */     if (position + 6 < data.length) {
/* 169 */       position++;
/* 170 */       this.workZip = new RawData(data, position, 6).getStringValue();
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getWorkCity() {
/* 175 */     return this.workCity;
/*     */   }
/*     */ 
/*     */   public String getWorkState() {
/* 179 */     return this.workState;
/*     */   }
/*     */ 
/*     */   public String getWorkPhone() {
/* 183 */     return this.workPhone;
/*     */   }
/*     */ 
/*     */   public String getWorkFax() {
/* 187 */     return this.workFax;
/*     */   }
/*     */ 
/*     */   public String getWorkAddress() {
/* 191 */     return this.workAddress;
/*     */   }
/*     */ 
/*     */   public String getWorkZip() {
/* 195 */     return this.workZip;
/*     */   }
/*     */ 
/*     */   public String getWorkCompany() {
/* 199 */     return this.workCompany;
/*     */   }
/*     */ 
/*     */   public String getWorkDepartment() {
/* 203 */     return this.workDepartment;
/*     */   }
/*     */ 
/*     */   public String getWorkPosition() {
/* 207 */     return this.workPosition;
/*     */   }
/*     */ 
/*     */   public String getWorkWebPage() {
/* 211 */     return this.workWebPage;
/*     */   }
/*     */ 
/*     */   public OccupationEnum getWorkOccupation() {
/* 215 */     return new OccupationEnum(this.workOccupationCode);
/*     */   }
/*     */ 
/*     */   public CountryEnum getWorkCountry() {
/* 219 */     return new CountryEnum(this.workCountry);
/*     */   }
/*     */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.metainfo.WorkUserInfoParser
 * JD-Core Version:    0.6.0
 */