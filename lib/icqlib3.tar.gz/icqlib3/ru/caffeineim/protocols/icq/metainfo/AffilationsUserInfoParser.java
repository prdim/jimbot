/*     */ package ru.caffeineim.protocols.icq.metainfo;
/*     */ 
/*     */ import java.util.EventListener;
/*     */ import java.util.EventObject;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import ru.caffeineim.protocols.icq.RawData;
/*     */ import ru.caffeineim.protocols.icq.exceptions.ConvertStringException;
/*     */ import ru.caffeineim.protocols.icq.integration.events.MetaAffilationsUserInfoEvent;
/*     */ import ru.caffeineim.protocols.icq.integration.listeners.MetaInfoListener;
/*     */ import ru.caffeineim.protocols.icq.setting.enumerations.AffilationEnum;
/*     */ import ru.caffeineim.protocols.icq.setting.enumerations.PostBackgroundEnum;
/*     */ import ru.caffeineim.protocols.icq.tool.StringTools;
/*     */ 
/*     */ public class AffilationsUserInfoParser extends BaseMetaInfoParser
/*     */ {
/*  37 */   private Map postbackgrounds = new HashMap();
/*  38 */   private Map affilations = new HashMap();
/*     */ 
/*     */   protected EventObject getNewEvent() {
/*  41 */     return new MetaAffilationsUserInfoEvent(this);
/*     */   }
/*     */ 
/*     */   protected void sendMessage(EventListener listener, EventObject e) {
/*  45 */     ((MetaInfoListener)listener).onAffilationsUserInfo((MetaAffilationsUserInfoEvent)e);
/*     */   }
/*     */ 
/*     */   public void parse(byte[] data, int position) throws ConvertStringException {
/*  49 */     position += 3;
/*     */ 
/*  51 */     int len = new RawData(data, position, 1).getValue();
/*  52 */     position++;
/*     */ 
/*  54 */     for (int i = 0; i < len; i++)
/*     */     {
/*  57 */       RawData rStrLen = new RawData(data, position, 2);
/*  58 */       rStrLen.invertIndianness();
/*  59 */       position += 2;
/*  60 */       int code = rStrLen.getValue();
/*     */ 
/*  63 */       rStrLen = new RawData(data, position, 2);
/*  64 */       rStrLen.invertIndianness();
/*  65 */       position += 2;
/*     */ 
/*  68 */       String postbackground = StringTools.byteArrayToString(data, position, rStrLen.getValue() - 1);
/*  69 */       position += rStrLen.getValue();
/*     */ 
/*  71 */       this.postbackgrounds.put(new PostBackgroundEnum(code), postbackground);
/*     */     }
/*     */ 
/*  74 */     len = new RawData(data, position, 1).getValue();
/*  75 */     position++;
/*     */ 
/*  77 */     for (int i = 0; i < len; i++)
/*     */     {
/*  80 */       RawData rStrLen = new RawData(data, position, 2);
/*  81 */       rStrLen.invertIndianness();
/*  82 */       position += 2;
/*  83 */       int code = rStrLen.getValue();
/*     */ 
/*  86 */       rStrLen = new RawData(data, position, 2);
/*  87 */       rStrLen.invertIndianness();
/*  88 */       position += 2;
/*     */ 
/*  91 */       String affilation = StringTools.byteArrayToString(data, position, rStrLen.getValue() - 1);
/*  92 */       position += rStrLen.getValue();
/*     */ 
/*  94 */       this.affilations.put(new AffilationEnum(code), affilation);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Map getPostBackgrounds() {
/*  99 */     return this.postbackgrounds;
/*     */   }
/*     */ 
/*     */   public Map getAffilations() {
/* 103 */     return this.affilations;
/*     */   }
/*     */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.metainfo.AffilationsUserInfoParser
 * JD-Core Version:    0.6.0
 */