/*     */ package ru.caffeineim.protocols.icq.metainfo;
/*     */ 
/*     */ import java.util.Date;
/*     */ import java.util.EventListener;
/*     */ import java.util.EventObject;
/*     */ import java.util.List;
/*     */ import ru.caffeineim.protocols.icq.RawData;
/*     */ import ru.caffeineim.protocols.icq.core.OscarConnection;
/*     */ import ru.caffeineim.protocols.icq.exceptions.ConvertStringException;
/*     */ import ru.caffeineim.protocols.icq.integration.events.OfflineMessageEvent;
/*     */ import ru.caffeineim.protocols.icq.integration.listeners.MessagingListener;
/*     */ import ru.caffeineim.protocols.icq.setting.enumerations.MessageFlagsEnum;
/*     */ import ru.caffeineim.protocols.icq.setting.enumerations.MessageTypeEnum;
/*     */ import ru.caffeineim.protocols.icq.tool.DateTools;
/*     */ import ru.caffeineim.protocols.icq.tool.StringTools;
/*     */ 
/*     */ public class OfflineMessageParser extends BaseMetaInfoParser
/*     */ {
/*     */   private String senderUin;
/*     */   private Date sendDate;
/*     */   private String message;
/*     */   private int type;
/*     */   private int flag;
/*     */ 
/*     */   protected EventObject getNewEvent()
/*     */   {
/*  46 */     return new OfflineMessageEvent(this);
/*     */   }
/*     */ 
/*     */   protected void sendMessage(EventListener listener, EventObject e) {
/*  50 */     ((MessagingListener)listener).onOfflineMessage((OfflineMessageEvent)e);
/*     */   }
/*     */ 
/*     */   public void parse(byte[] data, int position) throws ConvertStringException
/*     */   {
/*  55 */     RawData uin = new RawData(data, position, 4);
/*  56 */     uin.invertIndianness();
/*  57 */     this.senderUin = uin.toStringValue();
/*  58 */     position += 4;
/*     */ 
/*  61 */     RawData year = new RawData(data, position, 2);
/*  62 */     year.invertIndianness();
/*  63 */     position += 2;
/*     */ 
/*  66 */     RawData month = new RawData(data, position, 1);
/*  67 */     position++;
/*     */ 
/*  70 */     RawData day = new RawData(data, position, 1);
/*  71 */     position++;
/*     */ 
/*  74 */     RawData hour = new RawData(data, position, 1);
/*  75 */     position++;
/*     */ 
/*  78 */     RawData minute = new RawData(data, position, 1);
/*  79 */     position++;
/*  80 */     this.sendDate = DateTools.makeDate(year.getValue(), month.getValue(), day.getValue(), hour.getValue(), minute.getValue());
/*     */ 
/*  83 */     this.type = new RawData(data, position, 1).getValue();
/*  84 */     position++;
/*     */ 
/*  87 */     this.flag = new RawData(data, position, 1).getValue();
/*  88 */     position++;
/*     */ 
/*  91 */     RawData msgLen = new RawData(data, position, 2);
/*  92 */     msgLen.invertIndianness();
/*  93 */     position += 2;
/*     */ 
/*  96 */     this.message = StringTools.byteArrayToString(data, position, msgLen.getValue() - 1);
/*     */   }
/*     */ 
/*     */   protected List getListenersList(OscarConnection connection) {
/* 100 */     return connection.getMessagingListeners();
/*     */   }
/*     */ 
/*     */   public String getSenderUin() {
/* 104 */     return this.senderUin;
/*     */   }
/*     */ 
/*     */   public Date getSendDate() {
/* 108 */     return this.sendDate;
/*     */   }
/*     */ 
/*     */   public String getMessage() {
/* 112 */     return this.message;
/*     */   }
/*     */ 
/*     */   public MessageTypeEnum getMessageType() {
/* 116 */     return new MessageTypeEnum(this.type);
/*     */   }
/*     */ 
/*     */   public MessageFlagsEnum getMessageFlag() {
/* 120 */     return new MessageFlagsEnum(this.flag);
/*     */   }
/*     */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.metainfo.OfflineMessageParser
 * JD-Core Version:    0.6.0
 */