package ru.caffeineim.protocols.icq.metainfo;

import ru.caffeineim.protocols.icq.core.OscarConnection;
import ru.caffeineim.protocols.icq.exceptions.ConvertStringException;

public abstract interface IMetaInfoParser
{
  public abstract void parse(byte[] paramArrayOfByte, int paramInt)
    throws ConvertStringException;

  public abstract void execute(OscarConnection paramOscarConnection);

  public abstract void notifyEvent(OscarConnection paramOscarConnection);
}

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.metainfo.IMetaInfoParser
 * JD-Core Version:    0.6.0
 */