/*     */ package ru.caffeineim.protocols.icq;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import ru.caffeineim.protocols.icq.exceptions.ConvertStringException;
/*     */ import ru.caffeineim.protocols.icq.tool.StringTools;
/*     */ 
/*     */ public class Item extends DataField
/*     */ {
/*     */   public static final short TYPE_CONTACT = 0;
/*     */   public static final short TYPE_GROUP = 1;
/*     */   public static final short TYPE_VISIBLE = 2;
/*     */   public static final short TYPE_INVISIBLE = 3;
/*     */   public static final short TYPE_VISIBILITY = 4;
/*     */   public static final short TYPE_PRESENCE_INFO = 5;
/*     */   public static final short TYPE_ICQTIC = 9;
/*     */   public static final short TYPE_IGNORE_LIST = 14;
/*     */   public static final short TYPE_LAST_UPDATE_DATE = 15;
/*     */   public static final short TYPE_SMS_CONTACT = 16;
/*     */   public static final short TYPE_IMPORT_TIME = 19;
/*     */   public static final short TYPE_CONTACT_ICON = 20;
/*     */   public static final byte VISIBILITY_TLV_ALLOW_ALL = 1;
/*     */   public static final byte VISIBILITY_TLV_BLOCK_ALL = 2;
/*     */   public static final byte VISIBILITY_TLV_ALLOW_LIST = 3;
/*     */   public static final byte VISIBILITY_TLV_BLOCK_LIST = 4;
/*     */   public static final byte VISIBILITY_TLV_ALLOW_CONTACT = 5;
/*     */   private short nameLen;
/*     */   private String name;
/*     */   private short group;
/*     */   private short id;
/*     */   private Tlv itemTlv;
/*     */ 
/*     */   public Item(short id, short groupid, String name)
/*     */   {
/*  56 */     this.id = id;
/*  57 */     this.group = groupid;
/*  58 */     this.name = name;
/*  59 */     this.nameLen = (short)name.length();
/*     */   }
/*     */ 
/*     */   public Item(byte[] data, int offset) throws ConvertStringException {
/*  63 */     int index = offset;
/*  64 */     this.nameLen = (short)new RawData(data, index, 2).getValue();
/*  65 */     index += 2;
/*  66 */     this.name = StringTools.utf8ByteArrayToString(data, index, this.nameLen);
/*  67 */     index += this.nameLen;
/*  68 */     this.group = (short)new RawData(data, index, 2).getValue();
/*  69 */     index += 2;
/*  70 */     this.id = (short)new RawData(data, index, 2).getValue();
/*  71 */     index += 2;
/*  72 */     this.itemTlv = new Tlv(data, index);
/*  73 */     this.byteArray = new byte[getLength()];
/*  74 */     System.arraycopy(data, offset, this.byteArray, 0, this.byteArray.length);
/*     */   }
/*     */ 
/*     */   public int getLength() {
/*  78 */     return this.itemTlv.getByteArray().length + this.nameLen + 6;
/*     */   }
/*     */ 
/*     */   public String getName() {
/*  82 */     return this.name;
/*     */   }
/*     */ 
/*     */   public short getGroup() {
/*  86 */     return this.group;
/*     */   }
/*     */ 
/*     */   public short getId() {
/*  90 */     return this.id;
/*     */   }
/*     */ 
/*     */   public short getType() {
/*  94 */     return (short)this.itemTlv.getType();
/*     */   }
/*     */ 
/*     */   public Iterator getTlvsIterator() {
/*  98 */     return new Iterator() {
/*  99 */       private int offset = 0;
/*     */ 
/* 101 */       private final int offsetMax = Item.this.itemTlv.getDataFieldByteArray().length;
/*     */ 
/*     */       public boolean hasNext() {
/* 104 */         return this.offset < this.offsetMax;
/*     */       }
/*     */ 
/*     */       public Object next() {
/* 108 */         Tlv retTlv = new Tlv(Item.this.itemTlv.getDataFieldByteArray(), this.offset);
/* 109 */         this.offset += retTlv.getByteArray().length;
/* 110 */         return retTlv;
/*     */       }
/*     */ 
/*     */       public void remove() {
/* 114 */         throw new UnsupportedOperationException();
/*     */       } } ;
/*     */   }
/*     */ 
/*     */   protected byte[] getByteArray() {
/* 120 */     byte[] retArray = new byte[this.byteArray.length];
/* 121 */     System.arraycopy(this.byteArray, 0, retArray, 0, retArray.length);
/* 122 */     return retArray;
/*     */   }
/*     */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.Item
 * JD-Core Version:    0.6.0
 */