/*    */ package ru.caffeineim.protocols.icq.integration.events;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ import ru.caffeineim.protocols.icq.packet.received.icbm.ServerICBMError__4_1;
/*    */ import ru.caffeineim.protocols.icq.setting.enumerations.GlobalErrorsEnum;
/*    */ 
/*    */ public class MessageErrorEvent extends EventObject
/*    */ {
/*    */   private static final long serialVersionUID = -2134901750740303991L;
/*    */ 
/*    */   public MessageErrorEvent(ServerICBMError__4_1 source)
/*    */   {
/* 32 */     super(source);
/*    */   }
/*    */ 
/*    */   public GlobalErrorsEnum getError() {
/* 36 */     return ((ServerICBMError__4_1)getSource()).getError();
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.integration.events.MessageErrorEvent
 * JD-Core Version:    0.6.0
 */