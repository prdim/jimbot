package ru.caffeineim.protocols.icq.integration.listeners;

import java.util.EventListener;
import ru.caffeineim.protocols.icq.integration.events.MetaAffilationsUserInfoEvent;
import ru.caffeineim.protocols.icq.integration.events.MetaBasicUserInfoEvent;
import ru.caffeineim.protocols.icq.integration.events.MetaEmailUserInfoEvent;
import ru.caffeineim.protocols.icq.integration.events.MetaInterestsUserInfoEvent;
import ru.caffeineim.protocols.icq.integration.events.MetaMoreUserInfoEvent;
import ru.caffeineim.protocols.icq.integration.events.MetaNoteUserInfoEvent;
import ru.caffeineim.protocols.icq.integration.events.MetaShortUserInfoEvent;
import ru.caffeineim.protocols.icq.integration.events.MetaWorkUserInfoEvent;
import ru.caffeineim.protocols.icq.integration.events.UINRegistrationFailedEvent;
import ru.caffeineim.protocols.icq.integration.events.UINRegistrationSuccessEvent;

public abstract interface MetaInfoListener extends EventListener
{
  public abstract void onShortUserInfo(MetaShortUserInfoEvent paramMetaShortUserInfoEvent);

  public abstract void onBasicUserInfo(MetaBasicUserInfoEvent paramMetaBasicUserInfoEvent);

  public abstract void onEmailUserInfo(MetaEmailUserInfoEvent paramMetaEmailUserInfoEvent);

  public abstract void onWorkUserInfo(MetaWorkUserInfoEvent paramMetaWorkUserInfoEvent);

  public abstract void onInterestsUserInfo(MetaInterestsUserInfoEvent paramMetaInterestsUserInfoEvent);

  public abstract void onMoreUserInfo(MetaMoreUserInfoEvent paramMetaMoreUserInfoEvent);

  public abstract void onNotesUserInfo(MetaNoteUserInfoEvent paramMetaNoteUserInfoEvent);

  public abstract void onAffilationsUserInfo(MetaAffilationsUserInfoEvent paramMetaAffilationsUserInfoEvent);

  public abstract void onRegisterNewUINSuccess(UINRegistrationSuccessEvent paramUINRegistrationSuccessEvent);

  public abstract void onRegisterNewUINFailed(UINRegistrationFailedEvent paramUINRegistrationFailedEvent);
}

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.integration.listeners.MetaInfoListener
 * JD-Core Version:    0.6.0
 */