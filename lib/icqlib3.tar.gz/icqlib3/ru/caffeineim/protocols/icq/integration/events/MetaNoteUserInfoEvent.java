/*    */ package ru.caffeineim.protocols.icq.integration.events;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ import ru.caffeineim.protocols.icq.metainfo.NotesUserInfoParser;
/*    */ 
/*    */ public class MetaNoteUserInfoEvent extends EventObject
/*    */ {
/*    */   private static final long serialVersionUID = -2665788131933999461L;
/*    */ 
/*    */   public MetaNoteUserInfoEvent(NotesUserInfoParser source)
/*    */   {
/* 31 */     super(source);
/*    */   }
/*    */ 
/*    */   public String getNote() {
/* 35 */     return ((NotesUserInfoParser)getSource()).getNote();
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.integration.events.MetaNoteUserInfoEvent
 * JD-Core Version:    0.6.0
 */