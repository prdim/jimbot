/*    */ package ru.caffeineim.protocols.icq.integration.events;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ import ru.caffeineim.protocols.icq.metainfo.MetaAckParser;
/*    */ 
/*    */ public class MetaAckEvent extends EventObject
/*    */ {
/*    */   private static final long serialVersionUID = 7502170145119936435L;
/*    */ 
/*    */   public MetaAckEvent(MetaAckParser source)
/*    */   {
/* 31 */     super(source);
/*    */   }
/*    */ 
/*    */   public boolean isOk() {
/* 35 */     return ((MetaAckParser)getSource()).isOk();
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.integration.events.MetaAckEvent
 * JD-Core Version:    0.6.0
 */