/*    */ package ru.caffeineim.protocols.icq.integration.events;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ import ru.caffeineim.protocols.icq.packet.received.ssi.SsiAuthReply__19_27;
/*    */ 
/*    */ public class SsiAuthReplyEvent extends EventObject
/*    */ {
/*    */   private static final long serialVersionUID = 2677077723784627879L;
/*    */ 
/*    */   public SsiAuthReplyEvent(SsiAuthReply__19_27 msg)
/*    */   {
/* 31 */     super(msg);
/*    */   }
/*    */ 
/*    */   public String getSenderUin() {
/* 35 */     return ((SsiAuthReply__19_27)getSource()).getSenderUin();
/*    */   }
/*    */ 
/*    */   public String getMessage() {
/* 39 */     return ((SsiAuthReply__19_27)getSource()).getMessage();
/*    */   }
/*    */ 
/*    */   public boolean getAuthFlag() {
/* 43 */     return ((SsiAuthReply__19_27)getSource()).getAuthFlag();
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.integration.events.SsiAuthReplyEvent
 * JD-Core Version:    0.6.0
 */