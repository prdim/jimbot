/*     */ package ru.caffeineim.protocols.icq.integration;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import ru.caffeineim.protocols.icq.core.OscarClient;
/*     */ import ru.caffeineim.protocols.icq.core.OscarConnection;
/*     */ import ru.caffeineim.protocols.icq.exceptions.ConvertStringException;
/*     */ import ru.caffeineim.protocols.icq.packet.sent.buddylist.RemoveFromContactList;
/*     */ import ru.caffeineim.protocols.icq.packet.sent.generic.SetICQStatus;
/*     */ import ru.caffeineim.protocols.icq.packet.sent.generic.SetIdleTime;
/*     */ import ru.caffeineim.protocols.icq.packet.sent.icbm.SendType1Message;
/*     */ import ru.caffeineim.protocols.icq.packet.sent.icbm.SendType2Message;
/*     */ import ru.caffeineim.protocols.icq.packet.sent.icbm.SendXStatus;
/*     */ import ru.caffeineim.protocols.icq.packet.sent.icbm.XStatusRequest;
/*     */ import ru.caffeineim.protocols.icq.packet.sent.location.SetLocationInformation;
/*     */ import ru.caffeineim.protocols.icq.packet.sent.meta.ChangeOwnInfo;
/*     */ import ru.caffeineim.protocols.icq.packet.sent.meta.ChangePassword;
/*     */ import ru.caffeineim.protocols.icq.packet.sent.meta.FindUsersByUIN;
/*     */ import ru.caffeineim.protocols.icq.packet.sent.meta.FullUserInfo;
/*     */ import ru.caffeineim.protocols.icq.packet.sent.meta.RequestFullUserInfo;
/*     */ import ru.caffeineim.protocols.icq.packet.sent.meta.RequestOfflineMessages;
/*     */ import ru.caffeineim.protocols.icq.packet.sent.meta.RequestShortUserInfo;
/*     */ import ru.caffeineim.protocols.icq.packet.sent.privacy.SetPrivateStatus;
/*     */ import ru.caffeineim.protocols.icq.packet.sent.ssi.SsiContactListRequest;
/*     */ import ru.caffeineim.protocols.icq.packet.sent.ssi.SsiSendAuthReplyMessage;
/*     */ import ru.caffeineim.protocols.icq.packet.sent.ssi.SsiSendYouWereAdded;
/*     */ import ru.caffeineim.protocols.icq.setting.Tweaker;
/*     */ import ru.caffeineim.protocols.icq.setting.enumerations.IdleTimeEnum;
/*     */ import ru.caffeineim.protocols.icq.setting.enumerations.XStatusModeEnum;
/*     */ 
/*     */ public class OscarInterface
/*     */ {
/*     */   public static String getVersion()
/*     */   {
/*  54 */     return "0.7.6";
/*     */   }
/*     */ 
/*     */   public static void sendBasicMessage(OscarConnection connection, String userId, String message)
/*     */     throws ConvertStringException, IOException
/*     */   {
/*  67 */     connection.sendFlap(new SendType1Message(userId, message));
/*     */   }
/*     */ 
/*     */   public static void sendExtendedMessage(OscarConnection connection, String userId, String message)
/*     */     throws ConvertStringException, IOException
/*     */   {
/*  83 */     connection.sendFlap(new SendType2Message(userId, message));
/*     */   }
/*     */ 
/*     */   public static void changeStatus(OscarConnection connection, int newStatus)
/*     */   {
/*  94 */     connection.sendFlap(new SetICQStatus(newStatus, connection.getTweaker().getInitialStatusFlags(), connection.getTweaker().getTcpConnectionFlag(), connection.getClient().getInetaddress(), connection.getTweaker().getP2PPortListening()));
/*     */   }
/*     */ 
/*     */   public static void changeStatus2(OscarConnection connection, int newStatus)
/*     */   {
/* 120 */     connection.sendFlap(new SetICQStatus(newStatus));
/*     */   }
/*     */ 
/*     */   public static void RemoveFromContactList(OscarConnection con, String uin)
/*     */   {
/* 131 */     con.sendFlap(new RemoveFromContactList(uin));
/*     */   }
/*     */ 
/*     */   public static void SsiSendYouWereAdded(OscarConnection con, String uin)
/*     */   {
/* 142 */     con.sendFlap(new SsiSendYouWereAdded(uin));
/*     */   }
/*     */ 
/*     */   public static void changeXStatus(OscarConnection connection, int xstatus)
/*     */   {
/* 159 */     connection.sendFlap(new SetLocationInformation(xstatus));
/*     */   }
/*     */ 
/*     */   public static void changeXStatus(OscarConnection connection, int xstatus, int client)
/*     */   {
/* 167 */     connection.sendFlap(new SetLocationInformation(xstatus, client));
/*     */   }
/*     */ 
/*     */   public static void SetInfo(OscarConnection connection, FullUserInfo info, String uin)
/*     */   {
/* 175 */     connection.sendFlap(new ChangeOwnInfo(uin, info));
/*     */   }
/*     */ 
/*     */   public static void SendAdded(OscarConnection connection, String uin)
/*     */   {
/* 183 */     connection.sendFlap(new SsiSendYouWereAdded(uin));
/*     */   }
/*     */ 
/*     */   public static void sendXStatus(OscarConnection connection, int xstatus, String title, String description, long time, int msgId, String userId, int tcpVersion)
/*     */     throws ConvertStringException
/*     */   {
/* 207 */     connection.sendFlap(new SendXStatus((int)(time / 1000000L), msgId, userId, connection.getUserId(), tcpVersion, new XStatusModeEnum(xstatus), title, description));
/*     */   }
/*     */ 
/*     */   public static void sendXStatusRequest(OscarConnection connection, String userId)
/*     */   {
/* 222 */     connection.sendFlap(new XStatusRequest(userId, connection.getUserId()));
/*     */   }
/*     */ 
/*     */   public static void setIdleTime(OscarConnection connection, IdleTimeEnum idleTimeMode)
/*     */   {
/* 236 */     connection.sendFlap(new SetIdleTime(idleTimeMode));
/*     */   }
/*     */ 
/*     */   public static void sendAuthReply(OscarConnection connection, String uin, String msg, boolean auth)
/*     */     throws ConvertStringException
/*     */   {
/* 244 */     connection.sendFlap(new SsiSendAuthReplyMessage(uin, msg, auth));
/*     */   }
/*     */ 
/*     */   public static void requestOfflineMessages(OscarConnection connection)
/*     */   {
/* 258 */     connection.sendFlap(new RequestOfflineMessages(connection.getUserId()));
/*     */   }
/*     */ 
/*     */   public static void requestShortUserInfo(OscarConnection connection, String userId)
/*     */   {
/* 272 */     connection.sendFlap(new RequestShortUserInfo(userId, connection.getUserId()));
/*     */   }
/*     */ 
/*     */   public static void requestFullUserInfo(OscarConnection connection, String userId)
/*     */   {
/* 286 */     connection.sendFlap(new RequestFullUserInfo(userId, connection.getUserId()));
/*     */   }
/*     */ 
/*     */   public static void changePassword(OscarConnection connection, String password)
/*     */     throws ConvertStringException
/*     */   {
/* 301 */     connection.sendFlap(new ChangePassword(connection.getUserId(), password));
/*     */   }
/*     */ 
/*     */   public static void findUsersByUIN(OscarConnection connection, String userId)
/*     */   {
/* 314 */     connection.sendFlap(new FindUsersByUIN(userId, connection.getUserId()));
/*     */   }
/*     */ 
/*     */   public static void sendContatListRequest(OscarConnection connection)
/*     */   {
/* 326 */     connection.sendFlap(new SsiContactListRequest());
/*     */   }
/*     */ 
/*     */   public static void changePrivateStatus(OscarConnection connection, String uin, byte status)
/*     */   {
/* 334 */     connection.sendFlap(new SetPrivateStatus(uin, status));
/*     */   }
/*     */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.integration.OscarInterface
 * JD-Core Version:    0.6.0
 */