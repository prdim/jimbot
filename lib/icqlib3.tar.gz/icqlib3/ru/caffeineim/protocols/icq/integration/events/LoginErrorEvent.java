/*    */ package ru.caffeineim.protocols.icq.integration.events;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ import ru.caffeineim.protocols.icq.setting.enumerations.LoginErrorTypeEnum;
/*    */ 
/*    */ public class LoginErrorEvent extends EventObject
/*    */ {
/*    */   private static final long serialVersionUID = 7662695167749107169L;
/*    */ 
/*    */   public LoginErrorEvent(LoginErrorTypeEnum type)
/*    */   {
/* 34 */     super(type);
/*    */   }
/*    */ 
/*    */   public String getErrorMessage() {
/* 38 */     return this.source.toString();
/*    */   }
/*    */ 
/*    */   public LoginErrorTypeEnum getErrorType() {
/* 42 */     return (LoginErrorTypeEnum)this.source;
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.integration.events.LoginErrorEvent
 * JD-Core Version:    0.6.0
 */