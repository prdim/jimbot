package ru.caffeineim.protocols.icq.integration.listeners;

import java.util.EventListener;
import ru.caffeineim.protocols.icq.integration.events.MetaAckEvent;

public abstract interface MetaAckListener extends EventListener
{
  public abstract void onMetaAck(MetaAckEvent paramMetaAckEvent);
}

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.integration.listeners.MetaAckListener
 * JD-Core Version:    0.6.0
 */