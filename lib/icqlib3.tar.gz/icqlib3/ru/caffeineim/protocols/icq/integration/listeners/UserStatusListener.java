package ru.caffeineim.protocols.icq.integration.listeners;

import java.util.EventListener;
import ru.caffeineim.protocols.icq.integration.events.IncomingUserEvent;
import ru.caffeineim.protocols.icq.integration.events.MessageAckEvent;
import ru.caffeineim.protocols.icq.integration.events.OffgoingUserEvent;

public abstract interface UserStatusListener extends EventListener
{
  public abstract void onIncomingUser(IncomingUserEvent paramIncomingUserEvent);

  public abstract void onOffgoingUser(OffgoingUserEvent paramOffgoingUserEvent);

  public abstract void onMessageAck(MessageAckEvent paramMessageAckEvent);
}

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.integration.listeners.UserStatusListener
 * JD-Core Version:    0.6.0
 */