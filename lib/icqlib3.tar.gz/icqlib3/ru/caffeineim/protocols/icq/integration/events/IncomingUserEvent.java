/*    */ package ru.caffeineim.protocols.icq.integration.events;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ import ru.caffeineim.protocols.icq.packet.received.byddylist.IncomingUser__3_11;
/*    */ import ru.caffeineim.protocols.icq.setting.enumerations.ClientsEnum;
/*    */ import ru.caffeineim.protocols.icq.setting.enumerations.StatusFlagEnum;
/*    */ import ru.caffeineim.protocols.icq.setting.enumerations.StatusModeEnum;
/*    */ 
/*    */ public class IncomingUserEvent extends EventObject
/*    */ {
/*    */   private static final long serialVersionUID = -5665513460661361463L;
/*    */ 
/*    */   public IncomingUserEvent(IncomingUser__3_11 source)
/*    */   {
/* 34 */     super(source);
/*    */   }
/*    */ 
/*    */   public String getIncomingUserId() {
/* 38 */     return ((IncomingUser__3_11)getSource()).getUserId();
/*    */   }
/*    */ 
/*    */   public String getInterlnalIp() {
/* 42 */     return ((IncomingUser__3_11)getSource()).getInterlnalIp();
/*    */   }
/*    */ 
/*    */   public int getPort() {
/* 46 */     return ((IncomingUser__3_11)getSource()).getPort();
/*    */   }
/*    */ 
/*    */   public String getExternalIp() {
/* 50 */     return ((IncomingUser__3_11)getSource()).getExternalIp();
/*    */   }
/*    */ 
/*    */   public StatusModeEnum getStatusMode() {
/* 54 */     return ((IncomingUser__3_11)getSource()).getStatusMode();
/*    */   }
/*    */ 
/*    */   public StatusFlagEnum getStatusFlag() {
/* 58 */     return ((IncomingUser__3_11)getSource()).getStatusFlag();
/*    */   }
/*    */ 
/*    */   public ClientsEnum getClientData() {
/* 62 */     return ((IncomingUser__3_11)getSource()).getClient();
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.integration.events.IncomingUserEvent
 * JD-Core Version:    0.6.0
 */