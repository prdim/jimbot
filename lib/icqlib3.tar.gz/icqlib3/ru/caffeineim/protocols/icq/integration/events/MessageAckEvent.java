/*    */ package ru.caffeineim.protocols.icq.integration.events;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ import ru.caffeineim.protocols.icq.packet.received.icbm.MessageAck__4_12;
/*    */ 
/*    */ public class MessageAckEvent extends EventObject
/*    */ {
/*    */   private static final long serialVersionUID = 4390662787302984914L;
/*    */ 
/*    */   public MessageAckEvent(MessageAck__4_12 source)
/*    */   {
/* 31 */     super(source);
/*    */   }
/*    */ 
/*    */   public int getMessageTime() {
/* 35 */     return ((MessageAck__4_12)this.source).getMessageTime();
/*    */   }
/*    */ 
/*    */   public int getMessageId() {
/* 39 */     return ((MessageAck__4_12)this.source).getMessageId();
/*    */   }
/*    */ 
/*    */   public short getMessageType() {
/* 43 */     return ((MessageAck__4_12)this.source).getMessageType();
/*    */   }
/*    */ 
/*    */   public String getRcptUin() {
/* 47 */     return ((MessageAck__4_12)this.source).getRcptUin();
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.integration.events.MessageAckEvent
 * JD-Core Version:    0.6.0
 */