/*    */ package ru.caffeineim.protocols.icq.integration.events;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ import ru.caffeineim.protocols.icq.packet.received.ssi.SsiModifyingAck__19_14;
/*    */ import ru.caffeineim.protocols.icq.setting.enumerations.SsiResultModeEnum;
/*    */ 
/*    */ public class SsiModifyingAckEvent extends EventObject
/*    */ {
/*    */   private static final long serialVersionUID = -2803906198129443216L;
/*    */ 
/*    */   public SsiModifyingAckEvent(SsiModifyingAck__19_14 source)
/*    */   {
/* 35 */     super(source);
/*    */   }
/*    */ 
/*    */   public SsiResultModeEnum[] getResults() {
/* 39 */     return ((SsiModifyingAck__19_14)getSource()).getResuls();
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.integration.events.SsiModifyingAckEvent
 * JD-Core Version:    0.6.0
 */