/*    */ package ru.caffeineim.protocols.icq.integration.events;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ import ru.caffeineim.protocols.icq.packet.received.byddylist.OffgoingUser__3_12;
/*    */ 
/*    */ public class OffgoingUserEvent extends EventObject
/*    */ {
/*    */   private static final long serialVersionUID = 5744689489017496055L;
/*    */ 
/*    */   public OffgoingUserEvent(OffgoingUser__3_12 source)
/*    */   {
/* 31 */     super(source);
/*    */   }
/*    */ 
/*    */   public String getOffgoingUserId() {
/* 35 */     return ((OffgoingUser__3_12)getSource()).getUserId();
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.integration.events.OffgoingUserEvent
 * JD-Core Version:    0.6.0
 */