/*    */ package ru.caffeineim.protocols.icq.integration.events;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ import java.util.List;
/*    */ import ru.caffeineim.protocols.icq.metainfo.EmailUserInfoParser;
/*    */ 
/*    */ public class MetaEmailUserInfoEvent extends EventObject
/*    */ {
/*    */   private static final long serialVersionUID = -2549449467706651913L;
/*    */ 
/*    */   public MetaEmailUserInfoEvent(EmailUserInfoParser source)
/*    */   {
/* 32 */     super(source);
/*    */   }
/*    */ 
/*    */   public List getEmails() {
/* 36 */     return ((EmailUserInfoParser)getSource()).getEmails();
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.integration.events.MetaEmailUserInfoEvent
 * JD-Core Version:    0.6.0
 */