/*    */ package ru.caffeineim.protocols.icq.integration.events;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ import ru.caffeineim.protocols.icq.packet.received.icbm.MissedMessage__4_10;
/*    */ import ru.caffeineim.protocols.icq.setting.enumerations.MessageMissedTypeEnum;
/*    */ 
/*    */ public class MessageMissedEvent extends EventObject
/*    */ {
/*    */   private static final long serialVersionUID = -1249038091908724243L;
/*    */ 
/*    */   public MessageMissedEvent(MissedMessage__4_10 source)
/*    */   {
/* 32 */     super(source);
/*    */   }
/*    */ 
/*    */   public int getMissedMsgCount() {
/* 36 */     return ((MissedMessage__4_10)this.source).getMissedMsgCount();
/*    */   }
/*    */ 
/*    */   public String getUin() {
/* 40 */     return ((MissedMessage__4_10)this.source).getUin();
/*    */   }
/*    */ 
/*    */   public MessageMissedTypeEnum getReason() {
/* 44 */     return ((MissedMessage__4_10)this.source).getReason();
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.integration.events.MessageMissedEvent
 * JD-Core Version:    0.6.0
 */