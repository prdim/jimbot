/*    */ package ru.caffeineim.protocols.icq.integration.events;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ import ru.caffeineim.protocols.icq.packet.received.authorization.UINRegistrationSuccess__23_5;
/*    */ 
/*    */ public class UINRegistrationSuccessEvent extends EventObject
/*    */ {
/*    */   private static final long serialVersionUID = -2690338742682890998L;
/*    */ 
/*    */   public UINRegistrationSuccessEvent(UINRegistrationSuccess__23_5 source)
/*    */   {
/* 31 */     super(source);
/*    */   }
/*    */ 
/*    */   public String getNewUIN() {
/* 35 */     return ((UINRegistrationSuccess__23_5)getSource()).getNewUIN();
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.integration.events.UINRegistrationSuccessEvent
 * JD-Core Version:    0.6.0
 */