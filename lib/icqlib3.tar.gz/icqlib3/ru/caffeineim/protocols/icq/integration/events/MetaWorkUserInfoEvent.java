/*    */ package ru.caffeineim.protocols.icq.integration.events;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ import ru.caffeineim.protocols.icq.metainfo.WorkUserInfoParser;
/*    */ import ru.caffeineim.protocols.icq.setting.enumerations.CountryEnum;
/*    */ import ru.caffeineim.protocols.icq.setting.enumerations.OccupationEnum;
/*    */ 
/*    */ public class MetaWorkUserInfoEvent extends EventObject
/*    */ {
/*    */   private static final long serialVersionUID = -8999509597744117843L;
/*    */ 
/*    */   public MetaWorkUserInfoEvent(WorkUserInfoParser source)
/*    */   {
/* 33 */     super(source);
/*    */   }
/*    */ 
/*    */   public String getWorkCity() {
/* 37 */     return ((WorkUserInfoParser)getSource()).getWorkCity();
/*    */   }
/*    */ 
/*    */   public String getWorkState() {
/* 41 */     return ((WorkUserInfoParser)getSource()).getWorkState();
/*    */   }
/*    */ 
/*    */   public String getWorkPhone() {
/* 45 */     return ((WorkUserInfoParser)getSource()).getWorkPhone();
/*    */   }
/*    */ 
/*    */   public String getWorkFax() {
/* 49 */     return ((WorkUserInfoParser)getSource()).getWorkFax();
/*    */   }
/*    */ 
/*    */   public String getWorkAddress() {
/* 53 */     return ((WorkUserInfoParser)getSource()).getWorkAddress();
/*    */   }
/*    */ 
/*    */   public String getWorkZip() {
/* 57 */     return ((WorkUserInfoParser)getSource()).getWorkZip();
/*    */   }
/*    */ 
/*    */   public String getWorkCompany() {
/* 61 */     return ((WorkUserInfoParser)getSource()).getWorkCompany();
/*    */   }
/*    */ 
/*    */   public String getWorkDepartment() {
/* 65 */     return ((WorkUserInfoParser)getSource()).getWorkDepartment();
/*    */   }
/*    */ 
/*    */   public String getWorkPosition() {
/* 69 */     return ((WorkUserInfoParser)getSource()).getWorkPosition();
/*    */   }
/*    */ 
/*    */   public String getWorkWebPage() {
/* 73 */     return ((WorkUserInfoParser)getSource()).getWorkWebPage();
/*    */   }
/*    */ 
/*    */   public OccupationEnum getWorkOccupation() {
/* 77 */     return ((WorkUserInfoParser)getSource()).getWorkOccupation();
/*    */   }
/*    */ 
/*    */   public CountryEnum getWorkCountry() {
/* 81 */     return ((WorkUserInfoParser)getSource()).getWorkCountry();
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.integration.events.MetaWorkUserInfoEvent
 * JD-Core Version:    0.6.0
 */