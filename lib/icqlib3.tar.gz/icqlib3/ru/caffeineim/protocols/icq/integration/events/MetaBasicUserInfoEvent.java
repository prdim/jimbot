/*     */ package ru.caffeineim.protocols.icq.integration.events;
/*     */ 
/*     */ import java.util.EventObject;
/*     */ import ru.caffeineim.protocols.icq.metainfo.BasicUserInfoParser;
/*     */ import ru.caffeineim.protocols.icq.setting.enumerations.CountryEnum;
/*     */ import ru.caffeineim.protocols.icq.setting.enumerations.TimeZoneEnum;
/*     */ 
/*     */ public class MetaBasicUserInfoEvent extends EventObject
/*     */ {
/*     */   private static final long serialVersionUID = -6831886773708776171L;
/*     */ 
/*     */   public MetaBasicUserInfoEvent(BasicUserInfoParser source)
/*     */   {
/*  33 */     super(source);
/*     */   }
/*     */ 
/*     */   public String getNickName() {
/*  37 */     return ((BasicUserInfoParser)getSource()).getNickName();
/*     */   }
/*     */ 
/*     */   public String getFirstName() {
/*  41 */     return ((BasicUserInfoParser)getSource()).getFirstName();
/*     */   }
/*     */ 
/*     */   public String getLastName() {
/*  45 */     return ((BasicUserInfoParser)getSource()).getLastName();
/*     */   }
/*     */ 
/*     */   public String getEmail() {
/*  49 */     return ((BasicUserInfoParser)getSource()).getEmail();
/*     */   }
/*     */ 
/*     */   public String getHomeCity() {
/*  53 */     return ((BasicUserInfoParser)getSource()).getHomeCity();
/*     */   }
/*     */ 
/*     */   public String getHomeState() {
/*  57 */     return ((BasicUserInfoParser)getSource()).getHomeState();
/*     */   }
/*     */ 
/*     */   public String getHomePhone() {
/*  61 */     return ((BasicUserInfoParser)getSource()).getHomePhone();
/*     */   }
/*     */ 
/*     */   public String getHomeFax() {
/*  65 */     return ((BasicUserInfoParser)getSource()).getHomeFax();
/*     */   }
/*     */ 
/*     */   public String getHomeAddress() {
/*  69 */     return ((BasicUserInfoParser)getSource()).getHomeAddress();
/*     */   }
/*     */ 
/*     */   public String getCellPhone() {
/*  73 */     return ((BasicUserInfoParser)getSource()).getCellPhone();
/*     */   }
/*     */ 
/*     */   public String getZipCode() {
/*  77 */     return ((BasicUserInfoParser)getSource()).getZipCode();
/*     */   }
/*     */ 
/*     */   public CountryEnum getHomeCountry() {
/*  81 */     return ((BasicUserInfoParser)getSource()).getHomeCountry();
/*     */   }
/*     */ 
/*     */   public TimeZoneEnum getTimeZone() {
/*  85 */     return ((BasicUserInfoParser)getSource()).getTimeZone();
/*     */   }
/*     */ 
/*     */   public boolean isAuth() {
/*  89 */     return ((BasicUserInfoParser)getSource()).isAuthFlag();
/*     */   }
/*     */ 
/*     */   public boolean isWebaware() {
/*  93 */     return ((BasicUserInfoParser)getSource()).isWebawareFlag();
/*     */   }
/*     */ 
/*     */   public boolean isDirectConnection() {
/*  97 */     return ((BasicUserInfoParser)getSource()).isDirectConnection();
/*     */   }
/*     */ 
/*     */   public boolean isPublishPrimaryEmail() {
/* 101 */     return ((BasicUserInfoParser)getSource()).isPublishPrimaryEmail();
/*     */   }
/*     */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.integration.events.MetaBasicUserInfoEvent
 * JD-Core Version:    0.6.0
 */