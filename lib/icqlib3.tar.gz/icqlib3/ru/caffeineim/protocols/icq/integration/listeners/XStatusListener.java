package ru.caffeineim.protocols.icq.integration.listeners;

import java.util.EventListener;
import ru.caffeineim.protocols.icq.integration.events.XStatusRequestEvent;
import ru.caffeineim.protocols.icq.integration.events.XStatusResponseEvent;

public abstract interface XStatusListener extends EventListener
{
  public abstract void onXStatusRequest(XStatusRequestEvent paramXStatusRequestEvent);

  public abstract void onXStatusResponse(XStatusResponseEvent paramXStatusResponseEvent);
}

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.integration.listeners.XStatusListener
 * JD-Core Version:    0.6.0
 */