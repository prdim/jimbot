package ru.caffeineim.protocols.icq.integration.listeners;

import java.util.EventListener;
import ru.caffeineim.protocols.icq.integration.events.IncomingMessageEvent;
import ru.caffeineim.protocols.icq.integration.events.IncomingUrlEvent;
import ru.caffeineim.protocols.icq.integration.events.MessageErrorEvent;
import ru.caffeineim.protocols.icq.integration.events.MessageMissedEvent;
import ru.caffeineim.protocols.icq.integration.events.OfflineMessageEvent;

public abstract interface MessagingListener extends EventListener
{
  public abstract void onIncomingMessage(IncomingMessageEvent paramIncomingMessageEvent);

  public abstract void onIncomingUrl(IncomingUrlEvent paramIncomingUrlEvent);

  public abstract void onOfflineMessage(OfflineMessageEvent paramOfflineMessageEvent);

  public abstract void onMessageError(MessageErrorEvent paramMessageErrorEvent);

  public abstract void onMessageMissed(MessageMissedEvent paramMessageMissedEvent);
}

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.integration.listeners.MessagingListener
 * JD-Core Version:    0.6.0
 */