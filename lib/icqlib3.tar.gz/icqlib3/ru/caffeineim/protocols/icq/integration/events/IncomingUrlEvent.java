/*    */ package ru.caffeineim.protocols.icq.integration.events;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ import ru.caffeineim.protocols.icq.packet.received.icbm.IncomingMessage__4_7;
/*    */ import ru.caffeineim.protocols.icq.setting.enumerations.StatusModeEnum;
/*    */ 
/*    */ public class IncomingUrlEvent extends EventObject
/*    */ {
/*    */   private static final long serialVersionUID = -4823657602187419746L;
/*    */ 
/*    */   public IncomingUrlEvent(IncomingMessage__4_7 source)
/*    */   {
/* 32 */     super(source);
/*    */   }
/*    */ 
/*    */   public int getMessageId() {
/* 36 */     return ((IncomingMessage__4_7)getSource()).getMessageId();
/*    */   }
/*    */ 
/*    */   public String getSenderID() {
/* 40 */     return ((IncomingMessage__4_7)getSource()).getSenderID();
/*    */   }
/*    */ 
/*    */   public String getMessage() {
/* 44 */     return ((IncomingMessage__4_7)getSource()).getMessage();
/*    */   }
/*    */ 
/*    */   public String getUrl() {
/* 48 */     return ((IncomingMessage__4_7)getSource()).getUrl();
/*    */   }
/*    */ 
/*    */   public StatusModeEnum getSenderStatus() {
/* 52 */     return ((IncomingMessage__4_7)getSource()).getSenderStatus();
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.integration.events.IncomingUrlEvent
 * JD-Core Version:    0.6.0
 */