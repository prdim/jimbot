/*    */ package ru.caffeineim.protocols.icq.integration.events;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ import ru.caffeineim.protocols.icq.packet.received.icbm.IncomingMessage__4_7;
/*    */ import ru.caffeineim.protocols.icq.setting.enumerations.StatusModeEnum;
/*    */ 
/*    */ public class IncomingMessageEvent extends EventObject
/*    */ {
/*    */   private static final long serialVersionUID = 3874220290268537705L;
/*    */ 
/*    */   public IncomingMessageEvent(IncomingMessage__4_7 source)
/*    */   {
/* 32 */     super(source);
/*    */   }
/*    */ 
/*    */   public int getMessageId() {
/* 36 */     return ((IncomingMessage__4_7)getSource()).getMessageId();
/*    */   }
/*    */ 
/*    */   public int getMessageSeqNum() {
/* 40 */     return ((IncomingMessage__4_7)getSource()).getMessageSeqNum();
/*    */   }
/*    */ 
/*    */   public String getSenderID() {
/* 44 */     return ((IncomingMessage__4_7)getSource()).getSenderID();
/*    */   }
/*    */ 
/*    */   public StatusModeEnum getSenderStatus() {
/* 48 */     return ((IncomingMessage__4_7)getSource()).getSenderStatus();
/*    */   }
/*    */ 
/*    */   public String getMessage() {
/* 52 */     return ((IncomingMessage__4_7)getSource()).getMessage();
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.integration.events.IncomingMessageEvent
 * JD-Core Version:    0.6.0
 */