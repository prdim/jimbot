/*    */ package ru.caffeineim.protocols.icq.integration.events;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ import ru.caffeineim.protocols.icq.packet.received.ssi.SsiAuthRequest__19_25;
/*    */ 
/*    */ public class SsiAuthRequestEvent extends EventObject
/*    */ {
/*    */   private static final long serialVersionUID = -424498393439394416L;
/*    */ 
/*    */   public SsiAuthRequestEvent(SsiAuthRequest__19_25 msg)
/*    */   {
/* 31 */     super(msg);
/*    */   }
/*    */ 
/*    */   public String getSenderUin() {
/* 35 */     return ((SsiAuthRequest__19_25)getSource()).getSenderUin();
/*    */   }
/*    */ 
/*    */   public String getMessage() {
/* 39 */     return ((SsiAuthRequest__19_25)getSource()).getMessage();
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.integration.events.SsiAuthRequestEvent
 * JD-Core Version:    0.6.0
 */