/*    */ package ru.caffeineim.protocols.icq.integration.events;
/*    */ 
/*    */ import java.util.Date;
/*    */ import java.util.EventObject;
/*    */ import ru.caffeineim.protocols.icq.metainfo.OfflineMessageParser;
/*    */ import ru.caffeineim.protocols.icq.setting.enumerations.MessageFlagsEnum;
/*    */ import ru.caffeineim.protocols.icq.setting.enumerations.MessageTypeEnum;
/*    */ 
/*    */ public class OfflineMessageEvent extends EventObject
/*    */ {
/*    */   private static final long serialVersionUID = -1783900296942284591L;
/*    */ 
/*    */   public OfflineMessageEvent(OfflineMessageParser parser)
/*    */   {
/* 35 */     super(parser);
/*    */   }
/*    */ 
/*    */   public String getSenderUin() {
/* 39 */     return ((OfflineMessageParser)getSource()).getSenderUin();
/*    */   }
/*    */ 
/*    */   public Date getSendDate() {
/* 43 */     return ((OfflineMessageParser)getSource()).getSendDate();
/*    */   }
/*    */ 
/*    */   public String getMessage() {
/* 47 */     return ((OfflineMessageParser)getSource()).getMessage();
/*    */   }
/*    */ 
/*    */   public MessageTypeEnum getMessageType() {
/* 51 */     return ((OfflineMessageParser)getSource()).getMessageType();
/*    */   }
/*    */ 
/*    */   public MessageFlagsEnum getMessageFlag() {
/* 55 */     return ((OfflineMessageParser)getSource()).getMessageFlag();
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.integration.events.OfflineMessageEvent
 * JD-Core Version:    0.6.0
 */