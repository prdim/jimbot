/*    */ package ru.caffeineim.protocols.icq.integration.events;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ import java.util.Map;
/*    */ import ru.caffeineim.protocols.icq.metainfo.InterestsUserInfoParser;
/*    */ 
/*    */ public class MetaInterestsUserInfoEvent extends EventObject
/*    */ {
/*    */   private static final long serialVersionUID = -5349542463432171361L;
/*    */ 
/*    */   public MetaInterestsUserInfoEvent(InterestsUserInfoParser source)
/*    */   {
/* 32 */     super(source);
/*    */   }
/*    */ 
/*    */   public Map getInterests() {
/* 36 */     return ((InterestsUserInfoParser)getSource()).getInterests();
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.integration.events.MetaInterestsUserInfoEvent
 * JD-Core Version:    0.6.0
 */