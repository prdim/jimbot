/*    */ package ru.caffeineim.protocols.icq.integration.events;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ import ru.caffeineim.protocols.icq.packet.received.generic.OnlineInfoResp__1_15;
/*    */ 
/*    */ public class StatusEvent extends EventObject
/*    */ {
/*    */   private static final long serialVersionUID = -459517084246159557L;
/*    */ 
/*    */   public StatusEvent(OnlineInfoResp__1_15 source)
/*    */   {
/* 34 */     super(source);
/*    */   }
/*    */ 
/*    */   public int getStatusFlag() {
/* 38 */     return ((OnlineInfoResp__1_15)this.source).getStatusFlag();
/*    */   }
/*    */ 
/*    */   public int getStatusMode() {
/* 42 */     return ((OnlineInfoResp__1_15)this.source).getStatusMode();
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.integration.events.StatusEvent
 * JD-Core Version:    0.6.0
 */