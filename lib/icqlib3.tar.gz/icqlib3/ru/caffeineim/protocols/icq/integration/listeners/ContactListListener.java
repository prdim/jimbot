package ru.caffeineim.protocols.icq.integration.listeners;

import java.util.EventListener;
import ru.caffeineim.protocols.icq.integration.events.ContactListEvent;
import ru.caffeineim.protocols.icq.integration.events.SsiAuthReplyEvent;
import ru.caffeineim.protocols.icq.integration.events.SsiAuthRequestEvent;
import ru.caffeineim.protocols.icq.integration.events.SsiFutureAuthGrantEvent;
import ru.caffeineim.protocols.icq.integration.events.SsiModifyingAckEvent;

public abstract interface ContactListListener extends EventListener
{
  public abstract void onUpdateContactList(ContactListEvent paramContactListEvent);

  public abstract void onSsiModifyingAck(SsiModifyingAckEvent paramSsiModifyingAckEvent);

  public abstract void onSsiFutureAuthGrant(SsiFutureAuthGrantEvent paramSsiFutureAuthGrantEvent);

  public abstract void onSsiAuthRequest(SsiAuthRequestEvent paramSsiAuthRequestEvent);

  public abstract void onSsiAuthReply(SsiAuthReplyEvent paramSsiAuthReplyEvent);
}

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.integration.listeners.ContactListListener
 * JD-Core Version:    0.6.0
 */