/*    */ package ru.caffeineim.protocols.icq.integration.events;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ import ru.caffeineim.protocols.icq.packet.received.authorization.UINRegistrationFailed__23_1;
/*    */ 
/*    */ public class UINRegistrationFailedEvent extends EventObject
/*    */ {
/*    */   private static final long serialVersionUID = 3076041651776567131L;
/*    */ 
/*    */   public UINRegistrationFailedEvent(UINRegistrationFailed__23_1 source)
/*    */   {
/* 31 */     super(source);
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.integration.events.UINRegistrationFailedEvent
 * JD-Core Version:    0.6.0
 */