/*    */ package ru.caffeineim.protocols.icq.integration.events;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ import java.util.Iterator;
/*    */ import java.util.SortedMap;
/*    */ import java.util.TreeMap;
/*    */ import ru.caffeineim.protocols.icq.Item;
/*    */ import ru.caffeineim.protocols.icq.contacts.Contact;
/*    */ import ru.caffeineim.protocols.icq.contacts.Group;
/*    */ import ru.caffeineim.protocols.icq.packet.received.ssi.SsiContactListReply__19_6;
/*    */ 
/*    */ public class ContactListEvent extends EventObject
/*    */ {
/*    */   private static final long serialVersionUID = -3740165191665792396L;
/*    */   private static final String EMPTY = "";
/*    */   private Group root;
/*    */ 
/*    */   public ContactListEvent(SsiContactListReply__19_6 source)
/*    */   {
/* 43 */     super(source);
/*    */ 
/* 45 */     SortedMap grpMap = new TreeMap();
/* 46 */     SortedMap contMap = new TreeMap();
/*    */ 
/* 48 */     for (Iterator iter = source.getItemsIterator(); iter.hasNext(); ) {
/* 49 */       Item item = (Item)iter.next();
/* 50 */       switch (item.getType()) {
/*    */       case 0:
/*    */       case 14:
/* 53 */         contMap.put(new Short(item.getId()), item);
/* 54 */         break;
/*    */       case 1:
/* 56 */         grpMap.put(new Short(item.getGroup()), new Group(item));
/*    */       case 20:
/*    */       }
/*    */ 
/*    */     }
/*    */ 
/* 63 */     for (Iterator iter = contMap.values().iterator(); iter.hasNext(); ) {
/* 64 */       Item item = (Item)iter.next();
/* 65 */       Group grp = (Group)grpMap.get(new Short(item.getGroup()));
/* 66 */       grp.addItem(new Contact(item));
/*    */     }
/*    */ 
/* 69 */     this.root = ((Group)grpMap.remove(0));
/* 70 */     if (this.root == null) {
/* 71 */       this.root = new Group((short)0, "");
/*    */     }
/* 73 */     for (Iterator iter = grpMap.values().iterator(); iter.hasNext(); ) {
/* 74 */       Group grp = (Group)iter.next();
/* 75 */       this.root.addItem(grp);
/*    */     }
/*    */   }
/*    */ 
/*    */   public Group getRoot() {
/* 80 */     return this.root;
/*    */   }
/*    */ 
/*    */   public int getCount() {
/* 84 */     return ((SsiContactListReply__19_6)getSource()).getCount();
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.integration.events.ContactListEvent
 * JD-Core Version:    0.6.0
 */