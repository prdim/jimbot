/*    */ package ru.caffeineim.protocols.icq.integration.events;
/*    */ 
/*    */ import java.util.Date;
/*    */ import java.util.EventObject;
/*    */ import java.util.List;
/*    */ import ru.caffeineim.protocols.icq.metainfo.MoreUserInfoParser;
/*    */ import ru.caffeineim.protocols.icq.setting.enumerations.CountryEnum;
/*    */ import ru.caffeineim.protocols.icq.setting.enumerations.GenderEnum;
/*    */ import ru.caffeineim.protocols.icq.setting.enumerations.MaritalStatusEnum;
/*    */ 
/*    */ public class MetaMoreUserInfoEvent extends EventObject
/*    */ {
/*    */   private static final long serialVersionUID = -7346651515115520506L;
/*    */ 
/*    */   public MetaMoreUserInfoEvent(MoreUserInfoParser source)
/*    */   {
/* 36 */     super(source);
/*    */   }
/*    */ 
/*    */   public int getAge() {
/* 40 */     return ((MoreUserInfoParser)getSource()).getAge();
/*    */   }
/*    */ 
/*    */   public GenderEnum getGender() {
/* 44 */     return ((MoreUserInfoParser)getSource()).getGender();
/*    */   }
/*    */ 
/*    */   public String getHomePage() {
/* 48 */     return ((MoreUserInfoParser)getSource()).getHomePage();
/*    */   }
/*    */ 
/*    */   public Date getBirth() {
/* 52 */     return ((MoreUserInfoParser)getSource()).getBirth();
/*    */   }
/*    */ 
/*    */   public List getLanguages() {
/* 56 */     return ((MoreUserInfoParser)getSource()).getLanguages();
/*    */   }
/*    */ 
/*    */   public String getOriginalCity() {
/* 60 */     return ((MoreUserInfoParser)getSource()).getOriginalCity();
/*    */   }
/*    */ 
/*    */   public String getOriginalState() {
/* 64 */     return ((MoreUserInfoParser)getSource()).getOriginalState();
/*    */   }
/*    */ 
/*    */   public CountryEnum getOriginalCountry() {
/* 68 */     return ((MoreUserInfoParser)getSource()).getOriginalCountry();
/*    */   }
/*    */ 
/*    */   public MaritalStatusEnum getMaritalStatus() {
/* 72 */     return ((MoreUserInfoParser)getSource()).getMaritalStatus();
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.integration.events.MetaMoreUserInfoEvent
 * JD-Core Version:    0.6.0
 */