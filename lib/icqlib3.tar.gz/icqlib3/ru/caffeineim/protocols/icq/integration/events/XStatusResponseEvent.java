/*    */ package ru.caffeineim.protocols.icq.integration.events;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ import ru.caffeineim.protocols.icq.packet.received.icbm.MessageAutoReply__4_11;
/*    */ import ru.caffeineim.protocols.icq.setting.enumerations.XStatusModeEnum;
/*    */ 
/*    */ public class XStatusResponseEvent extends EventObject
/*    */ {
/*    */   private static final long serialVersionUID = 3401985213523814147L;
/* 31 */   private XStatusModeEnum xstatus = new XStatusModeEnum(0);
/* 32 */   private String title = "";
/* 33 */   private String description = "";
/*    */ 
/*    */   public XStatusResponseEvent(MessageAutoReply__4_11 source)
/*    */   {
/* 39 */     super(source);
/* 40 */     parseXStatusMessage(((MessageAutoReply__4_11)getSource()).getMessage());
/*    */   }
/*    */ 
/*    */   private void parseXStatusMessage(String message) {
/* 44 */     String[] strs = message.split("[&;]");
/*    */     try {
/* 46 */       this.xstatus = new XStatusModeEnum(Integer.parseInt(strs[44]));
/* 47 */       this.title = strs[52];
/* 48 */       this.description = strs[60];
/*    */     }
/*    */     catch (Exception ex) {
/* 51 */       ex.printStackTrace();
/*    */     }
/*    */   }
/*    */ 
/*    */   public String getSenderID() {
/* 56 */     return ((MessageAutoReply__4_11)getSource()).getSenderID();
/*    */   }
/*    */ 
/*    */   public XStatusModeEnum getXStatus() {
/* 60 */     return this.xstatus;
/*    */   }
/*    */ 
/*    */   public String getTitle() {
/* 64 */     return this.title;
/*    */   }
/*    */ 
/*    */   public String getDescription() {
/* 68 */     return this.description;
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.integration.events.XStatusResponseEvent
 * JD-Core Version:    0.6.0
 */