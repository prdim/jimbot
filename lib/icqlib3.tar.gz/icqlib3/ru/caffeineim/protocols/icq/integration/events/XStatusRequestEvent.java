/*    */ package ru.caffeineim.protocols.icq.integration.events;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ import ru.caffeineim.protocols.icq.packet.received.icbm.IncomingMessage__4_7;
/*    */ import ru.caffeineim.protocols.icq.setting.enumerations.StatusModeEnum;
/*    */ 
/*    */ public class XStatusRequestEvent extends EventObject
/*    */ {
/*    */   private static final long serialVersionUID = 7552679906825500214L;
/*    */ 
/*    */   public XStatusRequestEvent(IncomingMessage__4_7 source)
/*    */   {
/* 35 */     super(source);
/*    */   }
/*    */ 
/*    */   public String getSenderID() {
/* 39 */     return ((IncomingMessage__4_7)getSource()).getSenderID();
/*    */   }
/*    */ 
/*    */   public int getTime() {
/* 43 */     return ((IncomingMessage__4_7)getSource()).getTime();
/*    */   }
/*    */ 
/*    */   public int getMsgID() {
/* 47 */     return ((IncomingMessage__4_7)getSource()).getMessageId();
/*    */   }
/*    */ 
/*    */   public int getSenderTcpVersion() {
/* 51 */     return ((IncomingMessage__4_7)getSource()).getSenderTcpVersion();
/*    */   }
/*    */ 
/*    */   public StatusModeEnum getSenderStatus() {
/* 55 */     return ((IncomingMessage__4_7)getSource()).getSenderStatus();
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.integration.events.XStatusRequestEvent
 * JD-Core Version:    0.6.0
 */