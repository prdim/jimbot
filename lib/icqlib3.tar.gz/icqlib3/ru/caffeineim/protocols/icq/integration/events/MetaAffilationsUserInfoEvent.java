/*    */ package ru.caffeineim.protocols.icq.integration.events;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ import java.util.Map;
/*    */ import ru.caffeineim.protocols.icq.metainfo.AffilationsUserInfoParser;
/*    */ 
/*    */ public class MetaAffilationsUserInfoEvent extends EventObject
/*    */ {
/*    */   private static final long serialVersionUID = -5924242976594062666L;
/*    */ 
/*    */   public MetaAffilationsUserInfoEvent(AffilationsUserInfoParser source)
/*    */   {
/* 32 */     super(source);
/*    */   }
/*    */ 
/*    */   public Map getPostBackgrounds() {
/* 36 */     return ((AffilationsUserInfoParser)getSource()).getPostBackgrounds();
/*    */   }
/*    */ 
/*    */   public Map getAffilations() {
/* 40 */     return ((AffilationsUserInfoParser)getSource()).getAffilations();
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.integration.events.MetaAffilationsUserInfoEvent
 * JD-Core Version:    0.6.0
 */