/*    */ package ru.caffeineim.protocols.icq.integration.events;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ import ru.caffeineim.protocols.icq.metainfo.ShortUserInfoParser;
/*    */ 
/*    */ public class MetaShortUserInfoEvent extends EventObject
/*    */ {
/*    */   private static final long serialVersionUID = -397005868703632983L;
/*    */ 
/*    */   public MetaShortUserInfoEvent(ShortUserInfoParser source)
/*    */   {
/* 32 */     super(source);
/*    */   }
/*    */ 
/*    */   public String getNickName() {
/* 36 */     return ((ShortUserInfoParser)getSource()).getNickName();
/*    */   }
/*    */ 
/*    */   public String getFirstName() {
/* 40 */     return ((ShortUserInfoParser)getSource()).getFirstName();
/*    */   }
/*    */ 
/*    */   public String getLastName() {
/* 44 */     return ((ShortUserInfoParser)getSource()).getLastName();
/*    */   }
/*    */ 
/*    */   public String getEmail() {
/* 48 */     return ((ShortUserInfoParser)getSource()).getEmail();
/*    */   }
/*    */ 
/*    */   public boolean isAuth() {
/* 52 */     return ((ShortUserInfoParser)getSource()).isAuthFlag();
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.integration.events.MetaShortUserInfoEvent
 * JD-Core Version:    0.6.0
 */