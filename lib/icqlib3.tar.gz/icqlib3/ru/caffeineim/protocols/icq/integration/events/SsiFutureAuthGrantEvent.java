/*    */ package ru.caffeineim.protocols.icq.integration.events;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ import ru.caffeineim.protocols.icq.packet.received.ssi.SsiFutureAuthGranted__19_20;
/*    */ 
/*    */ public class SsiFutureAuthGrantEvent extends EventObject
/*    */ {
/*    */   private static final long serialVersionUID = 450453134629277027L;
/*    */ 
/*    */   public SsiFutureAuthGrantEvent(SsiFutureAuthGranted__19_20 msg)
/*    */   {
/* 31 */     super(msg);
/*    */   }
/*    */ 
/*    */   public String getSenderUin() {
/* 35 */     return ((SsiFutureAuthGranted__19_20)getSource()).getSenderUin();
/*    */   }
/*    */ 
/*    */   public String getMessage() {
/* 39 */     return ((SsiFutureAuthGranted__19_20)getSource()).getMessage();
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.integration.events.SsiFutureAuthGrantEvent
 * JD-Core Version:    0.6.0
 */