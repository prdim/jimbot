/*    */ package ru.caffeineim.protocols.icq.packet.sent.privacy;
/*    */ 
/*    */ import ru.caffeineim.protocols.icq.Flap;
/*    */ import ru.caffeineim.protocols.icq.Snac;
/*    */ 
/*    */ public class BosRightsRequest extends Flap
/*    */ {
/*    */   public BosRightsRequest()
/*    */   {
/* 28 */     super(2);
/*    */ 
/* 30 */     Snac snac = new Snac(9, 2, 0, 0, 0);
/* 31 */     addSnac(snac);
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.sent.privacy.BosRightsRequest
 * JD-Core Version:    0.6.0
 */