/*    */ package ru.caffeineim.protocols.icq.packet.sent.meta;
/*    */ 
/*    */ import ru.caffeineim.protocols.icq.RawData;
/*    */ import ru.caffeineim.protocols.icq.Tlv;
/*    */ 
/*    */ public abstract class RequestUserInfo extends BaseClientMeta
/*    */ {
/*    */   protected static final int REQUEST_LENGHT = 3584;
/*    */ 
/*    */   public RequestUserInfo(String uinSearch, String uinForRequest, int subType)
/*    */   {
/* 37 */     super(3584, uinForRequest, 2000, subType);
/*    */ 
/* 40 */     RawData rUin = new RawData(Integer.parseInt(uinSearch), 4);
/* 41 */     rUin.invertIndianness();
/* 42 */     this.tlv.appendRawDataToTlv(rUin);
/*    */ 
/* 44 */     finalizePacket();
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.sent.meta.RequestUserInfo
 * JD-Core Version:    0.6.0
 */