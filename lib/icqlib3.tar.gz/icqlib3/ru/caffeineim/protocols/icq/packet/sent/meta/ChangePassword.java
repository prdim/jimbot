/*    */ package ru.caffeineim.protocols.icq.packet.sent.meta;
/*    */ 
/*    */ import ru.caffeineim.protocols.icq.RawData;
/*    */ import ru.caffeineim.protocols.icq.Tlv;
/*    */ import ru.caffeineim.protocols.icq.exceptions.ConvertStringException;
/*    */ import ru.caffeineim.protocols.icq.tool.StringTools;
/*    */ 
/*    */ public class ChangePassword extends BaseClientMeta
/*    */ {
/*    */   protected static final int REQUEST_LENGHT = 3328;
/*    */ 
/*    */   public ChangePassword(String uinForRequest, String password)
/*    */     throws ConvertStringException
/*    */   {
/* 33 */     super(3328 + (StringTools.stringToByteArray(password).length << 8), uinForRequest, 2000, 1070);
/*    */ 
/* 37 */     byte[] passwd = StringTools.stringToByteArray(password);
/* 38 */     RawData rdPasswd = new RawData(passwd.length, 2);
/* 39 */     rdPasswd.invertIndianness();
/* 40 */     this.tlv.appendRawDataToTlv(rdPasswd);
/*    */ 
/* 43 */     this.tlv.appendRawDataToTlv(new RawData(passwd));
/* 44 */     this.tlv.appendRawDataToTlv(new RawData(0, 1));
/*    */ 
/* 46 */     finalizePacket();
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.sent.meta.ChangePassword
 * JD-Core Version:    0.6.0
 */