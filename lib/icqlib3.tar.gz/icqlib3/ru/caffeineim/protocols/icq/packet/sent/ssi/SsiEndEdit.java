/*    */ package ru.caffeineim.protocols.icq.packet.sent.ssi;
/*    */ 
/*    */ import ru.caffeineim.protocols.icq.Flap;
/*    */ import ru.caffeineim.protocols.icq.Snac;
/*    */ 
/*    */ public class SsiEndEdit extends Flap
/*    */ {
/*    */   public SsiEndEdit()
/*    */   {
/* 33 */     super(2);
/* 34 */     Snac snac = new Snac(19, 18, 0, 0, 18);
/* 35 */     addSnac(snac);
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.sent.ssi.SsiEndEdit
 * JD-Core Version:    0.6.0
 */