/*     */ package ru.caffeineim.protocols.icq.packet.received.icbm;
/*     */ 
/*     */ import java.util.List;
/*     */ import ru.caffeineim.protocols.icq.RawData;
/*     */ import ru.caffeineim.protocols.icq.Snac;
/*     */ import ru.caffeineim.protocols.icq.Tlv;
/*     */ import ru.caffeineim.protocols.icq.core.OscarConnection;
/*     */ import ru.caffeineim.protocols.icq.integration.events.MessageMissedEvent;
/*     */ import ru.caffeineim.protocols.icq.integration.listeners.MessagingListener;
/*     */ import ru.caffeineim.protocols.icq.packet.received.ReceivedPacket;
/*     */ import ru.caffeineim.protocols.icq.setting.enumerations.MessageMissedTypeEnum;
/*     */ 
/*     */ public class MissedMessage__4_10 extends ReceivedPacket
/*     */ {
/*     */   private Tlv usrClass;
/*     */   private Tlv usrStatus;
/*     */   private Tlv clientOnlineTime;
/*     */   private Tlv offlineTime;
/*     */   private String uin;
/*     */   private MessageMissedTypeEnum reason;
/*     */   private int missedMsgCount;
/*     */   public static final short MESSAGE_INVALID = 0;
/*     */   public static final short MESSAGE_TOO_LARGE = 1;
/*     */   public static final short MESSAGE_RATE_EXCEEDED = 2;
/*     */   public static final short SENDER_TOO_EVIL = 3;
/*     */   public static final short USER_TOO_EVIL = 4;
/*     */ 
/*     */   public MissedMessage__4_10(byte[] array)
/*     */   {
/*  49 */     super(array, true);
/*     */ 
/*  51 */     byte[] data = getSnac().getDataFieldByteArray();
/*  52 */     int index = 0;
/*     */     do
/*     */     {
/*  55 */       RawData type = new RawData(data, index, 2);
/*  56 */       index += 2;
/*  57 */       RawData uinLg = new RawData(data, index, 1);
/*  58 */       index++;
/*  59 */       this.uin = new RawData(data, index, uinLg.getValue()).getStringValue();
/*  60 */       index += uinLg.getValue();
/*  61 */       RawData warningLvl = new RawData(data, index, 2);
/*  62 */       index += 2;
/*  63 */       RawData nbOfTlv = new RawData(data, index, 2);
/*  64 */       index += 2;
/*     */ 
/*  66 */       this.usrClass = new Tlv(data, index);
/*  67 */       index += this.usrClass.getLength() + 4;
/*     */ 
/*  69 */       this.usrStatus = new Tlv(data, index);
/*  70 */       index += this.usrStatus.getLength() + 4;
/*     */ 
/*  73 */       for (int k = 0; k < nbOfTlv.getValue() - 4; k++) {
/*  74 */         Tlv fakeTlv = new Tlv(data, index);
/*  75 */         index += fakeTlv.getLength() + 4;
/*     */       }
/*     */ 
/*  78 */       this.clientOnlineTime = new Tlv(data, index);
/*  79 */       index += this.clientOnlineTime.getLength() + 4;
/*     */ 
/*  81 */       this.offlineTime = new Tlv(data, index);
/*  82 */       index += this.offlineTime.getLength() + 4;
/*     */ 
/*  84 */       this.missedMsgCount = new RawData(data, index, 2).getValue();
/*  85 */       index += 2;
/*     */ 
/*  87 */       this.reason = new MessageMissedTypeEnum(new RawData(data, index, 2).getValue());
/*  88 */       index += 2;
/*     */     }
/*  90 */     while (index < data.length);
/*     */   }
/*     */ 
/*     */   public void execute(OscarConnection connection) throws Exception {
/*     */   }
/*     */ 
/*     */   public void notifyEvent(OscarConnection connection) {
/*  97 */     MessageMissedEvent e = new MessageMissedEvent(this);
/*  98 */     for (int i = 0; i < connection.getMessagingListeners().size(); i++) {
/*  99 */       MessagingListener l = (MessagingListener)connection.getMessagingListeners().get(i);
/* 100 */       l.onMessageMissed(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getMissedMsgCount() {
/* 105 */     return this.missedMsgCount;
/*     */   }
/*     */ 
/*     */   public String getUin() {
/* 109 */     return this.uin;
/*     */   }
/*     */ 
/*     */   public MessageMissedTypeEnum getReason() {
/* 113 */     return this.reason;
/*     */   }
/*     */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.received.icbm.MissedMessage__4_10
 * JD-Core Version:    0.6.0
 */