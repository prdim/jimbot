/*     */ package ru.caffeineim.protocols.icq.packet.sent.location;
/*     */ 
/*     */ import ru.caffeineim.protocols.icq.Flap;
/*     */ import ru.caffeineim.protocols.icq.RawData;
/*     */ import ru.caffeineim.protocols.icq.Snac;
/*     */ import ru.caffeineim.protocols.icq.Tlv;
/*     */ import ru.caffeineim.protocols.icq.setting.enumerations.ClientsEnum;
/*     */ import ru.caffeineim.protocols.icq.setting.enumerations.XStatusModeEnum;
/*     */ 
/*     */ public class SetLocationInformation extends Flap
/*     */ {
/*  33 */   private static final byte[] AIM_SERVER_RELAY = { 9, 70, 19, 73, 76, 127, 17, -47, -126, 34, 68, 69, 83, 84, 0, 0 };
/*     */ 
/*  37 */   private static final byte[] AIM_RECIVE_FROM_ICQ = { 9, 70, 19, 77, 76, 127, 17, -47, -126, 34, 68, 69, 83, 84, 0, 0 };
/*     */ 
/*  41 */   private static final byte[] AIM_SUPPORT_FILE_TRANSFERS = { 9, 70, 19, 67, 76, 127, 17, -47, -126, 34, 68, 69, 83, 84, 0, 0 };
/*     */ 
/*  45 */   private static final byte[] AIM_LIST_SHORT_CAPS = { 9, 70, 0, 0, 76, 127, 17, -47, -126, 34, 68, 69, 83, 84, 0, 0 };
/*     */ 
/*  49 */   private static final byte[] UTF8_SUPPORT_CAPS = { 9, 70, 19, 78, 76, 127, 17, -47, -126, 34, 68, 69, 83, 84, 0, 0 };
/*     */ 
/*  53 */   private static final byte[] AIM_ICQ_RTF_CAPS = { -105, -79, 39, 81, 36, 60, 67, 52, -83, 34, -42, -85, -9, 63, 20, -110 };
/*     */ 
/*  57 */   private static final byte[] ICQ_CAPS = { 9, 70, 19, 68, 76, 127, 17, -47, -126, 34, 68, 69, 83, 84, 0, 0 };
/*     */ 
/*  61 */   private static final byte[] ICQ_DEVILS_CAPS = { 9, 70, 19, 76, 76, 127, 17, -47, -126, 34, 68, 69, 83, 84, 0, 0 };
/*     */ 
/*  65 */   private static final byte[] ROUTE_FINDER_CAPS = { 9, 70, 19, 68, 76, 127, 17, -47, -126, 34, 68, 69, 83, 84, 0, 0 };
/*     */ 
/*  69 */   private static final byte[] ICQ_XTRAZ_CAPS = { 26, 9, 60, 108, -41, -3, 78, -59, -99, 81, -90, 71, 78, 52, -11, -96 };
/*     */ 
/*  73 */   private static final byte[] CAP_KOPETE = { 75, 111, 112, 101, 116, 101, 32, 73, 67, 81, 32, 32, 0, 0, 0, 0 };
/*     */ 
/*     */   public SetLocationInformation()
/*     */   {
/*  80 */     super(2);
/*  81 */     SendLocationInformation(0);
/*     */   }
/*     */ 
/*     */   public SetLocationInformation(int xstatus)
/*     */   {
/*  90 */     super(2);
/*  91 */     SendLocationInformation(xstatus);
/*     */   }
/*     */ 
/*     */   public SetLocationInformation(int xstatus, int client) {
/*  95 */     super(2);
/*  96 */     SendLocationInformation(xstatus, client);
/*     */   }
/*     */ 
/*     */   public final void SendLocationInformation(int xstatus)
/*     */   {
/* 106 */     Snac snac = new Snac(2, 4, 0, 0, 0);
/*     */ 
/* 108 */     Tlv capaTlv = new Tlv(new RawData(AIM_SERVER_RELAY), 5);
/*     */ 
/* 111 */     capaTlv.appendRawDataToTlv(new RawData(AIM_SUPPORT_FILE_TRANSFERS));
/* 112 */     capaTlv.appendRawDataToTlv(new RawData(AIM_RECIVE_FROM_ICQ));
/* 113 */     capaTlv.appendRawDataToTlv(new RawData(AIM_LIST_SHORT_CAPS));
/* 114 */     capaTlv.appendRawDataToTlv(new RawData(ICQ_CAPS));
/* 115 */     capaTlv.appendRawDataToTlv(new RawData(ICQ_DEVILS_CAPS));
/* 116 */     capaTlv.appendRawDataToTlv(new RawData(ROUTE_FINDER_CAPS));
/* 117 */     capaTlv.appendRawDataToTlv(new RawData(UTF8_SUPPORT_CAPS));
/* 118 */     capaTlv.appendRawDataToTlv(new RawData(ICQ_XTRAZ_CAPS));
/* 119 */     byte[] t = ClientsEnum.getClientData(12);
/* 120 */     capaTlv.appendRawDataToTlv(new RawData(t, 0, t.length));
/* 121 */     capaTlv.appendRawDataToTlv(new RawData(XStatusModeEnum.getXStatusData(xstatus)));
/* 122 */     snac.addTlvToSnac(capaTlv);
/* 123 */     addSnac(snac);
/*     */   }
/*     */ 
/*     */   public final void SendLocationInformation(int xstatus, int client) {
/* 127 */     Snac snac = new Snac(2, 4, 0, 0, 0);
/*     */ 
/* 130 */     Tlv capaTlv = new Tlv(new RawData(AIM_SERVER_RELAY), 5);
/*     */ 
/* 133 */     capaTlv.appendRawDataToTlv(new RawData(AIM_SUPPORT_FILE_TRANSFERS));
/* 134 */     capaTlv.appendRawDataToTlv(new RawData(AIM_RECIVE_FROM_ICQ));
/* 135 */     capaTlv.appendRawDataToTlv(new RawData(AIM_LIST_SHORT_CAPS));
/* 136 */     capaTlv.appendRawDataToTlv(new RawData(ICQ_CAPS));
/* 137 */     capaTlv.appendRawDataToTlv(new RawData(ICQ_DEVILS_CAPS));
/* 138 */     capaTlv.appendRawDataToTlv(new RawData(ROUTE_FINDER_CAPS));
/* 139 */     capaTlv.appendRawDataToTlv(new RawData(UTF8_SUPPORT_CAPS));
/* 140 */     capaTlv.appendRawDataToTlv(new RawData(ICQ_XTRAZ_CAPS));
/*     */     byte[] t;
/* 142 */     if (client != 0) t = ClientsEnum.getClientData(client); else
/* 143 */       t = ClientsEnum.getClientData(12);
/* 144 */     capaTlv.appendRawDataToTlv(new RawData(t, 0, t.length));
/* 145 */     capaTlv.appendRawDataToTlv(new RawData(XStatusModeEnum.getXStatusData(xstatus)));
/* 146 */     snac.addTlvToSnac(capaTlv);
/* 147 */     addSnac(snac);
/*     */   }
/*     */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.sent.location.SetLocationInformation
 * JD-Core Version:    0.6.0
 */