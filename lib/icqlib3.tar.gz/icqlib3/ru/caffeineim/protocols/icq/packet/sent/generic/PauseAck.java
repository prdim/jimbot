/*    */ package ru.caffeineim.protocols.icq.packet.sent.generic;
/*    */ 
/*    */ import ru.caffeineim.protocols.icq.Flap;
/*    */ import ru.caffeineim.protocols.icq.RawData;
/*    */ import ru.caffeineim.protocols.icq.Snac;
/*    */ 
/*    */ public class PauseAck extends Flap
/*    */ {
/*    */   public PauseAck()
/*    */   {
/* 29 */     super(2, new Snac(1, 12, 0, 0, 0));
/* 30 */     getSnac().addRawDataToSnac(new RawData(1, 2));
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.sent.generic.PauseAck
 * JD-Core Version:    0.6.0
 */