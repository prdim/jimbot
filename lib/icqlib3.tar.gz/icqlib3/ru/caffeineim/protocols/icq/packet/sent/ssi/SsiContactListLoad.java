/*    */ package ru.caffeineim.protocols.icq.packet.sent.ssi;
/*    */ 
/*    */ import ru.caffeineim.protocols.icq.Flap;
/*    */ import ru.caffeineim.protocols.icq.Snac;
/*    */ 
/*    */ public class SsiContactListLoad extends Flap
/*    */ {
/*    */   public SsiContactListLoad()
/*    */   {
/* 28 */     super(2);
/* 29 */     Snac snac = new Snac(19, 7, 0, 0, 0);
/* 30 */     addSnac(snac);
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.sent.ssi.SsiContactListLoad
 * JD-Core Version:    0.6.0
 */