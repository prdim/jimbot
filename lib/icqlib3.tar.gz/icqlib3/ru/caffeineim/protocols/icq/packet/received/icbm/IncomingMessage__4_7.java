package ru.caffeineim.protocols.icq.packet.received.icbm;

import ru.caffeineim.protocols.icq.RawData;
import ru.caffeineim.protocols.icq.Tlv;
import ru.caffeineim.protocols.icq.core.OscarConnection;
import ru.caffeineim.protocols.icq.exceptions.ConvertStringException;
import ru.caffeineim.protocols.icq.integration.events.IncomingMessageEvent;
import ru.caffeineim.protocols.icq.integration.events.IncomingUrlEvent;
import ru.caffeineim.protocols.icq.integration.events.XStatusRequestEvent;
import ru.caffeineim.protocols.icq.integration.listeners.MessagingListener;
import ru.caffeineim.protocols.icq.integration.listeners.XStatusListener;
import ru.caffeineim.protocols.icq.packet.received.ReceivedPacket;
import ru.caffeineim.protocols.icq.packet.sent.icbm.MessageType2Ack;
import ru.caffeineim.protocols.icq.setting.enumerations.MessageFlagsEnum;
import ru.caffeineim.protocols.icq.setting.enumerations.MessageTypeEnum;
import ru.caffeineim.protocols.icq.setting.enumerations.StatusModeEnum;
import ru.caffeineim.protocols.icq.tool.StringTools;

public class IncomingMessage__4_7 extends ReceivedPacket
{
  public static final int UCS2BE_ENCODING_MASK = 131072;
  private RawData time;
  private RawData msgId;
  private RawData messageChannel;
  private RawData ackType;
  private RawData senderTcpVer;
  private RawData msgSeqNum;
  private RawData msgType;
  private RawData msgFlags;
  private String senderID;
  private String message;
  private String url;
  private Tlv senderStatus;
  private Tlv ackType2;
  private Tlv port;
  private Tlv ip;
  private RawData encoding;
  private boolean isRequestAwayMessage = false;
  private boolean isRequestXStatus = false;
  private boolean isFileAckOrAbortRequest = false;
  private boolean isFileAckOrFileOk = false;

  public IncomingMessage__4_7(byte[] array) throws ConvertStringException
  {
    super(array, true);

    int position = 0;
    byte[] data = getSnac().getDataFieldByteArray();
    this.time = new RawData(data, position, 4);
    position += 4;

    this.msgId = new RawData(data, position, 4);
    position += 4;

    this.messageChannel = new RawData(data, position, 2);
    position += 2;

    RawData len = new RawData(data[(position++)]);
    this.senderID = new String(data, position, len.getValue());
    position += len.getValue();

    position += 2;

    RawData nbTlv = new RawData(data, position, 2);
    position += 2;

    for (int i = 0; i < nbTlv.getValue(); i++) {
      Tlv tmpTlv = new Tlv(data, position);

      switch (tmpTlv.getType()) {
      case 6:
        this.senderStatus = tmpTlv;
        break;
      case 15:
        break;
      case 3:
      }

      position += tmpTlv.getByteArray().length;
    }

    if (this.messageChannel.getValue() == 1) {
      parseType1(position, data);
    }
    else if (this.messageChannel.getValue() == 2) {
      parseType2(position, data);
    }
    else {
      parseType4(position, data);
    }

    if (getMessageType().getType() == 26)
      this.isRequestXStatus = true;
  }

  public void execute(OscarConnection connection)
    throws Exception
  {
   if ((this.messageChannel.getValue() == 2) && (!this.isRequestXStatus))
      connection.sendFlap(new MessageType2Ack(this.time, this.msgId, this.senderID, this.senderTcpVer, this.msgSeqNum, this.msgType, this.msgFlags, connection.getTweaker().getRequestMessage(this.msgType.getValue())));
  }

  public void notifyEvent(OscarConnection connection)
  {
   if (getMessageType().getType() == 1)
      notifyIncomingMessage(connection);
   else if (getMessageType().getType() == 4)
      notifyIncomingUrl(connection);
   else if (getMessageType().getType() == 26)
      notifyXStatusRequest(connection);
//   else if(getMessageType().getType()==252)
//       System.out.println("Miranda IM packet only");
//   else
//      System.err.println(Dumper.dump(byteArray, true)); // не известный нам тип пакета.
  }

  private void notifyIncomingMessage(OscarConnection connection)
  {
    IncomingMessageEvent e = new IncomingMessageEvent(this);
    for (int i = 0; i < connection.getMessagingListeners().size(); i++) {
      MessagingListener l = (MessagingListener)connection.getMessagingListeners().get(i);
      l.onIncomingMessage(e);
    }
  }

  private void notifyXStatusRequest(OscarConnection connection) {
    XStatusRequestEvent e = new XStatusRequestEvent(this);
    for (int i = 0; i < connection.getXStatusListeners().size(); i++) {
      XStatusListener l = (XStatusListener)connection.getXStatusListeners().get(i);
      l.onXStatusRequest(e);
    }
  }

  private void notifyIncomingUrl(OscarConnection connection) {
    IncomingUrlEvent e = new IncomingUrlEvent(this);
    for (int i = 0; i < connection.getMessagingListeners().size(); i++) {
      MessagingListener l = (MessagingListener)connection.getMessagingListeners().get(i);
      l.onIncomingUrl(e);
    }
  }

  private void parseType1(int position, byte[] data)
    throws ConvertStringException
  {
    this.msgType = new RawData(1);

    position += 4;

    Tlv tlvCapa = new Tlv(data, position);
    position += tlvCapa.getLength() + 4;

    Tlv tlvMsg = new Tlv(data, position);
    int msgLen = tlvMsg.getLength() - 4;

    position += 4;

    this.encoding = new RawData(data, position, 4);
    position += 4;

    if ((getEncoding() & 0x20000) > 0)
      this.message = StringTools.ucs2beByteArrayToString(data, position, msgLen);
    else
      this.message = StringTools.byteArrayToString(data, position, msgLen);
  }

  private void parseType2(int position, byte[] data)
    throws ConvertStringException
  {
    position += 4;

    this.ackType = new RawData(data, position, 2);
    position += 2;

    if (this.ackType.getValue() != 0)
    {
       this.isFileAckOrAbortRequest = true;
    }
    else
    {
      position += 8;

      position += 16;

      this.ackType2 = new Tlv(data, position);
      position += 4 + this.ackType2.getLength();

      if (this.ackType2.getValue() == 2)
      {
        this.port = new Tlv(data, position);
        position += 4 + this.port.getValue();

        this.ip = new Tlv(data, position);
        position += 4 + this.ip.getValue();
        this.isFileAckOrFileOk = true;
      }
      else
      {
        position += 10;

        this.senderTcpVer = new RawData(data, position, 2);
        position += 2;

        position += 23;

        this.msgSeqNum = new RawData(data, position, 2);
        position += 2;

        position += 16;

        this.msgType = new RawData(data, position, 1);
        position++;

        this.msgFlags = new RawData(data, position, 1);
        position++;

        if (this.msgType.getValue() == 1) {
          parseType2Message(position, data);
        }
        else if ((this.msgType.getValue() >= 232) && (this.msgType.getValue() <= 236))
          this.isRequestAwayMessage = true;
      }
    }
  }

  private void parseType2Message(int position, byte[] data) throws ConvertStringException
  {
    position += 4;

    RawData msgLen = new RawData(data, position, 2);
    msgLen.invertIndianness();
    position += 2;

    this.message = StringTools.utf8ByteArrayToString(data, position, msgLen.getValue() - 1);
    position += this.message.length();

    position += 4;

    position += 4;
  }

  private void parseType4(int position, byte[] data)
  {
    position += 4;

    position += 4;

    this.msgType = new RawData(data, position, 2);
    this.msgType.invertIndianness();
    position += 2;
    RawData msgLen = new RawData(data, position, 2);
    msgLen.invertIndianness();
    position += 2;

    if (this.msgType.getValue() == 1)
      parseType4Message(position, data, msgLen.getValue());
    else if (this.msgType.getValue() == 4)
      parseType4LinkMessage(position, data, msgLen.getValue());
  }

  private void parseType4Message(int position, byte[] data, int msgLen) {
    this.message = new String(data, position, msgLen - 1);
  }

  private void parseType4LinkMessage(int position, byte[] data, int msgLen)
  {
    String tmp = new String(data, position, msgLen - 1);
    int divPosition = tmp.indexOf('þ');
    this.message = tmp.substring(0, divPosition);
    this.url = tmp.substring(divPosition + 1, tmp.length());
  }

  public int getMessageId() {
    return this.msgId.getValue();
  }

  public int getMessageChannel() {
    return this.messageChannel.getValue();
  }

  public String getSenderID() {
    return this.senderID;
  }

  public int getSenderTcpVersion() {
    return this.senderTcpVer.getValue();
  }

  public int getMessageSeqNum() {
    return this.msgSeqNum.getValue();
  }

  public String getMessage() {
    return this.message;
  }

  public String getUrl() {
    return this.url;
  }

  public StatusModeEnum getSenderStatus()
  {
    if (this.senderStatus == null)
      return new StatusModeEnum(0);
    return new StatusModeEnum(this.senderStatus.getValue());
  }

  public MessageFlagsEnum getMessageFlag() {
    return new MessageFlagsEnum(this.msgFlags.getValue());
  }

  public final MessageTypeEnum getMessageType() {
    return new MessageTypeEnum(this.msgType.getValue());
  }

  public int getTime() {
    return this.time.getValue();
  }

  public int getEncoding() {
    return this.encoding.getValue();
  }
}