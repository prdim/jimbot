/*    */ package ru.caffeineim.protocols.icq.packet.received.usagestats;
/*    */ 
/*    */ import ru.caffeineim.protocols.icq.Snac;
/*    */ import ru.caffeineim.protocols.icq.core.OscarConnection;
/*    */ import ru.caffeineim.protocols.icq.packet.received.ReceivedPacket;
/*    */ 
/*    */ public class MinReportInterval__11_2 extends ReceivedPacket
/*    */ {
/*    */   private short interval;
/*    */ 
/*    */   public MinReportInterval__11_2(byte[] array)
/*    */   {
/* 30 */     super(array, true);
/* 31 */     byte[] data = getSnac().getDataFieldByteArray();
/* 32 */     this.interval = (short)((data[0] << 8) + (data[1] & 0xFF));
/*    */   }
/*    */ 
/*    */   public void execute(OscarConnection oscarconnection)
/*    */   {
/*    */   }
/*    */ 
/*    */   public void notifyEvent(OscarConnection connection)
/*    */   {
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.received.usagestats.MinReportInterval__11_2
 * JD-Core Version:    0.6.0
 */