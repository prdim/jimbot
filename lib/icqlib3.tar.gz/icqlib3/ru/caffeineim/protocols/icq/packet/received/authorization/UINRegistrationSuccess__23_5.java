/*    */ package ru.caffeineim.protocols.icq.packet.received.authorization;
/*    */ 
/*    */ import java.util.List;
/*    */ import ru.caffeineim.protocols.icq.RawData;
/*    */ import ru.caffeineim.protocols.icq.core.OscarConnection;
/*    */ import ru.caffeineim.protocols.icq.integration.events.UINRegistrationSuccessEvent;
/*    */ import ru.caffeineim.protocols.icq.integration.listeners.MetaInfoListener;
/*    */ import ru.caffeineim.protocols.icq.packet.received.ReceivedPacket;
/*    */ 
/*    */ public class UINRegistrationSuccess__23_5 extends ReceivedPacket
/*    */ {
/*    */   protected String uin;
/*    */ 
/*    */   public UINRegistrationSuccess__23_5(byte[] array)
/*    */   {
/* 33 */     super(array, true);
/* 34 */     RawData uinData = new RawData(array, 50, 4);
/* 35 */     uinData.invertIndianness();
/* 36 */     this.uin = uinData.toStringValue();
/*    */   }
/*    */ 
/*    */   public String getNewUIN() {
/* 40 */     return this.uin;
/*    */   }
/*    */ 
/*    */   public void notifyEvent(OscarConnection connection) {
/* 44 */     UINRegistrationSuccessEvent e = new UINRegistrationSuccessEvent(this);
/* 45 */     for (int i = 0; i < connection.getMetaInfoListeners().size(); i++) {
/* 46 */       MetaInfoListener l = (MetaInfoListener)connection.getMessagingListeners().get(i);
/* 47 */       l.onRegisterNewUINSuccess(e);
/*    */     }
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.received.authorization.UINRegistrationSuccess__23_5
 * JD-Core Version:    0.6.0
 */