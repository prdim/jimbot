/*    */ package ru.caffeineim.protocols.icq.packet.sent.icbm;
/*    */ 
/*    */ import ru.caffeineim.protocols.icq.Flap;
/*    */ import ru.caffeineim.protocols.icq.RawData;
/*    */ import ru.caffeineim.protocols.icq.Snac;
/*    */ 
/*    */ public class ICBMSetParameters extends Flap
/*    */ {
/*    */   public ICBMSetParameters()
/*    */   {
/* 31 */     super(2);
/* 32 */     Snac snac = new Snac(4, 2, 0, 0, 0);
/* 33 */     snac.addRawDataToSnac(new RawData(0, 2));
/* 34 */     snac.addRawDataToSnac(new RawData(3, 4));
/* 35 */     snac.addRawDataToSnac(new RawData(8000, 2));
/* 36 */     snac.addRawDataToSnac(new RawData(999, 2));
/* 37 */     snac.addRawDataToSnac(new RawData(999, 2));
/* 38 */     snac.addRawDataToSnac(new RawData(0, 2));
/* 39 */     snac.addRawDataToSnac(new RawData(0, 2));
/* 40 */     addSnac(snac);
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.sent.icbm.ICBMSetParameters
 * JD-Core Version:    0.6.0
 */