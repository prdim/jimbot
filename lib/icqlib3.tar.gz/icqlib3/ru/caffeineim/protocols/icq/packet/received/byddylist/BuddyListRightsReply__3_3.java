/*    */ package ru.caffeineim.protocols.icq.packet.received.byddylist;
/*    */ 
/*    */ import ru.caffeineim.protocols.icq.core.OscarConnection;
/*    */ import ru.caffeineim.protocols.icq.packet.received.ReceivedPacket;
/*    */ import ru.caffeineim.protocols.icq.packet.sent.icbm.ICBMRequestParameters;
/*    */ 
/*    */ public class BuddyListRightsReply__3_3 extends ReceivedPacket
/*    */ {
/*    */   public BuddyListRightsReply__3_3(byte[] array)
/*    */   {
/* 29 */     super(array, true);
/*    */   }
/*    */ 
/*    */   public void execute(OscarConnection connection) {
/* 33 */     connection.sendFlap(new ICBMRequestParameters());
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.received.byddylist.BuddyListRightsReply__3_3
 * JD-Core Version:    0.6.0
 */