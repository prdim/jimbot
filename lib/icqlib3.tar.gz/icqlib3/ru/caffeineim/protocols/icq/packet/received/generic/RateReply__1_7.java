/*    */ package ru.caffeineim.protocols.icq.packet.received.generic;
/*    */ 
/*    */ import ru.caffeineim.protocols.icq.core.OscarConnection;
/*    */ import ru.caffeineim.protocols.icq.packet.received.ReceivedPacket;
/*    */ import ru.caffeineim.protocols.icq.packet.sent.generic.RateAcknowledge;
/*    */ import ru.caffeineim.protocols.icq.packet.sent.location.LocationRightsRequest;
/*    */ 
/*    */ public class RateReply__1_7 extends ReceivedPacket
/*    */ {
/*    */   public RateReply__1_7(byte[] array)
/*    */   {
/* 30 */     super(array, true);
/*    */   }
/*    */ 
/*    */   public void execute(OscarConnection connection) {
/* 34 */     connection.sendFlap(new RateAcknowledge());
/* 35 */     connection.sendFlap(new LocationRightsRequest());
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.received.generic.RateReply__1_7
 * JD-Core Version:    0.6.0
 */