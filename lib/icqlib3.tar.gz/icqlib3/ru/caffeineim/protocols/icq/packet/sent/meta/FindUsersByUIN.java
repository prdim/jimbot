/*    */ package ru.caffeineim.protocols.icq.packet.sent.meta;
/*    */ 
/*    */ public class FindUsersByUIN extends RequestUserInfo
/*    */ {
/*    */   public FindUsersByUIN(String uinSearch, String uinForRequest)
/*    */   {
/* 27 */     super(uinSearch, uinForRequest, 1311);
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.sent.meta.FindUsersByUIN
 * JD-Core Version:    0.6.0
 */