/*    */ package ru.caffeineim.protocols.icq.packet.sent.ssi;
/*    */ 
/*    */ import ru.caffeineim.protocols.icq.Flap;
/*    */ import ru.caffeineim.protocols.icq.Snac;
/*    */ 
/*    */ public class SsiBeginEdit extends Flap
/*    */ {
/*    */   public SsiBeginEdit()
/*    */   {
/* 33 */     super(2);
/* 34 */     Snac snac = new Snac(19, 17, 0, 0, 17);
/*    */ 
/* 36 */     addSnac(snac);
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.sent.ssi.SsiBeginEdit
 * JD-Core Version:    0.6.0
 */