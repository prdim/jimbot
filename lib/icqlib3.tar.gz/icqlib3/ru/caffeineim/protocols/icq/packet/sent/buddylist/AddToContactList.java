/*    */ package ru.caffeineim.protocols.icq.packet.sent.buddylist;
/*    */ 
/*    */ import ru.caffeineim.protocols.icq.Flap;
/*    */ import ru.caffeineim.protocols.icq.RawData;
/*    */ import ru.caffeineim.protocols.icq.Snac;
/*    */ 
/*    */ public class AddToContactList extends Flap
/*    */ {
/*    */   public AddToContactList(String uin)
/*    */   {
/* 34 */     super(2);
/* 35 */     Snac snac = new Snac(3, 4, 0, 0, 0);
/*    */ 
/* 38 */     snac.addRawDataToSnac(new RawData(uin.length(), 1));
/*    */ 
/* 41 */     snac.addRawDataToSnac(new RawData(uin));
/*    */ 
/* 43 */     addSnac(snac);
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.sent.buddylist.AddToContactList
 * JD-Core Version:    0.6.0
 */