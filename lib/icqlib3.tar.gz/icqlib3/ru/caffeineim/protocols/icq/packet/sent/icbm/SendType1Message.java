/*    */ package ru.caffeineim.protocols.icq.packet.sent.icbm;
/*    */ 
/*    */ import ru.caffeineim.protocols.icq.RawData;
/*    */ import ru.caffeineim.protocols.icq.Snac;
/*    */ import ru.caffeineim.protocols.icq.Tlv;
/*    */ import ru.caffeineim.protocols.icq.exceptions.ConvertStringException;
/*    */ import ru.caffeineim.protocols.icq.setting.enumerations.MessageChannelEnum;
/*    */ import ru.caffeineim.protocols.icq.tool.StringTools;
/*    */ 
/*    */ public class SendType1Message extends SendMessage
/*    */ {
/*    */   public SendType1Message(String uin, String message)
/*    */     throws ConvertStringException
/*    */   {
/* 32 */     super(uin, new MessageChannelEnum(1));
/*    */ 
/* 35 */     Tlv tlv2 = new Tlv(2);
/*    */ 
/* 38 */     Tlv tlv0501 = new Tlv(262, 2, 1281);
/*    */ 
/* 42 */     Tlv tlv0101 = new Tlv(131072, 4, 257);
/*    */ 
/* 45 */     tlv0101.appendRawDataToTlv(new RawData(StringTools.stringToUcs2beByteArray(message)));
/*    */ 
/* 48 */     tlv2.appendTlvToTlv(tlv0501);
/* 49 */     tlv2.appendTlvToTlv(tlv0101);
/*    */ 
/* 52 */     this.snac.addTlvToSnac(tlv2);
/*    */ 
/* 55 */     this.snac.addRawDataToSnac(new RawData(6, 2));
/* 56 */     this.snac.addRawDataToSnac(new RawData(0, 2));
/*    */ 
/* 58 */     addSnac(this.snac);
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.sent.icbm.SendType1Message
 * JD-Core Version:    0.6.0
 */