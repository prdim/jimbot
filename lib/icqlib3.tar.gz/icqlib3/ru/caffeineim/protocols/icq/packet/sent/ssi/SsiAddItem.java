/*     */ package ru.caffeineim.protocols.icq.packet.sent.ssi;
/*     */ 
/*     */ import ru.caffeineim.protocols.icq.Flap;
/*     */ import ru.caffeineim.protocols.icq.RawData;
/*     */ import ru.caffeineim.protocols.icq.Snac;
/*     */ import ru.caffeineim.protocols.icq.Tlv;
/*     */ import ru.caffeineim.protocols.icq.contacts.Contact;
/*     */ import ru.caffeineim.protocols.icq.contacts.Group;
/*     */ import ru.caffeineim.protocols.icq.exceptions.ConvertStringException;
/*     */ import ru.caffeineim.protocols.icq.tool.StringTools;
/*     */ 
/*     */ public class SsiAddItem extends Flap
/*     */ {
/*     */   public SsiAddItem(Contact cnt)
/*     */     throws ConvertStringException
/*     */   {
/*  38 */     super(2);
/*  39 */     Snac snac = new Snac(19, 8, 0, 0, 8);
/*     */ 
/*  42 */     snac.addRawDataToSnac(new RawData(cnt.getId().length(), 2));
/*     */ 
/*  45 */     snac.addRawDataToSnac(new RawData(cnt.getId()));
/*     */ 
/*  48 */     snac.addRawDataToSnac(new RawData(cnt.getGroupId(), 2));
/*     */ 
/*  51 */     snac.addRawDataToSnac(new RawData(cnt.getItemId(), 2));
/*     */ 
/*  54 */     snac.addRawDataToSnac(new RawData(0, 2));
/*     */ 
/*  56 */     byte[] nick = StringTools.stringToByteArray(cnt.getNickName());
/*     */ 
/*  59 */     snac.addRawDataToSnac(new RawData(20 + nick.length, 2));
/*     */ 
/*  62 */     Tlv tlv1 = new Tlv(305);
/*  63 */     tlv1.appendRawDataToTlv(new RawData(nick));
/*  64 */     snac.addTlvToSnac(tlv1);
/*     */ 
/*  67 */     snac.addTlvToSnac(new Tlv(314));
/*     */ 
/*  70 */     snac.addTlvToSnac(new Tlv(316));
/*     */ 
/*  73 */     snac.addTlvToSnac(new Tlv(311));
/*     */ 
/*  76 */     snac.addTlvToSnac(new Tlv(102));
/*     */ 
/*  78 */     addSnac(snac);
/*     */   }
/*     */ 
/*     */   public SsiAddItem(Group grp)
/*     */     throws ConvertStringException
/*     */   {
/*  86 */     super(2);
/*  87 */     Snac snac = new Snac(19, 8, 0, 0, 8);
/*     */ 
/*  89 */     byte[] groupId = StringTools.stringToByteArray(grp.getId());
/*     */ 
/*  92 */     snac.addRawDataToSnac(new RawData(groupId.length, 2));
/*     */ 
/*  95 */     snac.addRawDataToSnac(new RawData(groupId));
/*     */ 
/*  98 */     snac.addRawDataToSnac(new RawData(grp.getGroupId(), 2));
/*     */ 
/* 101 */     snac.addRawDataToSnac(new RawData(0, 2));
/*     */ 
/* 104 */     snac.addRawDataToSnac(new RawData(1, 2));
/*     */ 
/* 107 */     snac.addRawDataToSnac(new RawData(0, 2));
/*     */ 
/* 109 */     addSnac(snac);
/*     */   }
/*     */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.sent.ssi.SsiAddItem
 * JD-Core Version:    0.6.0
 */