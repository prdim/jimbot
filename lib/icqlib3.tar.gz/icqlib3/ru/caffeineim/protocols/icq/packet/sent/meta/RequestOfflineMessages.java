/*    */ package ru.caffeineim.protocols.icq.packet.sent.meta;
/*    */ 
/*    */ public class RequestOfflineMessages extends BaseClientMeta
/*    */ {
/*    */   protected static final int REQUEST_LENGHT = 2048;
/*    */ 
/*    */   public RequestOfflineMessages(String uinForRequest)
/*    */   {
/* 29 */     super(2048, uinForRequest, 60);
/* 30 */     finalizePacket();
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.sent.meta.RequestOfflineMessages
 * JD-Core Version:    0.6.0
 */