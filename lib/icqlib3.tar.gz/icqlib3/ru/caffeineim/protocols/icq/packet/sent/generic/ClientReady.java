/*    */ package ru.caffeineim.protocols.icq.packet.sent.generic;
/*    */ 
/*    */ import ru.caffeineim.protocols.icq.Flap;
/*    */ import ru.caffeineim.protocols.icq.RawData;
/*    */ import ru.caffeineim.protocols.icq.Snac;
/*    */ 
/*    */ public class ClientReady extends Flap
/*    */ {
/*    */   public ClientReady()
/*    */   {
/* 29 */     super(2);
/* 30 */     Snac snac = new Snac(1, 2, 0, 0, 0);
/*    */ 
/* 33 */     snac.addRawDataToSnac(new RawData(65539, 4));
/* 34 */     snac.addRawDataToSnac(new RawData(17826939, 4));
/*    */ 
/* 37 */     snac.addRawDataToSnac(new RawData(1245186, 4));
/* 38 */     snac.addRawDataToSnac(new RawData(17826939, 4));
/*    */ 
/* 41 */     snac.addRawDataToSnac(new RawData(131073, 4));
/* 42 */     snac.addRawDataToSnac(new RawData(16843899, 4));
/*    */ 
/* 45 */     snac.addRawDataToSnac(new RawData(196609, 4));
/* 46 */     snac.addRawDataToSnac(new RawData(17826939, 4));
/*    */ 
/* 49 */     snac.addRawDataToSnac(new RawData(1376257, 4));
/* 50 */     snac.addRawDataToSnac(new RawData(17826939, 4));
/*    */ 
/* 53 */     snac.addRawDataToSnac(new RawData(262145, 4));
/* 54 */     snac.addRawDataToSnac(new RawData(17826939, 4));
/*    */ 
/* 57 */     snac.addRawDataToSnac(new RawData(393217, 4));
/* 58 */     snac.addRawDataToSnac(new RawData(17826939, 4));
/*    */ 
/* 61 */     snac.addRawDataToSnac(new RawData(589825, 4));
/* 62 */     snac.addRawDataToSnac(new RawData(17826939, 4));
/*    */ 
/* 65 */     snac.addRawDataToSnac(new RawData(655361, 4));
/* 66 */     snac.addRawDataToSnac(new RawData(17826939, 4));
/*    */ 
/* 69 */     snac.addRawDataToSnac(new RawData(720897, 4));
/* 70 */     snac.addRawDataToSnac(new RawData(17826939, 4));
/*    */ 
/* 72 */     addSnac(snac);
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.sent.generic.ClientReady
 * JD-Core Version:    0.6.0
 */