/*    */ package ru.caffeineim.protocols.icq.packet.received.icbm;
/*    */ 
/*    */ import ru.caffeineim.protocols.icq.RawData;
/*    */ import ru.caffeineim.protocols.icq.Snac;
/*    */ import ru.caffeineim.protocols.icq.core.OscarConnection;
/*    */ import ru.caffeineim.protocols.icq.packet.received.ReceivedPacket;
/*    */ 
/*    */ public class TypingNotif__4_20 extends ReceivedPacket
/*    */ {
/*    */   public static final short TYPING_FINISHED = 0;
/*    */   public static final short TYPING_CURRENT = 1;
/*    */   public static final short TYPING_BEGIN = 2;
/*    */   private RawData uin;
/*    */   private RawData type;
/*    */ 
/*    */   public TypingNotif__4_20(byte[] array)
/*    */   {
/* 37 */     super(array, true);
/* 38 */     byte[] data = getSnac().getByteArray();
/*    */ 
/* 40 */     int index = 0;
/* 41 */     RawData id = new RawData(data, index, 8);
/* 42 */     index += 8;
/* 43 */     RawData channel = new RawData(data, index, 2);
/* 44 */     index += 2;
/* 45 */     RawData uinLg = new RawData(data, index++, 1);
/* 46 */     this.uin = new RawData(data, index, uinLg.getValue());
/* 47 */     index += uinLg.getValue();
/* 48 */     this.type = new RawData(data, index, 2);
/*    */   }
/*    */ 
/*    */   public void notifyEvent(OscarConnection connection)
/*    */   {
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.received.icbm.TypingNotif__4_20
 * JD-Core Version:    0.6.0
 */