/*    */ package ru.caffeineim.protocols.icq.packet.received.byddylist;
/*    */ 
/*    */ import ru.caffeineim.protocols.icq.Snac;
/*    */ import ru.caffeineim.protocols.icq.core.OscarConnection;
/*    */ import ru.caffeineim.protocols.icq.packet.received.ReceivedPacket;
/*    */ 
/*    */ public class RefusedContact__3_10 extends ReceivedPacket
/*    */ {
/*    */   private String ref;
/*    */ 
/*    */   public RefusedContact__3_10(byte[] array)
/*    */   {
/* 30 */     super(array, true);
/* 31 */     this.ref = null;
/* 32 */     byte[] data = getSnac().getDataFieldByteArray();
/* 33 */     this.ref = new String(data, 1, data.length - 1);
/*    */   }
/*    */ 
/*    */   public void execute(OscarConnection oscarconnection)
/*    */   {
/*    */   }
/*    */ 
/*    */   public void notifyEvent(OscarConnection connection)
/*    */   {
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.received.byddylist.RefusedContact__3_10
 * JD-Core Version:    0.6.0
 */