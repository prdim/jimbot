/*    */ package ru.caffeineim.protocols.icq.packet.sent.ssi;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import ru.caffeineim.protocols.icq.Flap;
/*    */ import ru.caffeineim.protocols.icq.RawData;
/*    */ import ru.caffeineim.protocols.icq.Snac;
/*    */ import ru.caffeineim.protocols.icq.Tlv;
/*    */ import ru.caffeineim.protocols.icq.contacts.Contact;
/*    */ import ru.caffeineim.protocols.icq.contacts.Group;
/*    */ import ru.caffeineim.protocols.icq.exceptions.ConvertStringException;
/*    */ import ru.caffeineim.protocols.icq.tool.StringTools;
/*    */ 
/*    */ public class SsiRemoveItem extends Flap
/*    */ {
/*    */   public SsiRemoveItem(Contact item)
/*    */   {
/* 37 */     super(2);
/* 38 */     Snac snac = new Snac(19, 10, 0, 0, 10);
/* 39 */     deleteContact(item, snac);
/* 40 */     addSnac(snac);
/*    */   }
/*    */ 
/*    */   public SsiRemoveItem(Group grp) throws ConvertStringException {
/* 44 */     super(2);
/* 45 */     Snac snac = new Snac(19, 10, 0, 0, 10);
/*    */ 
/* 47 */     byte[] groupId = StringTools.stringToByteArray(grp.getId());
/*    */ 
/* 50 */     snac.addRawDataToSnac(new RawData(groupId.length, 2));
/*    */ 
/* 53 */     snac.addRawDataToSnac(new RawData(groupId));
/*    */ 
/* 56 */     snac.addRawDataToSnac(new RawData(grp.getGroupId(), 2));
/*    */ 
/* 59 */     snac.addRawDataToSnac(new RawData(grp.getItemId(), 2));
/*    */ 
/* 62 */     snac.addRawDataToSnac(new RawData(1, 2));
/*    */ 
/* 65 */     snac.addRawDataToSnac(new RawData(4, 2));
/*    */ 
/* 68 */     Tlv tlv = new Tlv(200);
/* 69 */     snac.addTlvToSnac(tlv);
/*    */ 
/* 72 */     for (Iterator iter = grp.getContainedItems().iterator(); iter.hasNext(); ) {
/* 73 */       deleteContact((Contact)iter.next(), snac);
/*    */     }
/*    */ 
/* 76 */     addSnac(snac);
/*    */   }
/*    */ 
/*    */   private void deleteContact(Contact item, Snac snac)
/*    */   {
/* 81 */     snac.addRawDataToSnac(new RawData(item.getId().length(), 2));
/*    */ 
/* 84 */     snac.addRawDataToSnac(new RawData(item.getId()));
/*    */ 
/* 87 */     snac.addRawDataToSnac(new RawData(item.getGroupId(), 2));
/*    */ 
/* 90 */     snac.addRawDataToSnac(new RawData(item.getItemId(), 2));
/*    */ 
/* 93 */     snac.addRawDataToSnac(new RawData(0, 2));
/*    */ 
/* 96 */     snac.addRawDataToSnac(new RawData(0, 2));
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.sent.ssi.SsiRemoveItem
 * JD-Core Version:    0.6.0
 */