/*    */ package ru.caffeineim.protocols.icq.packet.received.meta;
/*    */ 
/*    */ import ru.caffeineim.protocols.icq.RawData;
/*    */ import ru.caffeineim.protocols.icq.Snac;
/*    */ import ru.caffeineim.protocols.icq.core.OscarConnection;
/*    */ import ru.caffeineim.protocols.icq.exceptions.ConvertStringException;
/*    */ import ru.caffeineim.protocols.icq.metainfo.IMetaInfoParser;
/*    */ import ru.caffeineim.protocols.icq.metainfo.MetaInfoParserFactory;
/*    */ import ru.caffeineim.protocols.icq.packet.received.ReceivedPacket;
/*    */ 
/*    */ public class ServerMetaReply__21_3 extends ReceivedPacket
/*    */ {
/* 33 */   private int metaType = 0;
/* 34 */   private int metaSubType = 0;
/*    */ 
/* 36 */   private IMetaInfoParser metaInfoParser = null;
/*    */ 
/*    */   public ServerMetaReply__21_3(byte[] array) throws ConvertStringException {
/* 39 */     super(array, true);
/*    */ 
/* 41 */     int position = 0;
/* 42 */     byte[] data = getSnac().getDataFieldByteArray();
/*    */ 
/* 45 */     position += 10;
/*    */ 
/* 48 */     RawData rdMetaType = new RawData(data, position, 2);
/* 49 */     rdMetaType.invertIndianness();
/* 50 */     this.metaType = rdMetaType.getValue();
/* 51 */     position += 2;
/*    */ 
/* 55 */     position += 2;
/*    */ 
/* 58 */     if (this.metaType == 2010) {
/* 59 */       RawData metaSubTypeRD = new RawData(data, position, 2);
/* 60 */       metaSubTypeRD.invertIndianness();
/* 61 */       this.metaSubType = metaSubTypeRD.getValue();
/*    */     }
/*    */ 
/* 65 */     this.metaInfoParser = MetaInfoParserFactory.buildMetaInfoParser(this.metaType, this.metaSubType);
/*    */ 
/* 68 */     if (this.metaInfoParser != null)
/* 69 */       this.metaInfoParser.parse(data, position);
/*    */   }
/*    */ 
/*    */   public void execute(OscarConnection connection) {
/* 73 */     if (this.metaInfoParser != null)
/* 74 */       this.metaInfoParser.execute(connection);
/*    */   }
/*    */ 
/*    */   public void notifyEvent(OscarConnection connection) {
/* 78 */     if (this.metaInfoParser != null)
/* 79 */       this.metaInfoParser.notifyEvent(connection);
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.received.meta.ServerMetaReply__21_3
 * JD-Core Version:    0.6.0
 */