/*     */ package ru.caffeineim.protocols.icq.packet.sent.generic;
/*     */ 
/*     */ import ru.caffeineim.protocols.icq.Flap;
/*     */ import ru.caffeineim.protocols.icq.RawData;
/*     */ import ru.caffeineim.protocols.icq.Tlv;
/*     */ 
/*     */ public class AuthorizationRequest extends Flap
/*     */ {
/*     */   private AuthorizationRequest()
/*     */   {
/*  30 */     super(1);
/*     */   }
/*     */ 
/*     */   public AuthorizationRequest(String Uin, String password)
/*     */   {
/*  43 */     this(Uin, password, "ICQBasic", 20, 52, 0, 2, "en", "us");
/*     */   }
/*     */ 
/*     */   public AuthorizationRequest(String Uin, String password, String clientProfile, int majorVersion, int minorVersion, int lesserVersion, int buildNumber, String language, String country)
/*     */   {
/*  63 */     this();
/*     */ 
/*  67 */     addRawDataToFlap(new RawData(1, 4));
/*     */ 
/*  69 */     addTlvToFlap(new Tlv(Uin, 1));
/*     */ 
/*  71 */     addTlvToFlap(new Tlv(encryptPassword(password), 2));
/*     */ 
/*  73 */     addTlvToFlap(new Tlv(clientProfile, 3));
/*     */ 
/*  75 */     addTlvToFlap(new Tlv(266, 22));
/*     */ 
/*  77 */     addTlvToFlap(new Tlv(majorVersion, 2, 23));
/*     */ 
/*  79 */     addTlvToFlap(new Tlv(minorVersion, 2, 24));
/*     */ 
/*  81 */     addTlvToFlap(new Tlv(lesserVersion, 2, 25));
/*     */ 
/*  83 */     addTlvToFlap(new Tlv(buildNumber, 2, 26));
/*     */ 
/*  85 */     addTlvToFlap(new Tlv(1085, 4, 20));
/*     */ 
/*  87 */     addTlvToFlap(new Tlv(language, 15));
/*     */ 
/*  89 */     addTlvToFlap(new Tlv(country, 14));
/*     */   }
/*     */ 
/*     */   private String encryptPassword(String password)
/*     */   {
/* 100 */     byte[] bytePassword = password.getBytes();
/* 101 */     char[] charPass = new char[bytePassword.length];
/* 102 */     byte[] xorValues = { -13, 38, -127, -60, 57, -122, -37, -110 };
/*     */ 
/* 105 */     int i = 0; for (int j = 0; i < bytePassword.length; j++) {
/* 106 */       if (j >= xorValues.length) {
/* 107 */         j = 0;
/*     */       }
/* 109 */       charPass[i] = (char)((char)bytePassword[i] ^ (char)xorValues[j]);
/*     */ 
/* 105 */       i++;
/*     */     }
/*     */ 
/* 112 */     return new String(charPass);
/*     */   }
/*     */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.sent.generic.AuthorizationRequest
 * JD-Core Version:    0.6.0
 */