/*    */ package ru.caffeineim.protocols.icq.packet.received.generic;
/*    */ 
/*    */ import ru.caffeineim.protocols.icq.core.OscarConnection;
/*    */ import ru.caffeineim.protocols.icq.packet.received.ReceivedPacket;
/*    */ import ru.caffeineim.protocols.icq.packet.sent.generic.RateRequest;
/*    */ 
/*    */ public class ServerFamilies__1_24 extends ReceivedPacket
/*    */ {
/*    */   public ServerFamilies__1_24(byte[] array)
/*    */   {
/* 29 */     super(array, true);
/*    */   }
/*    */ 
/*    */   public void execute(OscarConnection connection) throws Exception {
/* 33 */     connection.sendFlap(new RateRequest());
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.received.generic.ServerFamilies__1_24
 * JD-Core Version:    0.6.0
 */