/*    */ package ru.caffeineim.protocols.icq.packet.sent.meta;
/*    */ 
/*    */ public class AckOfflineMessages extends BaseClientMeta
/*    */ {
/*    */   protected static final int REQUEST_LENGHT = 2048;
/*    */ 
/*    */   public AckOfflineMessages(String uinForRequest)
/*    */   {
/* 29 */     super(2048, uinForRequest, 62);
/* 30 */     finalizePacket();
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.sent.meta.AckOfflineMessages
 * JD-Core Version:    0.6.0
 */