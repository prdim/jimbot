/*     */ package ru.caffeineim.protocols.icq.packet.sent.meta;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import ru.caffeineim.protocols.icq.tool.CharSetUtils;
/*     */ import ru.caffeineim.protocols.icq.tool.ProtocolUtils;
/*     */ 
/*     */ public class FullUserInfo
/*     */ {
/*     */   public static final short TLV_TYPE_FIRST_NAME = 320;
/*     */   public static final short TLV_TYPE_LAST_NAME = 330;
/*     */   public static final short TLV_TYPE_NICK_NAME = 340;
/*     */   public static final short TLV_TYPE_EMAIL = 350;
/*     */   public static final short TLV_TYPE_AGE = 370;
/*     */   public static final short TLV_TYPE_GENDER = 380;
/*     */   public static final short TLV_TYPE_HOME_CITY = 400;
/*     */   public static final short TLV_TYPE_HOME_STATE = 410;
/*     */   public static final short TLV_TYPE_HOME_COUNTRY = 420;
/*     */   public static final short TLV_TYPE_COMPANY_NAME = 430;
/*     */   public static final short TLV_TYPE_DEPARTAMENT_NAME = 440;
/*     */   public static final short TLV_TYPE_WORK_TITLE = 450;
/*     */   public static final short TLV_TYPE_WORK_OCCUPATION_CODE = 460;
/*     */   public static final short TLV_TYPE_AFFILATIONS_CODE = 470;
/*     */   public static final short TLV_TYPE_INTERESTS_NODE = 490;
/*     */   public static final short TLV_TYPE_PAST_INFO_NODE = 510;
/*     */   public static final short TLV_TYPE_HOME_PAGE_CATEGORY = 530;
/*     */   public static final short TLV_TYPE_PHOME_PAGE_URL = 531;
/*     */   public static final short TLV_TYPE_BIRTHDAY = 570;
/*     */   public static final short TLV_TYPE_NOTES = 600;
/*     */   public static final short TLV_TYPE_HOME_ADDRESS = 610;
/*     */   public static final short TLV_TYPE_HOME_ZIP_CODE = 620;
/*     */   public static final short TLV_TYPE_HOME_PHONE_NUMBER = 630;
/*     */   public static final short TLV_TYPE_HOME_FAX_NUMBER = 640;
/*     */   public static final short TLV_TYPE_HOME_CELL_PHONE = 650;
/*     */   public static final short TLV_TYPE_WORK_STREET_ADDRESS = 660;
/*     */   public static final short TLV_TYPE_WORK_CITY = 670;
/*     */   public static final short TLV_TYPE_WORK_STATE = 680;
/*     */   public static final short TLV_TYPE_WORK_COUNTRY = 690;
/*     */   public static final short TLV_TYPE_WORK_ZIP_CODE = 700;
/*     */   public static final short TLV_TYPE_WORK_PHONE_NUMBER = 710;
/*     */   public static final short TLV_TYPE_WORK_FAX = 720;
/*     */   public static final short TLV_TYPE_WORK_URL = 730;
/*     */   public static final short TLV_TYPE_AUTHORIZATION = 780;
/*     */   public static final short TLV_TYPE_GMT_OFFSET = 790;
/*     */   public static final short TLV_TYPE_FROM_CITY = 800;
/*     */   public static final short TLV_TYPE_FROM_STATE = 810;
/*     */   public static final short TLV_TYPE_FROM_COUNTRY = 820;
/*     */   public static final short TLV_TYPE_WEBAWARE = 760;
/*  48 */   byte age = 0;
/*  49 */   byte webaware = -1;
/*  50 */   byte auth = -1;
/*  51 */   String nick = null;
/*  52 */   String firstName = null;
/*  53 */   String lastName = null;
/*  54 */   String eMail = null;
/*  55 */   String city = null;
/*  56 */   String state = null;
/*  57 */   String phone = null;
/*  58 */   String fax = null;
/*  59 */   String homeAddress = null;
/*  60 */   String cellPhone = null;
/*  61 */   String zipCode = null;
/*  62 */   String nota = null;
/*     */   short bYear;
/*     */   short bMounth;
/*     */   short bDay;
/*     */   short countryCode;
/*  67 */   byte GMTOffset = -1;
/*  68 */   byte authorization = -1;
/*     */   byte publishEmail;
/*     */ 
/*     */   public void setWebAware(boolean b)
/*     */   {
/*  73 */     this.webaware = (byte)(b ? 1 : 0);
/*     */   }
/*     */ 
/*     */   public void setAuthNeed(boolean b) {
/*  77 */     this.auth = (byte)(b ? 1 : 0);
/*     */   }
/*     */ 
/*     */   public void setBYear(short bYear) {
/*  81 */     this.bYear = bYear;
/*     */   }
/*     */ 
/*     */   public void setBMounth(short bMounth) {
/*  85 */     this.bMounth = bMounth;
/*     */   }
/*     */ 
/*     */   public void setBDay(short bDay) {
/*  89 */     this.bDay = bDay;
/*     */   }
/*     */ 
/*     */   public String getNick()
/*     */   {
/*  94 */     return this.nick;
/*     */   }
/*     */ 
/*     */   public String getFirstName() {
/*  98 */     return this.firstName;
/*     */   }
/*     */ 
/*     */   public String getLastName() {
/* 102 */     return this.lastName;
/*     */   }
/*     */ 
/*     */   public String getEMail() {
/* 106 */     return this.eMail;
/*     */   }
/*     */ 
/*     */   public byte getWebAware() {
/* 110 */     return this.webaware;
/*     */   }
/*     */ 
/*     */   public byte getAuthNeed() {
/* 114 */     return this.authorization;
/*     */   }
/*     */ 
/*     */   public String getCity() {
/* 118 */     return this.city;
/*     */   }
/*     */ 
/*     */   public String getState() {
/* 122 */     return this.state;
/*     */   }
/*     */ 
/*     */   public String getPhone() {
/* 126 */     return this.phone;
/*     */   }
/*     */ 
/*     */   public String getFax() {
/* 130 */     return this.fax;
/*     */   }
/*     */ 
/*     */   public String getHomeAddress() {
/* 134 */     return this.homeAddress;
/*     */   }
/*     */ 
/*     */   public String getCellPhone() {
/* 138 */     return this.cellPhone;
/*     */   }
/*     */ 
/*     */   public String getZipCode() {
/* 142 */     return this.zipCode;
/*     */   }
/*     */ 
/*     */   public short getCountryCode() {
/* 146 */     return this.countryCode;
/*     */   }
/*     */ 
/*     */   public byte getGMTOffset() {
/* 150 */     return this.GMTOffset;
/*     */   }
/*     */ 
/*     */   public String getNotes()
/*     */   {
/* 155 */     return this.nota;
/*     */   }
/*     */ 
/*     */   public byte getPublishEmail()
/*     */   {
/* 160 */     return this.publishEmail;
/*     */   }
/*     */ 
/*     */   public void setNick(String nick)
/*     */   {
/* 165 */     this.nick = nick;
/*     */   }
/*     */ 
/*     */   public void setFirstName(String firstName) {
/* 169 */     this.firstName = firstName;
/*     */   }
/*     */ 
/*     */   public void setLastName(String lastName) {
/* 173 */     this.lastName = lastName;
/*     */   }
/*     */ 
/*     */   public void setEMail(String eMail) {
/* 177 */     this.eMail = eMail;
/*     */   }
/*     */ 
/*     */   public void setCity(String city) {
/* 181 */     this.city = city;
/*     */   }
/*     */ 
/*     */   public void setState(String state) {
/* 185 */     this.state = state;
/*     */   }
/*     */ 
/*     */   public void setPhone(String phone) {
/* 189 */     this.phone = phone;
/*     */   }
/*     */ 
/*     */   public void setFax(String fax) {
/* 193 */     this.fax = fax;
/*     */   }
/*     */ 
/*     */   public void setNotes(String note) {
/* 197 */     this.nota = note;
/*     */   }
/*     */ 
/*     */   public void setHomeAddress(String homeAddress) {
/* 201 */     this.homeAddress = homeAddress;
/*     */   }
/*     */ 
/*     */   public void setCellPhone(String cellPhone) {
/* 205 */     this.cellPhone = cellPhone;
/*     */   }
/*     */ 
/*     */   public void setZipCode(String zipCode) {
/* 209 */     this.zipCode = zipCode;
/*     */   }
/*     */ 
/*     */   public void setCountryCode(short countryCode) {
/* 213 */     this.countryCode = countryCode;
/*     */   }
/*     */ 
/*     */   public void setGMTOffset(byte GMTOffset) {
/* 217 */     this.GMTOffset = GMTOffset;
/*     */   }
/*     */ 
/*     */   public void setPublishEmail(byte publishEmail) {
/* 221 */     this.publishEmail = publishEmail;
/*     */   }
/*     */ 
/*     */   public void setAge(byte age) {
/* 225 */     this.age = age;
/*     */   }
/*     */ 
/*     */   private void appendString(ArrayList<Byte> data, String s)
/*     */   {
/* 230 */     ProtocolUtils.appendLeftShort(data, (short)(s.length() + 1));
/* 231 */     ProtocolUtils.appendBytes(data, CharSetUtils.UNICODEtoCP_1251_8(s));
/* 232 */     ProtocolUtils.appendByte(data, (byte)0);
/*     */   }
/*     */ 
/*     */   private void appendStringTLV(ArrayList<Byte> data, int tlvType, String s)
/*     */   {
/* 237 */     ProtocolUtils.appendLeftShort(data, (short)tlvType);
/* 238 */     ProtocolUtils.appendLeftShort(data, (short)(s.length() + 3));
/* 239 */     ProtocolUtils.appendLeftShort(data, (short)(s.length() + 1));
/* 240 */     ProtocolUtils.appendBytes(data, CharSetUtils.UNICODEtoCP_1251_8(s));
/* 241 */     ProtocolUtils.appendByte(data, (byte)0);
/*     */   }
/*     */ 
/*     */   public int getlenght() {
/* 245 */     int a = 0;
/* 246 */     if (this.nick != null) {
/* 247 */       a += 5 + this.nick.length();
/*     */     }
/* 249 */     if (this.firstName != null) {
/* 250 */       a += 5 + this.eMail.length();
/*     */     }
/* 252 */     if (this.firstName != null) {
/* 253 */       a += 5 + this.eMail.length();
/*     */     }
/* 255 */     if (this.eMail != null) {
/* 256 */       a += 5 + this.eMail.length();
/*     */     }
/* 258 */     if (this.city != null) {
/* 259 */       a += 5 + this.city.length();
/*     */     }
/* 261 */     if (this.state != null) {
/* 262 */       a += 5 + this.state.length();
/*     */     }
/* 264 */     if (this.phone != null) {
/* 265 */       a += 5 + this.phone.length();
/*     */     }
/* 267 */     if (this.fax != null) {
/* 268 */       a += 5 + this.fax.length();
/*     */     }
/* 270 */     if (this.homeAddress != null) {
/* 271 */       a += 5 + this.homeAddress.length();
/*     */     }
/* 273 */     if (this.cellPhone != null) {
/* 274 */       a += 17;
/*     */     }
/* 276 */     if (this.auth != -1) {
/* 277 */       a += 5;
/*     */     }
/*     */ 
/* 280 */     if ((this.bYear != 0) && (this.bMounth != 0) && (this.bDay != 0)) {
/* 281 */       a += 12;
/*     */     }
/*     */ 
/* 284 */     if (this.nota != null) {
/* 285 */       a += this.nota.length() + 5;
/*     */     }
/*     */ 
/* 288 */     if (this.GMTOffset != -1) {
/* 289 */       a += 8;
/*     */     }
/* 291 */     if (this.webaware != -1) {
/* 292 */       a += 5;
/*     */     }
/* 294 */     if (this.authorization != -1) {
/* 295 */       a += 5;
/*     */     }
/* 297 */     return a;
/*     */   }
/*     */ 
/*     */   public ArrayList<Byte> pack()
/*     */   {
/* 302 */     ArrayList data = new ArrayList(getlenght());
/* 303 */     if (this.nick != null) {
/* 304 */       appendStringTLV(data, 340, this.nick);
/*     */     }
/* 306 */     if (this.firstName != null) {
/* 307 */       appendStringTLV(data, 320, this.firstName);
/*     */     }
/* 309 */     if (this.lastName != null) {
/* 310 */       appendStringTLV(data, 330, this.lastName);
/*     */     }
/* 312 */     if (this.eMail != null) {
/* 313 */       appendStringTLV(data, 350, this.eMail);
/*     */     }
/* 315 */     if (this.city != null) {
/* 316 */       appendStringTLV(data, 400, this.city);
/*     */     }
/* 318 */     if (this.state != null) {
/* 319 */       appendStringTLV(data, 410, this.state);
/*     */     }
/* 321 */     if (this.phone != null) {
/* 322 */       appendStringTLV(data, 630, this.phone);
/*     */     }
/* 324 */     if (this.fax != null) {
/* 325 */       appendStringTLV(data, 640, this.fax);
/*     */     }
/* 327 */     if (this.homeAddress != null) {
/* 328 */       appendStringTLV(data, 610, this.homeAddress);
/*     */     }
/* 330 */     if (this.cellPhone != null) {
/* 331 */       appendStringTLV(data, 650, this.cellPhone);
/*     */     }
/* 333 */     if (this.auth != -1) {
/* 334 */       ProtocolUtils.appendLeftShort(data, (short)780);
/* 335 */       ProtocolUtils.appendLeftShort(data, (short)1);
/* 336 */       ProtocolUtils.appendByte(data, Byte.valueOf(this.auth).byteValue());
/*     */     }
/*     */ 
/* 339 */     if ((this.bYear != 0) && (this.bMounth != 0) && (this.bDay != 0)) {
/* 340 */       ProtocolUtils.appendLeftShort(data, (short)570);
/* 341 */       ProtocolUtils.appendLeftShort(data, (short)6);
/* 342 */       ProtocolUtils.appendLeftShort(data, this.bYear);
/* 343 */       ProtocolUtils.appendLeftShort(data, this.bMounth);
/* 344 */       ProtocolUtils.appendLeftShort(data, this.bDay);
/*     */     }
/*     */ 
/* 347 */     if (this.nota != null) {
/* 348 */       appendStringTLV(data, 600, this.nota);
/*     */     }
/*     */ 
/* 351 */     if (this.GMTOffset != -1) {
/* 352 */       ProtocolUtils.appendLeftShort(data, (short)790);
/* 353 */       ProtocolUtils.appendLeftShort(data, (short)1);
/* 354 */       ProtocolUtils.appendByte(data, Byte.valueOf(this.GMTOffset).byteValue());
/*     */     }
/* 356 */     if (this.webaware != -1) {
/* 357 */       ProtocolUtils.appendLeftShort(data, (short)760);
/* 358 */       ProtocolUtils.appendLeftShort(data, (short)1);
/* 359 */       ProtocolUtils.appendByte(data, Byte.valueOf(this.webaware).byteValue());
/*     */     }
/* 361 */     if (this.authorization != -1) {
/* 362 */       ProtocolUtils.appendLeftShort(data, (short)780);
/* 363 */       ProtocolUtils.appendLeftShort(data, (short)1);
/* 364 */       ProtocolUtils.appendByte(data, Byte.valueOf(this.authorization).byteValue());
/*     */     }
/*     */ 
/* 367 */     return data;
/*     */   }
/*     */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.sent.meta.FullUserInfo
 * JD-Core Version:    0.6.0
 */