/*    */ package ru.caffeineim.protocols.icq.packet.sent.meta;
/*    */ 
/*    */ public class RequestShortUserInfo extends RequestUserInfo
/*    */ {
/*    */   public RequestShortUserInfo(String uinSearch, String uinForRequest)
/*    */   {
/* 32 */     super(uinSearch, uinForRequest, 1210);
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.sent.meta.RequestShortUserInfo
 * JD-Core Version:    0.6.0
 */