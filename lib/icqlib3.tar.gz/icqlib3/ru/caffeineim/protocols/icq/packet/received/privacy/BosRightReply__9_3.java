/*    */ package ru.caffeineim.protocols.icq.packet.received.privacy;
/*    */ 
/*    */ import ru.caffeineim.protocols.icq.core.OscarClient;
/*    */ import ru.caffeineim.protocols.icq.core.OscarConnection;
/*    */ import ru.caffeineim.protocols.icq.packet.received.ReceivedPacket;
/*    */ import ru.caffeineim.protocols.icq.packet.sent.generic.ClientReady;
/*    */ import ru.caffeineim.protocols.icq.packet.sent.generic.SetICQStatus;
/*    */ import ru.caffeineim.protocols.icq.setting.Tweaker;
/*    */ import ru.caffeineim.protocols.icq.setting.enumerations.StatusModeEnum;
/*    */ 
/*    */ public class BosRightReply__9_3 extends ReceivedPacket
/*    */ {
/*    */   public BosRightReply__9_3(byte[] array)
/*    */   {
/* 30 */     super(array, true);
/*    */   }
/*    */ 
/*    */   public void execute(OscarConnection connection) {
/* 34 */     connection.sendFlap(new SetICQStatus(connection.getTweaker().getInitialStatusMode().getMode(), connection.getTweaker().getInitialStatusFlags(), connection.getTweaker().getTcpConnectionFlag(), connection.getClient().getInetaddress(), connection.getTweaker().getP2PPortListening()));
/*    */ 
/* 40 */     connection.sendFlap(new ClientReady());
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.received.privacy.BosRightReply__9_3
 * JD-Core Version:    0.6.0
 */