/*    */ package ru.caffeineim.protocols.icq.packet.sent.privacy;
/*    */ 
/*    */ import ru.caffeineim.protocols.icq.Flap;
/*    */ import ru.caffeineim.protocols.icq.RawData;
/*    */ import ru.caffeineim.protocols.icq.Snac;
/*    */ 
/*    */ public class SetPrivateStatus extends Flap
/*    */ {
/*    */   public SetPrivateStatus(String UIN, byte privateStatus)
/*    */   {
/* 16 */     super(2);
/*    */ 
/* 19 */     Snac snac = new Snac(19, 9, 0, 0, 9);
/* 20 */     snac.addDataField(new RawData(new byte[] { 0, 0, 0, 0 }));
/* 21 */     snac.addDataField(new RawData(1573, 2));
/*    */ 
/* 23 */     snac.addDataField(new RawData(new byte[] { 0, 4, 0, 33, 0, -54, 0, 1 }));
/*    */ 
/* 25 */     snac.addDataField(new RawData(privateStatus, 1));
/* 26 */     snac.addDataField(new RawData(new byte[] { 0, -48, 0, 1, 1, 0, -47, 0, 1, 1, 0, -46, 0, 1, 1, 0, -45, 0, 1, 1, 0, -53, 0, 4, -1, -1, -1, -1 }));
/*    */ 
/* 49 */     addSnac(snac);
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.sent.privacy.SetPrivateStatus
 * JD-Core Version:    0.6.0
 */