/*    */ package ru.caffeineim.protocols.icq.packet.received.meta;
/*    */ 
/*    */ import ru.caffeineim.protocols.icq.RawData;
/*    */ import ru.caffeineim.protocols.icq.Snac;
/*    */ import ru.caffeineim.protocols.icq.core.OscarConnection;
/*    */ import ru.caffeineim.protocols.icq.packet.received.ReceivedPacket;
/*    */ 
/*    */ public class MetaError__21_1 extends ReceivedPacket
/*    */ {
/*    */   private RawData errorCode;
/*    */ 
/*    */   public MetaError__21_1(byte[] array)
/*    */   {
/* 34 */     super(array, true);
/* 35 */     byte[] data = getSnac().getDataFieldByteArray();
/* 36 */     this.errorCode = new RawData(data, 0, 2);
/*    */   }
/*    */ 
/*    */   public void execute(OscarConnection connection) throws Exception {
/* 40 */     throw new Exception("Received 21-1, error code " + this.errorCode.getValue());
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.received.meta.MetaError__21_1
 * JD-Core Version:    0.6.0
 */