/*    */ package ru.caffeineim.protocols.icq.packet.received.generic;
/*    */ 
/*    */ import java.util.List;
/*    */ import ru.caffeineim.protocols.icq.RawData;
/*    */ import ru.caffeineim.protocols.icq.Snac;
/*    */ import ru.caffeineim.protocols.icq.Tlv;
/*    */ import ru.caffeineim.protocols.icq.core.OscarConnection;
/*    */ import ru.caffeineim.protocols.icq.integration.events.StatusEvent;
/*    */ import ru.caffeineim.protocols.icq.integration.listeners.OurStatusListener;
/*    */ import ru.caffeineim.protocols.icq.packet.received.ReceivedPacket;
/*    */ 
/*    */ public class OnlineInfoResp__1_15 extends ReceivedPacket
/*    */ {
/* 32 */   private int status = 0;
/*    */ 
/*    */   public OnlineInfoResp__1_15(byte[] array)
/*    */   {
/* 38 */     super(array, true);
/* 39 */     int index = 0;
/* 40 */     Snac snac = getSnac();
/* 41 */     byte[] data = snac.getDataFieldByteArray();
/* 42 */     if ((snac.getFlag0() & 0x80) != 0) {
/* 43 */       int unknownDataLen = new RawData(data, index, 2).getValue();
/* 44 */       index += unknownDataLen + 2;
/*    */     }
/* 46 */     int uinLg = new RawData(data, index, 1).getValue();
/* 47 */     index++;
/* 48 */     String uin = new RawData(data, index, uinLg).getStringValue();
/* 49 */     index += uin.length();
/* 50 */     int warnLvl = new RawData(data, index, 2).getValue();
/* 51 */     index += 2;
/* 52 */     int tlvNb = new RawData(data, index, 2).getValue();
/* 53 */     index += 2;
/* 54 */     for (int i = 0; i < tlvNb; i++) {
/* 55 */       Tlv tlvi = new Tlv(data, index);
/* 56 */       if (6 == tlvi.getType()) {
/* 57 */         this.status = tlvi.getValue();
/*    */       }
/* 59 */       index += tlvi.getLength() + 4;
/*    */     }
/*    */   }
/*    */ 
/*    */   public int getStatusFlag() {
/* 64 */     return this.status & 0xFFFF0000;
/*    */   }
/*    */ 
/*    */   public int getStatusMode() {
/* 68 */     return this.status & 0xFFFF;
/*    */   }
/*    */ 
/*    */   public void execute(OscarConnection connection) throws Exception {
/*    */   }
/*    */ 
/*    */   public void notifyEvent(OscarConnection connection) {
/* 75 */     StatusEvent e = new StatusEvent(this);
/* 76 */     for (int i = 0; i < connection.getOurStatusListeners().size(); i++) {
/* 77 */       OurStatusListener l = (OurStatusListener)connection.getOurStatusListeners().get(i);
/* 78 */       l.onStatusResponse(e);
/*    */     }
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.received.generic.OnlineInfoResp__1_15
 * JD-Core Version:    0.6.0
 */