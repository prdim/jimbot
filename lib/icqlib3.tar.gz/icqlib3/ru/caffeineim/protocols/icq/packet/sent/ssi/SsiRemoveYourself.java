/*    */ package ru.caffeineim.protocols.icq.packet.sent.ssi;
/*    */ 
/*    */ import ru.caffeineim.protocols.icq.Flap;
/*    */ import ru.caffeineim.protocols.icq.RawData;
/*    */ import ru.caffeineim.protocols.icq.Snac;
/*    */ 
/*    */ public class SsiRemoveYourself extends Flap
/*    */ {
/*    */   public SsiRemoveYourself(String uin)
/*    */   {
/* 32 */     super(2);
/* 33 */     Snac snac = new Snac(19, 22, 0, 0, 22);
/*    */ 
/* 36 */     snac.addRawDataToSnac(new RawData(uin.length(), 1));
/*    */ 
/* 39 */     snac.addRawDataToSnac(new RawData(uin));
/*    */ 
/* 41 */     addSnac(snac);
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.sent.ssi.SsiRemoveYourself
 * JD-Core Version:    0.6.0
 */