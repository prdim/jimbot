/*    */ package ru.caffeineim.protocols.icq.packet.received.icbm;
/*    */ 
/*    */ import java.util.List;
/*    */ import ru.caffeineim.protocols.icq.RawData;
/*    */ import ru.caffeineim.protocols.icq.Snac;
/*    */ import ru.caffeineim.protocols.icq.core.OscarConnection;
/*    */ import ru.caffeineim.protocols.icq.integration.events.MessageAckEvent;
/*    */ import ru.caffeineim.protocols.icq.integration.listeners.UserStatusListener;
/*    */ import ru.caffeineim.protocols.icq.packet.received.ReceivedPacket;
/*    */ 
/*    */ public class MessageAck__4_12 extends ReceivedPacket
/*    */ {
/*    */   private RawData time;
/*    */   private RawData id;
/*    */   private RawData type;
/*    */   private RawData rcptUin;
/*    */ 
/*    */   public MessageAck__4_12(byte[] array)
/*    */   {
/* 34 */     super(array, true);
/* 35 */     byte[] data = getSnac().getDataFieldByteArray();
/* 36 */     this.time = new RawData(data, 0, 4);
/* 37 */     this.id = new RawData(data, 4, 4);
/* 38 */     this.type = new RawData(data, 8, 2);
/* 39 */     this.rcptUin = new RawData(data, 11, data[10]);
/*    */   }
/*    */ 
/*    */   public void execute(OscarConnection oscarconnection) {
/*    */   }
/*    */ 
/*    */   public void notifyEvent(OscarConnection connection) {
/* 46 */     MessageAckEvent e = new MessageAckEvent(this);
/* 47 */     for (int i = 0; i < connection.getUserStatusListeners().size(); i++) {
/* 48 */       UserStatusListener l = (UserStatusListener)connection.getMessagingListeners().get(i);
/* 49 */       l.onMessageAck(e);
/*    */     }
/*    */   }
/*    */ 
/*    */   public int getMessageTime() {
/* 54 */     return this.time.getValue();
/*    */   }
/*    */ 
/*    */   public int getMessageId() {
/* 58 */     return this.id.getValue();
/*    */   }
/*    */ 
/*    */   public short getMessageType() {
/* 62 */     return (short)this.type.getValue();
/*    */   }
/*    */ 
/*    */   public String getRcptUin() {
/* 66 */     return this.rcptUin.getStringValue();
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.received.icbm.MessageAck__4_12
 * JD-Core Version:    0.6.0
 */