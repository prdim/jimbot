/*     */ package ru.caffeineim.protocols.icq.packet.received.byddylist;
/*     */ 
/*     */ import java.util.List;
/*     */ import ru.caffeineim.protocols.icq.RawData;
/*     */ import ru.caffeineim.protocols.icq.Snac;
/*     */ import ru.caffeineim.protocols.icq.Tlv;
/*     */ import ru.caffeineim.protocols.icq.core.OscarConnection;
/*     */ import ru.caffeineim.protocols.icq.integration.events.IncomingUserEvent;
/*     */ import ru.caffeineim.protocols.icq.integration.listeners.UserStatusListener;
/*     */ import ru.caffeineim.protocols.icq.packet.received.ReceivedPacket;
/*     */ import ru.caffeineim.protocols.icq.setting.Capabilities;
/*     */ import ru.caffeineim.protocols.icq.setting.enumerations.ClientsEnum;
/*     */ import ru.caffeineim.protocols.icq.setting.enumerations.StatusFlagEnum;
/*     */ import ru.caffeineim.protocols.icq.setting.enumerations.StatusModeEnum;
/*     */ import ru.caffeineim.protocols.icq.setting.enumerations.TcpConnectionFlagEnum;
/*     */ 
/*     */ public class IncomingUser__3_11 extends ReceivedPacket
/*     */ {
/*     */   private RawData userId;
/*     */   private RawData internalIp;
/*     */   private RawData port;
/*     */   private RawData tcpFlag;
/*     */   private RawData tcpVersion;
/*     */   private RawData cookie;
/*     */   private RawData versioning1;
/*     */   private RawData versioning2;
/*     */   private RawData versioning3;
/*     */   private Tlv externalIp;
/*     */   private Tlv userStatus;
/*     */   private Tlv capabilitiesOld;
/*     */   private Tlv capabilitiesNew;
/*     */   private Tlv onlineSince;
/*     */   private Tlv idleTime;
/*     */   private Tlv memberSince;
/*     */   private Tlv timeUpdate;
/*  71 */   private boolean isContainingCapabilities = false;
/*     */ 
/*  73 */   private boolean isConstainingDirectConnectionInformation = false;
/*     */   private ClientsEnum client;
/*     */ 
/*     */   public IncomingUser__3_11(byte[] array)
/*     */   {
/*  78 */     super(array, true);
/*  79 */     int position = 0;
/*  80 */     byte[] data = getSnac().getDataFieldByteArray();
/*     */ 
/*  83 */     RawData idLen = new RawData(data, position, 1);
/*  84 */     position++;
/*  85 */     this.userId = new RawData(data, position, idLen.getValue());
/*  86 */     position += this.userId.getByteArray().length;
/*     */ 
/*  89 */     position += 2;
/*     */ 
/*  92 */     RawData nbTLV = new RawData(data, position, 2);
/*  93 */     position += 2;
/*     */ 
/*  95 */     for (int i = 0; i < nbTLV.getValue(); i++) {
/*  96 */       Tlv tmpTlv = new Tlv(data, position);
/*  97 */       switch (tmpTlv.getType())
/*     */       {
/*     */       case 12:
/* 100 */         parseCli2Cli(tmpTlv.getByteArray());
/* 101 */         this.isConstainingDirectConnectionInformation = true;
/*     */ 
/* 104 */         break;
/*     */       case 10:
/* 108 */         this.externalIp = tmpTlv;
/* 109 */         break;
/*     */       case 6:
/* 113 */         this.userStatus = tmpTlv;
/* 114 */         break;
/*     */       case 13:
/* 118 */         this.capabilitiesOld = tmpTlv;
/* 119 */         this.isContainingCapabilities = true;
/* 120 */         break;
/*     */       case 25:
/* 123 */         this.capabilitiesNew = tmpTlv;
/* 124 */         this.isContainingCapabilities = true;
/* 125 */         break;
/*     */       case 15:
/* 129 */         this.idleTime = tmpTlv;
/* 130 */         break;
/*     */       case 3:
/* 134 */         this.onlineSince = tmpTlv;
/* 135 */         break;
/*     */       case 5:
/* 139 */         this.memberSince = tmpTlv;
/* 140 */         break;
/*     */       case 17:
/* 144 */         this.timeUpdate = tmpTlv;
/*     */       case 4:
/*     */       case 7:
/*     */       case 8:
/*     */       case 9:
/*     */       case 11:
/*     */       case 14:
/*     */       case 16:
/*     */       case 18:
/*     */       case 19:
/*     */       case 20:
/*     */       case 21:
/*     */       case 22:
/*     */       case 23:
/* 147 */       case 24: } position += tmpTlv.getByteArray().length;
/*     */     }
/*     */ 
/* 151 */     detectClient();
/*     */   }
/*     */ 
/*     */   private void detectClient()
/*     */   {
/* 159 */     int dwFP1 = this.versioning1.getValue();
/* 160 */     int dwFP2 = this.versioning2.getValue();
/* 161 */     int dwFP3 = this.versioning3.getValue();
/*     */ 
/* 163 */     int wVersion = this.tcpVersion.getValue();
/*     */ 
/* 165 */     this.client = Capabilities.detectUserClient(dwFP1, dwFP2, dwFP3, Capabilities.mergeCapabilities(this.capabilitiesOld.getByteArray(), this.capabilitiesNew.getByteArray()), wVersion);
/*     */   }
/*     */ 
/*     */   public void notifyEvent(OscarConnection connection)
/*     */   {
/* 171 */     IncomingUserEvent e = new IncomingUserEvent(this);
/* 172 */     for (int i = 0; i < connection.getUserStatusListeners().size(); i++) {
/* 173 */       UserStatusListener l = (UserStatusListener)connection.getUserStatusListeners().get(i);
/* 174 */       l.onIncomingUser(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void parseCli2Cli(byte[] data)
/*     */   {
/* 181 */     int position = 4;
/*     */ 
/* 184 */     this.internalIp = new RawData(data, position, 4);
/* 185 */     position += 4;
/*     */ 
/* 188 */     this.port = new RawData(data, position, 4);
/* 189 */     position += 4;
/*     */ 
/* 192 */     this.tcpFlag = new RawData(data, position, 1);
/* 193 */     position++;
/*     */ 
/* 196 */     this.tcpVersion = new RawData(data, position, 2);
/* 197 */     position += 2;
/*     */ 
/* 200 */     this.cookie = new RawData(data, position, 4);
/* 201 */     position += 4;
/*     */ 
/* 204 */     position += 8;
/*     */ 
/* 207 */     this.versioning1 = new RawData(data, position, 4);
/* 208 */     position += 4;
/*     */ 
/* 211 */     this.versioning2 = new RawData(data, position, 4);
/* 212 */     position += 4;
/*     */ 
/* 215 */     this.versioning3 = new RawData(data, position, 4);
/*     */   }
/*     */ 
/*     */   public boolean getIsContainingCapabilities() {
/* 219 */     return this.isContainingCapabilities;
/*     */   }
/*     */ 
/*     */   public boolean isConstainingDirectConnectionInformation() {
/* 223 */     return this.isConstainingDirectConnectionInformation;
/*     */   }
/*     */ 
/*     */   public String getUserId() {
/* 227 */     return this.userId.getStringValue();
/*     */   }
/*     */ 
/*     */   public String getInterlnalIp() {
/* 231 */     String add = "";
/* 232 */     add = add + (this.internalIp.getValue() >> 24 & 0xFF) + ".";
/* 233 */     add = add + (this.internalIp.getValue() >> 16 & 0xFF) + ".";
/* 234 */     add = add + (this.internalIp.getValue() >> 8 & 0xFF) + ".";
/* 235 */     add = add + (this.internalIp.getValue() & 0xFF);
/*     */ 
/* 237 */     return add;
/*     */   }
/*     */ 
/*     */   public int getPort() {
/* 241 */     return this.port.getValue();
/*     */   }
/*     */ 
/*     */   public TcpConnectionFlagEnum getTcpFlag() {
/* 245 */     return new TcpConnectionFlagEnum(this.tcpFlag.getValue());
/*     */   }
/*     */ 
/*     */   public int getTcpVersion() {
/* 249 */     return this.tcpVersion.getValue();
/*     */   }
/*     */ 
/*     */   public int getCookie() {
/* 253 */     return this.cookie.getValue();
/*     */   }
/*     */ 
/*     */   public int getVersionning1() {
/* 257 */     return this.versioning1.getValue();
/*     */   }
/*     */ 
/*     */   public int getVersionning2() {
/* 261 */     return this.versioning2.getValue();
/*     */   }
/*     */ 
/*     */   public String getExternalIp() {
/* 265 */     String add = "";
/* 266 */     add = add + (this.externalIp.getValue() >> 24 & 0xFF) + ".";
/* 267 */     add = add + (this.externalIp.getValue() >> 16 & 0xFF) + ".";
/* 268 */     add = add + (this.externalIp.getValue() >> 8 & 0xFF) + ".";
/* 269 */     add = add + (this.externalIp.getValue() & 0xFF);
/*     */ 
/* 271 */     return add;
/*     */   }
/*     */ 
/*     */   public StatusModeEnum getStatusMode()
/*     */   {
/* 276 */     if (this.userStatus == null)
/* 277 */       return new StatusModeEnum(0);
/* 278 */     return new StatusModeEnum(this.userStatus.getValue() & 0xFFFF);
/*     */   }
/*     */ 
/*     */   public StatusFlagEnum getStatusFlag()
/*     */   {
/* 283 */     if (this.userStatus == null)
/* 284 */       return new StatusFlagEnum(0);
/* 285 */     return new StatusFlagEnum(this.userStatus.getValue());
/*     */   }
/*     */ 
/*     */   public ClientsEnum getClient()
/*     */   {
/* 293 */     return this.client;
/*     */   }
/*     */ 
/*     */   public Tlv getCapabilitiesOld() {
/* 297 */     return this.capabilitiesOld;
/*     */   }
/*     */ 
/*     */   public Tlv getCapabilitiesNew() {
/* 301 */     return this.capabilitiesNew;
/*     */   }
/*     */ 
/*     */   public int getOnlineSince() {
/* 305 */     return this.onlineSince.getValue();
/*     */   }
/*     */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.received.byddylist.IncomingUser__3_11
 * JD-Core Version:    0.6.0
 */