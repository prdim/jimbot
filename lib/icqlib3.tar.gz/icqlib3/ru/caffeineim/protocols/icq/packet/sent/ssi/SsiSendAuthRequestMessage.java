/*    */ package ru.caffeineim.protocols.icq.packet.sent.ssi;
/*    */ 
/*    */ import ru.caffeineim.protocols.icq.Flap;
/*    */ import ru.caffeineim.protocols.icq.RawData;
/*    */ import ru.caffeineim.protocols.icq.Snac;
/*    */ import ru.caffeineim.protocols.icq.exceptions.ConvertStringException;
/*    */ import ru.caffeineim.protocols.icq.tool.StringTools;
/*    */ 
/*    */ public class SsiSendAuthRequestMessage extends Flap
/*    */ {
/*    */   public SsiSendAuthRequestMessage(String uin, String message)
/*    */     throws ConvertStringException
/*    */   {
/* 36 */     super(2);
/* 37 */     Snac snac = new Snac(19, 24, 0, 0, 24);
/*    */ 
/* 40 */     snac.addRawDataToSnac(new RawData(uin.length(), 1));
/*    */ 
/* 43 */     snac.addRawDataToSnac(new RawData(uin));
/*    */ 
/* 45 */     byte[] msg = StringTools.stringToByteArray(message);
/*    */ 
/* 48 */     snac.addRawDataToSnac(new RawData(msg.length, 2));
/*    */ 
/* 51 */     snac.addRawDataToSnac(new RawData(msg));
/*    */ 
/* 54 */     snac.addRawDataToSnac(new RawData(0, 2));
/*    */ 
/* 56 */     addSnac(snac);
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.sent.ssi.SsiSendAuthRequestMessage
 * JD-Core Version:    0.6.0
 */