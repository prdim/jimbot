/*    */ package ru.caffeineim.protocols.icq.packet.sent.authorization;
/*    */ 
/*    */ import ru.caffeineim.protocols.icq.Flap;
/*    */ import ru.caffeineim.protocols.icq.RawData;
/*    */ import ru.caffeineim.protocols.icq.Snac;
/*    */ import ru.caffeineim.protocols.icq.Tlv;
/*    */ 
/*    */ public class UINRegistration extends Flap
/*    */ {
/* 28 */   private static final byte[] REGISTRATION_REQUEST_BEGIN = { 0, 0, 0, 0, 40, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 70, 0, 0, 3, 70, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
/*    */ 
/* 37 */   private static final byte[] REGISTRATION_REQUEST_END = { 0, 3, 70, 0, 0, 0, 0, 0, 0, 17, 1 };
/*    */ 
/*    */   public UINRegistration(String password)
/*    */   {
/* 41 */     super(2);
/*    */ 
/* 43 */     byte[] passwd_lng = getPasswordLng(password);
/*    */ 
/* 45 */     byte[] regData = new byte[REGISTRATION_REQUEST_BEGIN.length + password.toCharArray().length + REGISTRATION_REQUEST_END.length + 2];
/*    */ 
/* 49 */     for (int i = 0; i < REGISTRATION_REQUEST_BEGIN.length; i++) {
/* 50 */       regData[i] = REGISTRATION_REQUEST_BEGIN[i];
/*    */     }
/*    */ 
/* 53 */     regData[REGISTRATION_REQUEST_BEGIN.length] = passwd_lng[0];
/* 54 */     regData[(REGISTRATION_REQUEST_BEGIN.length + 1)] = passwd_lng[1];
/*    */ 
/* 56 */     for (int i = 0; i < password.toCharArray().length; i++) {
/* 57 */       regData[(i + REGISTRATION_REQUEST_BEGIN.length + 2)] = (byte)password.toCharArray()[i];
/*    */     }
/*    */ 
/* 61 */     for (int i = 0; i < REGISTRATION_REQUEST_END.length; i++) {
/* 62 */       regData[(i + REGISTRATION_REQUEST_BEGIN.length + password.toCharArray().length + 2)] = REGISTRATION_REQUEST_END[i];
/*    */     }
/*    */ 
/* 66 */     Snac regSnac = new Snac(23, 4, 0, 0, 0);
/* 67 */     Tlv regTlv = new Tlv(new RawData(regData), 1);
/*    */ 
/* 69 */     regSnac.addTlvToSnac(regTlv);
/*    */   }
/*    */ 
/*    */   protected byte[] getPasswordLng(String password) {
/* 73 */     short lng = (short)password.length();
/* 74 */     RawData lngData = new RawData(lng, 4);
/* 75 */     lngData.invertIndianness();
/* 76 */     return lngData.getByteArray();
/*    */   }
/*    */ 
/*    */   protected byte[] getPasswordArray(String password) {
/* 80 */     byte[] lng = getPasswordLng(password);
/*    */ 
/* 82 */     byte[] result = new byte[lng.length + password.length()];
/*    */ 
/* 84 */     for (int i = 0; i < lng.length; i++) {
/* 85 */       result[i] = lng[i];
/*    */     }
/*    */ 
/* 88 */     for (int i = 0; i < password.length(); i++) {
/* 89 */       result[(lng.length + i)] = (byte)password.charAt(i);
/*    */     }
/*    */ 
/* 92 */     return result;
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.sent.authorization.UINRegistration
 * JD-Core Version:    0.6.0
 */