/*     */ package ru.caffeineim.protocols.icq.packet.received.icbm;
/*     */ 
/*     */ import java.util.List;
/*     */ import ru.caffeineim.protocols.icq.RawData;
/*     */ import ru.caffeineim.protocols.icq.Snac;
/*     */ import ru.caffeineim.protocols.icq.core.OscarConnection;
/*     */ import ru.caffeineim.protocols.icq.exceptions.ConvertStringException;
/*     */ import ru.caffeineim.protocols.icq.integration.events.XStatusResponseEvent;
/*     */ import ru.caffeineim.protocols.icq.integration.listeners.XStatusListener;
/*     */ import ru.caffeineim.protocols.icq.packet.received.ReceivedPacket;
/*     */ import ru.caffeineim.protocols.icq.setting.enumerations.MessageFlagsEnum;
/*     */ import ru.caffeineim.protocols.icq.setting.enumerations.MessageTypeEnum;
/*     */ import ru.caffeineim.protocols.icq.tool.StringTools;
/*     */ 
/*     */ public class MessageAutoReply__4_11 extends ReceivedPacket
/*     */ {
/*     */   public static final short UNSUPPORTED_CHANNEL = 1;
/*     */   public static final short BUSTED_PAYLOAD = 2;
/*     */   public static final short CHANNEL_SPECIFIC = 3;
/*     */   private String message;
/*     */   private MessageTypeEnum messageType;
/*     */   private RawData messageChannel;
/*     */   private String senderID;
/*  44 */   private boolean isResponseXStatus = false;
/*     */ 
/*     */   public MessageAutoReply__4_11(byte[] array)
/*     */     throws Exception
/*     */   {
/*  50 */     super(array, true);
/*     */ 
/*  52 */     byte[] data = getSnac().getDataFieldByteArray();
/*  53 */     int index = 0;
/*  54 */     RawData id = new RawData(data, index, 8);
/*  55 */     index += 8;
/*  56 */     this.messageChannel = new RawData(data, index, 2);
/*  57 */     index += 2;
/*  58 */     RawData uinLg = new RawData(data, index, 1);
/*  59 */     index++;
/*  60 */     this.senderID = new String(data, index, uinLg.getValue());
/*  61 */     index += uinLg.getValue();
/*  62 */     RawData reasonCode = new RawData(data, index, 2);
/*  63 */     index += 2;
/*     */ 
/*  65 */     if (reasonCode.getValue() == 3) {
/*  66 */       if (index >= data.length) return;
/*  67 */       switch (this.messageChannel.getValue()) {
/*     */       case 1:
/*  69 */         getChannel1Msg(data, index);
/*  70 */         break;
/*     */       case 2:
/*  72 */         getChannel2Msg(data, index);
/*  73 */         break;
/*     */       default:
/*  75 */         throw new Exception("Unknown channel");
/*     */       }
/*     */     }
/*     */ 
/*  79 */     if ((this.messageChannel.getValue() == 2) && (this.messageType.getType() == 26))
/*  80 */       this.isResponseXStatus = true;
/*     */   }
/*     */ 
/*     */   private void getChannel1Msg(byte[] data, int index)
/*     */     throws ConvertStringException
/*     */   {
/*  86 */     RawData id1 = new RawData(data, index++, 1);
/*  87 */     RawData ver1 = new RawData(data, index++, 1);
/*  88 */     RawData frag1Lg = new RawData(data, index, 2);
/*  89 */     index += 2;
/*  90 */     RawData capabilities = new RawData(data, index, frag1Lg.getValue());
/*     */ 
/*  93 */     RawData id2 = new RawData(data, index++, 1);
/*  94 */     RawData ver2 = new RawData(data, index++, 1);
/*  95 */     RawData frag2Lg = new RawData(data, index, 2);
/*  96 */     index += 2;
/*     */ 
/*  99 */     this.message = parseMessageType1(data, index, frag2Lg.getValue());
/*     */   }
/*     */ 
/*     */   private void getChannel2Msg(byte[] data, int index) throws ConvertStringException
/*     */   {
/* 104 */     RawData part1Lg = new RawData(data, index, 2);
/* 105 */     index += 2;
/* 106 */     RawData protocolVersion = new RawData(data, index, 2);
/* 107 */     index += 2;
/* 108 */     RawData guid = new RawData(data, index, 16);
/* 109 */     index += 16;
/* 110 */     RawData unknownWord = new RawData(data, index, 2);
/* 111 */     index += 2;
/* 112 */     RawData clientCapabilities = new RawData(data, index, 4);
/* 113 */     index += 4;
/* 114 */     RawData unknownByte = new RawData(data, index, 1);
/* 115 */     index++;
/* 116 */     RawData cntr1 = new RawData(data, index, 2);
/* 117 */     index += 2;
/*     */ 
/* 120 */     RawData part2Lg = new RawData(data, index, 2);
/* 121 */     index += 2;
/* 122 */     RawData cntr2 = new RawData(data, index, 2);
/* 123 */     part2Lg.invertIndianness();
/* 124 */     index += part2Lg.getValue();
/*     */ 
/* 126 */     this.message = parseMessageType2(data, index);
/*     */   }
/*     */ 
/*     */   private String parseMessageType1(byte[] data, int index, int length) throws ConvertStringException {
/* 130 */     RawData charset = new RawData(data, index, 2);
/* 131 */     index += 2;
/* 132 */     RawData language = new RawData(data, index, 2);
/* 133 */     index += 2;
/* 134 */     length -= 4;
/*     */ 
/* 136 */     return StringTools.utf8ByteArrayToString(data, index, length);
/*     */   }
/*     */ 
/*     */   private String parseMessageType2(byte[] data, int index) throws ConvertStringException {
/* 140 */     this.messageType = new MessageTypeEnum(data[(index++)]);
/* 141 */     MessageFlagsEnum msgFlag = new MessageFlagsEnum(data[(index++)]);
/* 142 */     RawData status = new RawData(data, index, 2);
/* 143 */     index += 2;
/* 144 */     RawData priority = new RawData(data, index, 2);
/* 145 */     index += 2;
/* 146 */     RawData msgLg = new RawData(data, index, 2);
/* 147 */     index += 2;
/*     */ 
/* 150 */     msgLg.invertIndianness();
/* 151 */     this.message = StringTools.utf8ByteArrayToString(data, index, msgLg.getValue());
/*     */ 
/* 153 */     if (this.messageType.getType() == 26)
/*     */     {
/* 155 */       index += 66;
/*     */ 
/* 158 */       index += 24;
/*     */ 
/* 160 */       this.message = StringTools.utf8ByteArrayToString(data, index, data.length - index);
/*     */     }
/*     */ 
/* 163 */     if (this.messageType.getType() == 1) {
/* 164 */       RawData textColor = new RawData(data, index, 4);
/* 165 */       index += 4;
/* 166 */       RawData backgroundColor = new RawData(data, index, 4);
/* 167 */       index += 4;
/*     */     }
/*     */ 
/* 174 */     return this.message;
/*     */   }
/*     */ 
/*     */   public void notifyEvent(OscarConnection connection) {
/* 178 */     MessageTypeEnum mt = getMessageType();
/* 179 */     if (mt == null) return;
/* 180 */     if (mt.getType() == 26)
/* 181 */       notifyXStatusRequest(connection);
/*     */   }
/*     */ 
/*     */   private void notifyXStatusRequest(OscarConnection connection)
/*     */   {
/* 186 */     XStatusResponseEvent e = new XStatusResponseEvent(this);
/* 187 */     for (int i = 0; i < connection.getXStatusListeners().size(); i++) {
/* 188 */       XStatusListener l = (XStatusListener)connection.getXStatusListeners().get(i);
/* 189 */       l.onXStatusResponse(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getMessage() {
/* 194 */     return this.message;
/*     */   }
/*     */ 
/*     */   public String getSenderID() {
/* 198 */     return this.senderID;
/*     */   }
/*     */ 
/*     */   public int getChannel() {
/* 202 */     return this.messageChannel.getValue();
/*     */   }
/*     */ 
/*     */   public MessageTypeEnum getMessageType() {
/* 206 */     return this.messageType;
/*     */   }
/*     */ 
/*     */   public boolean isResponseXStatus() {
/* 210 */     return this.isResponseXStatus;
/*     */   }
/*     */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.received.icbm.MessageAutoReply__4_11
 * JD-Core Version:    0.6.0
 */