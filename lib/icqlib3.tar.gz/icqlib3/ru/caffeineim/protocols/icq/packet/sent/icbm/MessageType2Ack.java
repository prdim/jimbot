/*     */ package ru.caffeineim.protocols.icq.packet.sent.icbm;
/*     */ 
/*     */ import ru.caffeineim.protocols.icq.Flap;
/*     */ import ru.caffeineim.protocols.icq.RawData;
/*     */ import ru.caffeineim.protocols.icq.Snac;
/*     */ 
/*     */ public class MessageType2Ack extends Flap
/*     */ {
/*  28 */   private static final byte[] capability = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
/*     */ 
/*  33 */   private static final byte[] unknown12 = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
/*     */ 
/*  37 */   private static final byte[] msgTypeFooter = { 0, 0, 0, 0, -1, -1, -1, 0 };
/*     */ 
/*     */   public MessageType2Ack(RawData Time, RawData msgID, String UIN, RawData senderTcpVer, RawData msgSeqNum, RawData msgType, RawData msgFlags, String requestedMessage)
/*     */   {
/*  47 */     super(2);
/*     */ 
/*  49 */     Snac snac = new Snac(4, 11, 0, 0, 0);
/*     */ 
/*  52 */     snac.addRawDataToSnac(Time);
/*     */ 
/*  55 */     snac.addRawDataToSnac(msgID);
/*     */ 
/*  58 */     snac.addRawDataToSnac(new RawData(2, 2));
/*     */ 
/*  61 */     snac.addRawDataToSnac(new RawData(UIN.length(), 1));
/*     */ 
/*  64 */     snac.addRawDataToSnac(new RawData(UIN));
/*     */ 
/*  67 */     snac.addRawDataToSnac(new RawData(3, 2));
/*     */ 
/*  70 */     snac.addRawDataToSnac(new RawData(6912));
/*     */ 
/*  73 */     snac.addRawDataToSnac(senderTcpVer);
/*     */ 
/*  76 */     snac.addRawDataToSnac(new RawData(capability));
/*     */ 
/*  79 */     snac.addRawDataToSnac(new RawData(0, 2));
/*     */ 
/*  82 */     snac.addRawDataToSnac(new RawData(50331648, 4));
/*     */ 
/*  85 */     snac.addRawDataToSnac(new RawData(0, 1));
/*     */ 
/*  88 */     snac.addRawDataToSnac(msgSeqNum);
/*     */ 
/*  91 */     snac.addRawDataToSnac(new RawData(3584, 2));
/*     */ 
/*  94 */     snac.addRawDataToSnac(msgSeqNum);
/*     */ 
/*  97 */     snac.addRawDataToSnac(new RawData(unknown12));
/*     */ 
/* 100 */     snac.addRawDataToSnac(msgType);
/*     */ 
/* 103 */     snac.addRawDataToSnac(msgFlags);
/*     */ 
/* 106 */     snac.addRawDataToSnac(new RawData(0, 2));
/*     */ 
/* 109 */     snac.addRawDataToSnac(new RawData(0, 2));
/*     */ 
/* 112 */     RawData rLen = new RawData(requestedMessage.length() + 1, 2);
/*     */ 
/* 114 */     rLen.invertIndianness();
/* 115 */     snac.addRawDataToSnac(rLen);
/* 116 */     snac.addRawDataToSnac(new RawData(requestedMessage));
/* 117 */     snac.addRawDataToSnac(new RawData(0, 1));
/*     */ 
/* 120 */     snac.addRawDataToSnac(new RawData(msgTypeFooter));
/*     */ 
/* 122 */     addSnac(snac);
/*     */   }
/*     */ 
/*     */   public MessageType2Ack(RawData time, RawData msgID, String UIN, RawData senderTcpVer, RawData msgSeqNum, RawData msgType, RawData msgFlags)
/*     */   {
/* 129 */     this(time, msgID, UIN, senderTcpVer, msgSeqNum, msgType, msgFlags, "");
/*     */   }
/*     */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.sent.icbm.MessageType2Ack
 * JD-Core Version:    0.6.0
 */