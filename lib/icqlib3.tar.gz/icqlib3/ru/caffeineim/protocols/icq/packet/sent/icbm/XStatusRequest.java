/*     */ package ru.caffeineim.protocols.icq.packet.sent.icbm;
/*     */ 
/*     */ import ru.caffeineim.protocols.icq.RawData;
/*     */ import ru.caffeineim.protocols.icq.Snac;
/*     */ import ru.caffeineim.protocols.icq.Tlv;
/*     */ import ru.caffeineim.protocols.icq.setting.enumerations.MessageChannelEnum;
/*     */ 
/*     */ public class XStatusRequest extends SendMessage
/*     */ {
/*  28 */   private static final byte[] CAPABILITY1 = { 9, 70, 19, 73, 76, 127, 17, -47, -126, 34, 68, 69, 83, 84, 0, 0 };
/*     */ 
/*  33 */   private static final byte[] CAPABILITY2 = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
/*     */ 
/*  38 */   private static final byte[] CAPABILITY3 = { 26, 0, 0, 0, 1, 0, 1, 0, 0, 79, 0, 59, 96, -77, -17, -40 };
/*     */ 
/*  43 */   private static final byte[] CAPABILITY4 = { 42, 108, 69, -92, -32, -100, 90, 94, 103, -24, 101, 8, 0, 42, 0, 0 };
/*     */ 
/*  48 */   private static final byte[] UNKNOWN = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
/*     */ 
/*     */   public XStatusRequest(String userId, String myId)
/*     */   {
/*  54 */     super(userId, new MessageChannelEnum(2));
/*     */ 
/*  57 */     Tlv tlv5 = new Tlv(0, 2, 5);
/*     */ 
/*  60 */     tlv5.appendRawDataToTlv(new RawData(0, 4));
/*     */ 
/*  63 */     tlv5.appendRawDataToTlv(new RawData(0, 4));
/*     */ 
/*  66 */     tlv5.appendRawDataToTlv(new RawData(CAPABILITY1));
/*     */ 
/*  69 */     tlv5.appendTlvToTlv(new Tlv(1, 2, 10));
/*     */ 
/*  72 */     tlv5.appendRawDataToTlv(new RawData(983040, 4));
/*     */ 
/*  75 */     Tlv tlv2711 = new Tlv(6912, 2, 10001);
/*     */ 
/*  78 */     tlv2711.appendRawDataToTlv(new RawData(2560, 2));
/*     */ 
/*  81 */     tlv2711.appendRawDataToTlv(new RawData(CAPABILITY2));
/*  82 */     tlv2711.appendRawDataToTlv(new RawData(0, 2));
/*     */ 
/*  87 */     tlv2711.appendRawDataToTlv(new RawData(0, 4));
/*     */ 
/*  90 */     tlv2711.appendRawDataToTlv(new RawData(0, 1));
/*     */ 
/*  93 */     tlv2711.appendRawDataToTlv(new RawData(38354, 2));
/*     */ 
/*  96 */     tlv2711.appendRawDataToTlv(new RawData(3584, 2));
/*     */ 
/*  99 */     tlv2711.appendRawDataToTlv(new RawData(38354, 2));
/*     */ 
/* 102 */     tlv2711.appendRawDataToTlv(new RawData(UNKNOWN));
/*     */ 
/* 105 */     tlv2711.appendRawDataToTlv(new RawData(CAPABILITY3));
/* 106 */     tlv2711.appendRawDataToTlv(new RawData(CAPABILITY4));
/*     */ 
/* 109 */     tlv2711.appendRawDataToTlv(new RawData(0, 1));
/*     */ 
/* 112 */     tlv2711.appendRawDataToTlv(new RawData("Script Plug-in: Remote Notification Arrive"));
/* 113 */     tlv2711.appendRawDataToTlv(new RawData(0, 1));
/*     */ 
/* 117 */     tlv2711.appendRawDataToTlv(new RawData(1, 2));
/*     */ 
/* 119 */     tlv2711.appendRawDataToTlv(new RawData(UNKNOWN));
/*     */ 
/* 121 */     tlv2711.appendRawDataToTlv(new RawData(318832640, 4));
/*     */ 
/* 123 */     tlv2711.appendRawDataToTlv(new RawData(-251592704, 4));
/*     */ 
/* 126 */     int trans = (int)Math.random() * 18;
/* 127 */     tlv2711.appendRawDataToTlv(new RawData("<N><QUERY>&lt;Q&gt;&lt;PluginID&gt;srvMng&lt;/PluginID&gt;&lt;/Q&gt;</QUERY><NOTIFY>&lt;srv&gt;&lt;id&gt;cAwaySrv&lt;/id&gt;&lt;req&gt;&lt;id&gt;AwayStat&lt;/id&gt;&lt;trans&gt;" + trans + "&lt;/trans&gt;&lt;senderId&gt;" + myId + "&lt;/senderId&gt;&lt;/req&gt;&lt;/srv&gt;</NOTIFY></N>"));
/*     */ 
/* 129 */     tlv5.appendTlvToTlv(tlv2711);
/* 130 */     this.snac.addTlvToSnac(tlv5);
/*     */ 
/* 133 */     this.snac.addRawDataToSnac(new RawData(3, 2));
/*     */ 
/* 136 */     this.snac.addRawDataToSnac(new RawData(0, 2));
/*     */ 
/* 138 */     addSnac(this.snac);
/*     */   }
/*     */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.sent.icbm.XStatusRequest
 * JD-Core Version:    0.6.0
 */