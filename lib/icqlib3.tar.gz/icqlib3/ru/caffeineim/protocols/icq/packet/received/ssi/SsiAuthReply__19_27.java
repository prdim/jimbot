/*    */ package ru.caffeineim.protocols.icq.packet.received.ssi;
/*    */ 
/*    */ import java.util.List;
/*    */ import ru.caffeineim.protocols.icq.RawData;
/*    */ import ru.caffeineim.protocols.icq.Snac;
/*    */ import ru.caffeineim.protocols.icq.core.OscarConnection;
/*    */ import ru.caffeineim.protocols.icq.exceptions.ConvertStringException;
/*    */ import ru.caffeineim.protocols.icq.integration.events.SsiAuthReplyEvent;
/*    */ import ru.caffeineim.protocols.icq.integration.listeners.ContactListListener;
/*    */ import ru.caffeineim.protocols.icq.packet.received.ReceivedPacket;
/*    */ import ru.caffeineim.protocols.icq.tool.StringTools;
/*    */ 
/*    */ public class SsiAuthReply__19_27 extends ReceivedPacket
/*    */ {
/*    */   private String senderUin;
/*    */   private String message;
/*    */   private boolean authFlag;
/*    */ 
/*    */   public SsiAuthReply__19_27(byte[] array)
/*    */     throws ConvertStringException
/*    */   {
/* 39 */     super(array, true);
/* 40 */     int position = 0;
/*    */ 
/* 42 */     byte[] data = getSnac().getDataFieldByteArray();
/*    */ 
/* 45 */     position += 8;
/*    */ 
/* 48 */     RawData len = new RawData(data[(position++)]);
/* 49 */     this.senderUin = new String(data, position, len.getValue());
/* 50 */     position += len.getValue();
/*    */ 
/* 53 */     RawData flag = new RawData(data[(position++)]);
/* 54 */     this.authFlag = (flag.getValue() == 1);
/*    */ 
/* 57 */     len = new RawData(data, position, 2);
/* 58 */     position += 2;
/* 59 */     this.message = StringTools.utf8ByteArrayToString(data, position, len.getValue());
/*    */   }
/*    */ 
/*    */   public void notifyEvent(OscarConnection connection) {
/* 63 */     SsiAuthReplyEvent e = new SsiAuthReplyEvent(this);
/* 64 */     for (int i = 0; i < connection.getContactListListeners().size(); i++) {
/* 65 */       ContactListListener l = (ContactListListener)connection.getContactListListeners().get(i);
/* 66 */       l.onSsiAuthReply(e);
/*    */     }
/*    */   }
/*    */ 
/*    */   public String getSenderUin() {
/* 71 */     return this.senderUin;
/*    */   }
/*    */ 
/*    */   public String getMessage() {
/* 75 */     return this.message;
/*    */   }
/*    */ 
/*    */   public boolean getAuthFlag() {
/* 79 */     return this.authFlag;
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.received.ssi.SsiAuthReply__19_27
 * JD-Core Version:    0.6.0
 */