/*    */ package ru.caffeineim.protocols.icq.packet.sent.meta;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import ru.caffeineim.protocols.icq.Flap;
/*    */ import ru.caffeineim.protocols.icq.RawData;
/*    */ import ru.caffeineim.protocols.icq.Snac;
/*    */ import ru.caffeineim.protocols.icq.tool.ProtocolUtils;
/*    */ 
/*    */ public class ChangeOwnInfo extends Flap
/*    */ {
/*    */   public ChangeOwnInfo(String screenName, FullUserInfo info)
/*    */   {
/* 18 */     super(2);
/*    */ 
/* 20 */     ArrayList infoDat = info.pack();
/* 21 */     byte[] infoBDat = new byte[infoDat.size()];
/* 22 */     for (int i = 0; i < infoDat.size(); i++) {
/* 23 */       infoBDat[i] = ((Byte)infoDat.get(i)).byteValue();
/*    */     }
/* 25 */     Snac snac = new Snac(21, 2, 0, 0, 0);
/* 26 */     snac.addRawDataToSnac(new RawData(1, 2));
/* 27 */     snac.addRawDataToSnac(new RawData(infoDat.size() + 12, 2));
/* 28 */     RawData rw = new RawData(infoDat.size() + 10, 2);
/* 29 */     rw.invertIndianness();
/* 30 */     snac.addRawDataToSnac(rw);
/* 31 */     snac.addRawDataToSnac(new RawData(ProtocolUtils.getUIN(screenName)));
/* 32 */     snac.addRawDataToSnac(new RawData(new byte[] { -48, 7 }));
/* 33 */     snac.addRawDataToSnac(new RawData(new byte[] { 2, 0 }));
/* 34 */     snac.addRawDataToSnac(new RawData(new byte[] { 58, 12 }));
/* 35 */     snac.addRawDataToSnac(new RawData(infoBDat));
/* 36 */     addSnac(snac);
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.sent.meta.ChangeOwnInfo
 * JD-Core Version:    0.6.0
 */