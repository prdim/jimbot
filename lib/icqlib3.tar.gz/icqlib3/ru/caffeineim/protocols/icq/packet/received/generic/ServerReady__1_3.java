/*    */ package ru.caffeineim.protocols.icq.packet.received.generic;
/*    */ 
/*    */ import ru.caffeineim.protocols.icq.core.OscarConnection;
/*    */ import ru.caffeineim.protocols.icq.packet.received.ReceivedPacket;
/*    */ import ru.caffeineim.protocols.icq.packet.sent.generic.ClientFamilies;
/*    */ import ru.caffeineim.protocols.icq.packet.sent.ssi.SsiContactListLoad;
/*    */ 
/*    */ public class ServerReady__1_3 extends ReceivedPacket
/*    */ {
/*    */   public ServerReady__1_3(byte[] array)
/*    */   {
/* 30 */     super(array, true);
/*    */   }
/*    */ 
/*    */   public void execute(OscarConnection connection) throws Exception {
/* 34 */     connection.sendFlap(new ClientFamilies());
/* 35 */     connection.sendFlap(new SsiContactListLoad());
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.received.generic.ServerReady__1_3
 * JD-Core Version:    0.6.0
 */