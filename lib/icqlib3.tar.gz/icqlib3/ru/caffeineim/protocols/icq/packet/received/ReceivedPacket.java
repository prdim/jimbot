/*    */ package ru.caffeineim.protocols.icq.packet.received;
/*    */ 
/*    */ import ru.caffeineim.protocols.icq.Flap;
/*    */ import ru.caffeineim.protocols.icq.RawData;
/*    */ import ru.caffeineim.protocols.icq.Snac;
/*    */ import ru.caffeineim.protocols.icq.core.IReceivable;
/*    */ import ru.caffeineim.protocols.icq.core.OscarConnection;
/*    */ import ru.caffeineim.protocols.icq.request.Request;
/*    */ import ru.caffeineim.protocols.icq.request.RequestKeeper;
/*    */ import ru.caffeineim.protocols.icq.request.event.RequestAnswerEvent;
/*    */ 
/*    */ public class ReceivedPacket extends Flap
/*    */   implements IReceivable
/*    */ {
/*    */   public ReceivedPacket(byte[] array, boolean hasSnac)
/*    */   {
/* 37 */     setChannelId(new RawData(array, 1, 1).getValue());
/* 38 */     setSequenceNumber(new RawData(array, 2, 2).getValue());
/*    */ 
/* 40 */     if (hasSnac)
/* 41 */       addSnac(new Snac(array, 6));
/*    */     else
/* 43 */       addRawDataToFlap(new RawData(array, 6, array.length - 6));
/*    */   }
/*    */ 
/*    */   public void matchRequest(OscarConnection connection)
/*    */   {
/* 53 */     RequestKeeper requestKeeper = connection.getRequestKeeper();
/* 54 */     if (requestKeeper.containsRequest(getSnac().getRequestId())) {
/* 55 */       Request request = requestKeeper.getRequest(getSnac().getRequestId());
/* 56 */       for (int i = 0; i < request.getNbListeners(); i++) {
/* 57 */         request.getRequestListener(i).onRequestAnswer(new RequestAnswerEvent(request.getMonitoredFlap(), this));
/*    */       }
/*    */ 
/* 60 */       request.removeAllListener();
/*    */     }
/*    */   }
/*    */ 
/*    */   public void execute(OscarConnection connection)
/*    */     throws Exception
/*    */   {
/*    */   }
/*    */ 
/*    */   public void notifyEvent(OscarConnection connection)
/*    */   {
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.received.ReceivedPacket
 * JD-Core Version:    0.6.0
 */