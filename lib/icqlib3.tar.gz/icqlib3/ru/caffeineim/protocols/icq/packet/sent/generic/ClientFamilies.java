/*    */ package ru.caffeineim.protocols.icq.packet.sent.generic;
/*    */ 
/*    */ import ru.caffeineim.protocols.icq.Flap;
/*    */ import ru.caffeineim.protocols.icq.RawData;
/*    */ import ru.caffeineim.protocols.icq.Snac;
/*    */ 
/*    */ public class ClientFamilies extends Flap
/*    */ {
/*    */   public ClientFamilies()
/*    */   {
/* 29 */     super(2);
/* 30 */     Snac snac = new Snac(1, 23, 0, 0, 0);
/*    */ 
/* 33 */     snac.addRawDataToSnac(new RawData(65539, 4));
/*    */ 
/* 35 */     snac.addRawDataToSnac(new RawData(1245188, 4));
/*    */ 
/* 37 */     snac.addRawDataToSnac(new RawData(131073, 4));
/*    */ 
/* 39 */     snac.addRawDataToSnac(new RawData(196609, 4));
/*    */ 
/* 41 */     snac.addRawDataToSnac(new RawData(1376257, 4));
/*    */ 
/* 43 */     snac.addRawDataToSnac(new RawData(262145, 4));
/*    */ 
/* 45 */     snac.addRawDataToSnac(new RawData(393217, 4));
/*    */ 
/* 47 */     snac.addRawDataToSnac(new RawData(589825, 4));
/*    */ 
/* 49 */     snac.addRawDataToSnac(new RawData(655361, 4));
/*    */ 
/* 51 */     snac.addRawDataToSnac(new RawData(720897, 4));
/*    */ 
/* 53 */     addSnac(snac);
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.sent.generic.ClientFamilies
 * JD-Core Version:    0.6.0
 */