/*    */ package ru.caffeineim.protocols.icq.packet.sent.icbm;
/*    */ 
/*    */ import ru.caffeineim.protocols.icq.Flap;
/*    */ import ru.caffeineim.protocols.icq.Snac;
/*    */ 
/*    */ public class ICBMRequestParameters extends Flap
/*    */ {
/*    */   public ICBMRequestParameters()
/*    */   {
/* 28 */     super(2);
/*    */ 
/* 30 */     Snac snac = new Snac(4, 4, 0, 0, 0);
/* 31 */     addSnac(snac);
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.sent.icbm.ICBMRequestParameters
 * JD-Core Version:    0.6.0
 */