/*    */ package ru.caffeineim.protocols.icq.packet.sent.generic;
/*    */ 
/*    */ import ru.caffeineim.protocols.icq.Flap;
/*    */ import ru.caffeineim.protocols.icq.RawData;
/*    */ import ru.caffeineim.protocols.icq.Snac;
/*    */ 
/*    */ public class RateAcknowledge extends Flap
/*    */ {
/*    */   public RateAcknowledge()
/*    */   {
/* 29 */     super(2);
/*    */ 
/* 31 */     Snac snac = new Snac(1, 8, 0, 0, 0);
/*    */ 
/* 33 */     snac.addRawDataToSnac(new RawData(1, 2));
/* 34 */     snac.addRawDataToSnac(new RawData(2, 2));
/* 35 */     snac.addRawDataToSnac(new RawData(3, 2));
/* 36 */     snac.addRawDataToSnac(new RawData(4, 2));
/* 37 */     snac.addRawDataToSnac(new RawData(5, 2));
/*    */ 
/* 39 */     addSnac(snac);
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.sent.generic.RateAcknowledge
 * JD-Core Version:    0.6.0
 */