/*    */ package ru.caffeineim.protocols.icq.packet.received.byddylist;
/*    */ 
/*    */ import java.util.List;
/*    */ import ru.caffeineim.protocols.icq.RawData;
/*    */ import ru.caffeineim.protocols.icq.Snac;
/*    */ import ru.caffeineim.protocols.icq.core.OscarConnection;
/*    */ import ru.caffeineim.protocols.icq.integration.events.OffgoingUserEvent;
/*    */ import ru.caffeineim.protocols.icq.integration.listeners.UserStatusListener;
/*    */ import ru.caffeineim.protocols.icq.packet.received.ReceivedPacket;
/*    */ 
/*    */ public class OffgoingUser__3_12 extends ReceivedPacket
/*    */ {
/*    */   private RawData userId;
/*    */ 
/*    */   public OffgoingUser__3_12(byte[] array)
/*    */   {
/* 33 */     super(array, true);
/* 34 */     int position = 0;
/*    */ 
/* 36 */     byte[] data = getSnac().getDataFieldByteArray();
/*    */ 
/* 39 */     RawData idLen = new RawData(data, position, 1);
/* 40 */     position++;
/* 41 */     this.userId = new RawData(data, position, idLen.getValue());
/*    */   }
/*    */ 
/*    */   public void notifyEvent(OscarConnection connection) {
/* 45 */     OffgoingUserEvent e = new OffgoingUserEvent(this);
/* 46 */     for (int i = 0; i < connection.getUserStatusListeners().size(); i++) {
/* 47 */       UserStatusListener l = (UserStatusListener)connection.getUserStatusListeners().get(i);
/* 48 */       l.onOffgoingUser(e);
/*    */     }
/*    */   }
/*    */ 
/*    */   public String getUserId() {
/* 53 */     return this.userId.getStringValue();
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.received.byddylist.OffgoingUser__3_12
 * JD-Core Version:    0.6.0
 */