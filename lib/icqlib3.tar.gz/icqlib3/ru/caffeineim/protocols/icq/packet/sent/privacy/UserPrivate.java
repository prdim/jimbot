/*    */ package ru.caffeineim.protocols.icq.packet.sent.privacy;
/*    */ 
/*    */ import ru.caffeineim.protocols.icq.Flap;
/*    */ import ru.caffeineim.protocols.icq.RawData;
/*    */ import ru.caffeineim.protocols.icq.Snac;
/*    */ 
/*    */ public class UserPrivate extends Flap
/*    */ {
/*    */   public static final byte VIS_ALL = 1;
/*    */   public static final byte UNVIS_ALL = 2;
/*    */   public static final byte VIS_LIST = 3;
/*    */   public static final byte UNVIS_LIST = 4;
/*    */   public static final byte CONTACT_LIST = 5;
/*    */ 
/*    */   public UserPrivate()
/*    */   {
/* 24 */     super(2);
/* 25 */     Snac snac = new Snac(19, 9, 0, 9, 0);
/* 26 */     snac.addDataField(new RawData(0));
/* 27 */     snac.addDataField(new RawData(new byte[] { 0, 4, 0, 33, 0, -54, 0, 1 }));
/* 28 */     snac.addDataField(new RawData(1));
/* 29 */     snac.addDataField(new RawData(new byte[] { 0, -48, 0, 1, 1, 0, -47, 0, 1, 1, 0, -46, 0, 1, 1, 0, -45, 0, 1, 1, 0, -53, 0, 4, -1, -1, -1, -1 }));
/*    */ 
/* 33 */     addSnac(snac);
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.sent.privacy.UserPrivate
 * JD-Core Version:    0.6.0
 */