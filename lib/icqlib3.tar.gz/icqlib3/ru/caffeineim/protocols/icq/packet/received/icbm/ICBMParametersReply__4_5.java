/*    */ package ru.caffeineim.protocols.icq.packet.received.icbm;
/*    */ 
/*    */ import ru.caffeineim.protocols.icq.core.OscarConnection;
/*    */ import ru.caffeineim.protocols.icq.packet.received.ReceivedPacket;
/*    */ import ru.caffeineim.protocols.icq.packet.sent.icbm.ICBMSetParameters;
/*    */ import ru.caffeineim.protocols.icq.packet.sent.privacy.BosRightsRequest;
/*    */ 
/*    */ public class ICBMParametersReply__4_5 extends ReceivedPacket
/*    */ {
/*    */   public ICBMParametersReply__4_5(byte[] array)
/*    */   {
/* 31 */     super(array, true);
/*    */   }
/*    */ 
/*    */   public void execute(OscarConnection connection) {
/* 35 */     connection.sendFlap(new ICBMSetParameters());
/* 36 */     connection.sendFlap(new BosRightsRequest());
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.received.icbm.ICBMParametersReply__4_5
 * JD-Core Version:    0.6.0
 */