/*    */ package ru.caffeineim.protocols.icq.packet.received.authorization;
/*    */ 
/*    */ import java.util.List;
/*    */ import ru.caffeineim.protocols.icq.core.OscarConnection;
/*    */ import ru.caffeineim.protocols.icq.integration.events.UINRegistrationFailedEvent;
/*    */ import ru.caffeineim.protocols.icq.integration.listeners.MetaInfoListener;
/*    */ import ru.caffeineim.protocols.icq.packet.received.ReceivedPacket;
/*    */ 
/*    */ public class UINRegistrationFailed__23_1 extends ReceivedPacket
/*    */ {
/*    */   public UINRegistrationFailed__23_1(byte[] array)
/*    */   {
/* 30 */     super(array, true);
/*    */   }
/*    */ 
/*    */   public void notifyEvent(OscarConnection connection) {
/* 34 */     UINRegistrationFailedEvent e = new UINRegistrationFailedEvent(this);
/* 35 */     for (int i = 0; i < connection.getMetaInfoListeners().size(); i++) {
/* 36 */       MetaInfoListener l = (MetaInfoListener)connection.getMessagingListeners().get(i);
/* 37 */       l.onRegisterNewUINFailed(e);
/*    */     }
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.received.authorization.UINRegistrationFailed__23_1
 * JD-Core Version:    0.6.0
 */