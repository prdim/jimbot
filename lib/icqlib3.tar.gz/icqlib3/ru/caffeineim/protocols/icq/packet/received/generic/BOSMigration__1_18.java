/*    */ package ru.caffeineim.protocols.icq.packet.received.generic;
/*    */ 
/*    */ import ru.caffeineim.protocols.icq.RawData;
/*    */ import ru.caffeineim.protocols.icq.Tlv;
/*    */ import ru.caffeineim.protocols.icq.core.OscarConnection;
/*    */ import ru.caffeineim.protocols.icq.packet.received.ReceivedPacket;
/*    */ 
/*    */ public class BOSMigration__1_18 extends ReceivedPacket
/*    */ {
/*    */   private Tlv server;
/*    */   private Tlv cookie;
/*    */ 
/*    */   public BOSMigration__1_18(byte[] array)
/*    */   {
/* 32 */     super(array, true);
/* 33 */     byte[] data = getSnac().getDataFieldByteArray();
/* 34 */     int nbFamilies = new RawData(data, 0, 2).getValue();
/* 35 */     this.server = new Tlv(data, 2 + 2 * nbFamilies);
///* 36 */     Log.info(this.server.getStringValue());
/* 37 */     this.cookie = new Tlv(data, 2 + 2 * nbFamilies + this.server.getLength());
/*    */   }
/*    */ 
/*    */   public void execute(OscarConnection connection) {
/* 41 */     connection.close();
/*    */   }
/*    */ 
/*    */   public void notifyEvent(OscarConnection oscarconnection) {
/*    */   }
/*    */ 
/*    */   public String getBOSAddress() {
/* 48 */     return this.server.getStringValue();
/*    */   }
/*    */ 
/*    */   public String getCookie() {
/* 52 */     return this.cookie.getStringValue();
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.received.generic.BOSMigration__1_18
 * JD-Core Version:    0.6.0
 */