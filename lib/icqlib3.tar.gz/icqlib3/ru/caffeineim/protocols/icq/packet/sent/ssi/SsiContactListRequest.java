/*    */ package ru.caffeineim.protocols.icq.packet.sent.ssi;
/*    */ 
/*    */ import ru.caffeineim.protocols.icq.Flap;
/*    */ import ru.caffeineim.protocols.icq.Snac;
/*    */ 
/*    */ public class SsiContactListRequest extends Flap
/*    */ {
/*    */   public SsiContactListRequest()
/*    */   {
/* 28 */     super(2);
/* 29 */     Snac snac = new Snac(19, 4, 0, 0, 0);
/* 30 */     addSnac(snac);
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.sent.ssi.SsiContactListRequest
 * JD-Core Version:    0.6.0
 */