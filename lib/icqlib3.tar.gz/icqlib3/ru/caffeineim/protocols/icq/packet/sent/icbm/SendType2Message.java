/*     */ package ru.caffeineim.protocols.icq.packet.sent.icbm;
/*     */ 
/*     */ import ru.caffeineim.protocols.icq.RawData;
/*     */ import ru.caffeineim.protocols.icq.Snac;
/*     */ import ru.caffeineim.protocols.icq.Tlv;
/*     */ import ru.caffeineim.protocols.icq.exceptions.ConvertStringException;
/*     */ import ru.caffeineim.protocols.icq.setting.enumerations.MessageChannelEnum;
/*     */ import ru.caffeineim.protocols.icq.tool.StringTools;
/*     */ 
/*     */ public class SendType2Message extends SendMessage
/*     */ {
/*  31 */   private static final byte[] CAPABILITY1 = { 9, 70, 19, 73, 76, 127, 17, -47, -126, 34, 68, 69, 83, 84, 0, 0 };
/*     */ 
/*  36 */   private static final byte[] CAPABILITY2 = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
/*     */ 
/*  41 */   private static final byte[] UNKNOWN = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
/*     */ 
/*  45 */   private static final byte[] CAP_UTF8_GUID = { 123, 48, 57, 52, 54, 49, 51, 52, 69, 45, 52, 67, 55, 70, 45, 49, 49, 68, 49, 45, 56, 50, 50, 50, 45, 52, 52, 52, 53, 53, 51, 53, 52, 48, 48, 48, 48, 125 };
/*     */ 
/*     */   public SendType2Message(String uin, String message)
/*     */     throws ConvertStringException
/*     */   {
/*  56 */     super(uin, new MessageChannelEnum(2));
/*     */ 
/*  59 */     Tlv tlv5 = new Tlv(0, 2, 5);
/*     */ 
/*  62 */     tlv5.appendRawDataToTlv(new RawData(0, 4));
/*     */ 
/*  65 */     tlv5.appendRawDataToTlv(new RawData(0, 4));
/*     */ 
/*  68 */     tlv5.appendRawDataToTlv(new RawData(CAPABILITY1));
/*     */ 
/*  71 */     tlv5.appendTlvToTlv(new Tlv(1, 2, 10));
/*     */ 
/*  74 */     tlv5.appendRawDataToTlv(new RawData(983040, 4));
/*     */ 
/*  77 */     Tlv tlv2711 = new Tlv(6912, 2, 10001);
/*     */ 
/*  80 */     tlv2711.appendRawDataToTlv(new RawData(2816, 2));
/*     */ 
/*  83 */     tlv2711.appendRawDataToTlv(new RawData(CAPABILITY2));
/*     */ 
/*  86 */     tlv2711.appendRawDataToTlv(new RawData(3, 3));
/*     */ 
/*  89 */     tlv2711.appendRawDataToTlv(new RawData(0, 4));
/*     */ 
/*  92 */     tlv2711.appendRawDataToTlv(new RawData(65535, 2));
/*     */ 
/*  95 */     tlv2711.appendRawDataToTlv(new RawData(3584, 2));
/*     */ 
/*  98 */     tlv2711.appendRawDataToTlv(new RawData(65535, 2));
/*     */ 
/* 101 */     tlv2711.appendRawDataToTlv(new RawData(UNKNOWN));
/*     */ 
/* 104 */     tlv2711.appendRawDataToTlv(new RawData(256, 2));
/*     */ 
/* 107 */     tlv2711.appendRawDataToTlv(new RawData(0, 2));
/*     */ 
/* 110 */     tlv2711.appendRawDataToTlv(new RawData(8448, 2));
/*     */ 
/* 114 */     byte[] msg = StringTools.stringToByteArray(message);
/* 115 */     RawData rLen = new RawData(msg.length + 1, 2);
/* 116 */     rLen.invertIndianness();
/* 117 */     tlv2711.appendRawDataToTlv(rLen);
/*     */ 
/* 120 */     tlv2711.appendRawDataToTlv(new RawData(msg));
/* 121 */     tlv2711.appendRawDataToTlv(new RawData(0, 1));
/*     */ 
/* 124 */     tlv2711.appendRawDataToTlv(new RawData(0, 4));
/*     */ 
/* 127 */     tlv2711.appendRawDataToTlv(new RawData(-256, 4));
/*     */ 
/* 130 */     tlv2711.appendRawDataToTlv(new RawData(637534208, 4));
/*     */ 
/* 133 */     tlv2711.appendRawDataToTlv(new RawData(CAP_UTF8_GUID));
/*     */ 
/* 135 */     tlv5.appendTlvToTlv(tlv2711);
/* 136 */     this.snac.addTlvToSnac(tlv5);
/*     */ 
/* 139 */     this.snac.addRawDataToSnac(new RawData(3, 2));
/*     */ 
/* 142 */     this.snac.addRawDataToSnac(new RawData(0, 2));
/* 143 */     addSnac(this.snac);
/*     */   }
/*     */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.sent.icbm.SendType2Message
 * JD-Core Version:    0.6.0
 */