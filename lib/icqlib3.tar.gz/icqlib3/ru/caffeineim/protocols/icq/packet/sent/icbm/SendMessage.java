/*    */ package ru.caffeineim.protocols.icq.packet.sent.icbm;
/*    */ 
/*    */ import ru.caffeineim.protocols.icq.Flap;
/*    */ import ru.caffeineim.protocols.icq.RawData;
/*    */ import ru.caffeineim.protocols.icq.Snac;
/*    */ import ru.caffeineim.protocols.icq.setting.enumerations.MessageChannelEnum;
/*    */ 
/*    */ public abstract class SendMessage extends Flap
/*    */ {
/*    */   protected Snac snac;
/*    */   protected RawData channel;
/*    */ 
/*    */   public SendMessage(String userId, MessageChannelEnum messageChannel)
/*    */   {
/* 38 */     super(2);
/*    */ 
/* 40 */     this.snac = new Snac(4, 6, 0, 0, 0);
/*    */ 
/* 43 */     this.snac.addRawDataToSnac(new RawData((int)(System.currentTimeMillis() / 1000000L), 4));
/*    */ 
/* 46 */     this.snac.addRawDataToSnac(new RawData(0, 4));
/*    */ 
/* 49 */     this.channel = new RawData(messageChannel.getChannelNumber(), 2);
/* 50 */     this.snac.addRawDataToSnac(this.channel);
/*    */ 
/* 53 */     this.snac.addRawDataToSnac(new RawData(userId.length(), 1));
/* 54 */     this.snac.addRawDataToSnac(new RawData(userId));
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.sent.icbm.SendMessage
 * JD-Core Version:    0.6.0
 */