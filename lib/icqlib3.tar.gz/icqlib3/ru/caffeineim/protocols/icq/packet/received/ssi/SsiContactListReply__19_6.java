/*    */ package ru.caffeineim.protocols.icq.packet.received.ssi;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import java.util.SortedMap;
/*    */ import java.util.TreeMap;
/*    */ import ru.caffeineim.protocols.icq.Item;
/*    */ import ru.caffeineim.protocols.icq.RawData;
/*    */ import ru.caffeineim.protocols.icq.Snac;
/*    */ import ru.caffeineim.protocols.icq.core.OscarConnection;
/*    */ import ru.caffeineim.protocols.icq.exceptions.ConvertStringException;
/*    */ import ru.caffeineim.protocols.icq.integration.events.ContactListEvent;
/*    */ import ru.caffeineim.protocols.icq.integration.listeners.ContactListListener;
/*    */ import ru.caffeineim.protocols.icq.packet.received.ReceivedPacket;
/*    */ 
/*    */ public final class SsiContactListReply__19_6 extends ReceivedPacket
/*    */ {
/*    */   private int version;
/*    */   private int count;
/*    */   private int lastChangeTime;
/* 42 */   private SortedMap<Integer, Item> items = new TreeMap();
/*    */ 
/*    */   public SsiContactListReply__19_6(byte[] array) throws ConvertStringException {
/* 45 */     super(array, true);
/* 46 */     int position = 8;
/* 47 */     byte[] data = getSnac().getDataFieldByteArray();
/* 48 */     this.version = new RawData(data, position, 1).getValue();
/* 49 */     position++;
/* 50 */     this.count = new RawData(data, position, 2).getValue();
/* 51 */     position += 2;
/*    */ 
/* 53 */     for (int i = 0; i < this.count; i++) {
/* 54 */       Item item = new Item(data, position);
/* 55 */       int id = (item.getGroup() << 16) + item.getId();
/* 56 */       this.items.put(Integer.valueOf(id), item);
/* 57 */       position += item.getLength();
/*    */     }
/*    */ 
/* 60 */     this.lastChangeTime = new RawData(data, position, 4).getValue();
/* 61 */     position += 4;
/*    */   }
/*    */ 
/*    */   public void execute(OscarConnection connection) {
/*    */   }
/*    */ 
/*    */   public void notifyEvent(OscarConnection connection) {
/* 68 */     ContactListEvent e = new ContactListEvent(this);
/*    */ 
/* 70 */     connection.buildContactList(e.getRoot(), getCount());
/*    */ 
/* 72 */     for (int i = 0; i < connection.getContactListListeners().size(); i++) {
/* 73 */       ContactListListener l = (ContactListListener)connection.getContactListListeners().get(i);
/* 74 */       l.onUpdateContactList(e);
/*    */     }
/*    */   }
/*    */ 
/*    */   public int getCount() {
/* 79 */     return this.count;
/*    */   }
/*    */ 
/*    */   public int getLastChangeTime() {
/* 83 */     return this.lastChangeTime;
/*    */   }
/*    */ 
/*    */   public Iterator<Item> getItemsIterator() {
/* 87 */     return this.items.values().iterator();
/*    */   }
/*    */ 
/*    */   public Item get(int id) {
/* 91 */     return (Item)this.items.get(Integer.valueOf(id));
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.received.ssi.SsiContactListReply__19_6
 * JD-Core Version:    0.6.0
 */