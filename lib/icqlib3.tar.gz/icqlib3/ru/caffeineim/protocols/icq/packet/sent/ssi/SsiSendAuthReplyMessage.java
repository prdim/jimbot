/*    */ package ru.caffeineim.protocols.icq.packet.sent.ssi;
/*    */ 
/*    */ import ru.caffeineim.protocols.icq.Flap;
/*    */ import ru.caffeineim.protocols.icq.RawData;
/*    */ import ru.caffeineim.protocols.icq.Snac;
/*    */ import ru.caffeineim.protocols.icq.exceptions.ConvertStringException;
/*    */ import ru.caffeineim.protocols.icq.tool.StringTools;
/*    */ 
/*    */ public class SsiSendAuthReplyMessage extends Flap
/*    */ {
/*    */   public SsiSendAuthReplyMessage(String uin, String message, boolean auth)
/*    */     throws ConvertStringException
/*    */   {
/* 36 */     super(2);
/* 37 */     Snac snac = new Snac(19, 26, 0, 0, 26);
/*    */ 
/* 40 */     snac.addRawDataToSnac(new RawData(uin.length(), 1));
/*    */ 
/* 43 */     snac.addRawDataToSnac(new RawData(uin));
/*    */ 
/* 46 */     snac.addRawDataToSnac(new RawData(auth ? 1 : 0, 1));
/*    */ 
/* 48 */     byte[] msg = StringTools.stringToByteArray(message);
/*    */ 
/* 51 */     snac.addRawDataToSnac(new RawData(msg.length, 2));
/*    */ 
/* 54 */     snac.addRawDataToSnac(new RawData(msg));
/*    */ 
/* 57 */     snac.addRawDataToSnac(new RawData(0, 2));
/*    */ 
/* 59 */     addSnac(snac);
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.sent.ssi.SsiSendAuthReplyMessage
 * JD-Core Version:    0.6.0
 */