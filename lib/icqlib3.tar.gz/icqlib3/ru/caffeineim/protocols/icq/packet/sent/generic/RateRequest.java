/*    */ package ru.caffeineim.protocols.icq.packet.sent.generic;
/*    */ 
/*    */ import ru.caffeineim.protocols.icq.Flap;
/*    */ import ru.caffeineim.protocols.icq.Snac;
/*    */ 
/*    */ public class RateRequest extends Flap
/*    */ {
/*    */   public RateRequest()
/*    */   {
/* 28 */     super(2);
/*    */ 
/* 30 */     Snac snac = new Snac(1, 6, 0, 0, 0);
/* 31 */     addSnac(snac);
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.sent.generic.RateRequest
 * JD-Core Version:    0.6.0
 */