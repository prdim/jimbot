/*    */ package ru.caffeineim.protocols.icq.packet.sent.meta;
/*    */ 
/*    */ import ru.caffeineim.protocols.icq.Flap;
/*    */ import ru.caffeineim.protocols.icq.RawData;
/*    */ import ru.caffeineim.protocols.icq.Snac;
/*    */ import ru.caffeineim.protocols.icq.Tlv;
/*    */ 
/*    */ public abstract class BaseClientMeta extends Flap
/*    */ {
/*    */   protected Snac snac;
/*    */   protected Tlv tlv;
/*    */ 
/*    */   public BaseClientMeta(int lenght, String uinForRequest, int type)
/*    */   {
/* 40 */     super(2);
/* 41 */     this.snac = new Snac(21, 2, 0, 0, 0);
/*    */ 
/* 44 */     this.tlv = new Tlv(1);
/*    */ 
/* 47 */     this.tlv.appendRawDataToTlv(new RawData(lenght, 2));
/*    */ 
/* 50 */     RawData rUin = new RawData(Integer.parseInt(uinForRequest), 4);
/* 51 */     rUin.invertIndianness();
/* 52 */     this.tlv.appendRawDataToTlv(rUin);
/*    */ 
/* 55 */     RawData rdType = new RawData(type, 2);
/* 56 */     rdType.invertIndianness();
/* 57 */     this.tlv.appendRawDataToTlv(rdType);
/*    */ 
/* 60 */     this.tlv.appendRawDataToTlv(new RawData(512, 2));
/*    */   }
/*    */ 
/*    */   public BaseClientMeta(int lenght, String uinForRequest, int type, int subType)
/*    */   {
/* 72 */     this(lenght, uinForRequest, type);
/*    */ 
/* 75 */     RawData rdSubType = new RawData(subType, 2);
/* 76 */     rdSubType.invertIndianness();
/* 77 */     this.tlv.appendRawDataToTlv(rdSubType);
/*    */   }
/*    */ 
/*    */   public void finalizePacket() {
/* 81 */     this.snac.addTlvToSnac(this.tlv);
/* 82 */     addSnac(this.snac);
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.sent.meta.BaseClientMeta
 * JD-Core Version:    0.6.0
 */