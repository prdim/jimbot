/*     */ package ru.caffeineim.protocols.icq.packet.received;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import ru.caffeineim.protocols.icq.Tlv;
/*     */ import ru.caffeineim.protocols.icq.core.OscarClient;
/*     */ import ru.caffeineim.protocols.icq.core.OscarConnection;
/*     */ import ru.caffeineim.protocols.icq.core.exceptions.LoginException;
/*     */ import ru.caffeineim.protocols.icq.setting.enumerations.LoginErrorTypeEnum;
/*     */ 
/*     */ public class AuthorizationReply extends ReceivedPacket
/*     */ {
/*     */   private Tlv uin;
/*     */   private Tlv bosServerAddress;
/*     */   private Tlv cookie;
/*     */   private Tlv errorCode;
/*     */   private Tlv url;
/*  37 */   private boolean readyToConnect = false;
/*     */ 
/*     */   public AuthorizationReply(byte[] packet)
/*     */   {
/*  45 */     super(packet, false);
/*     */ 
/*  47 */     Tlv tempTlv = null;
/*  48 */     for (int position = 0; position < getDataFieldByteArray().length; position += tempTlv.getByteArray().length) {
/*  49 */       tempTlv = new Tlv(getDataFieldByteArray(), position);
/*     */ 
/*  51 */       switch (tempTlv.getType())
/*     */       {
/*     */       case 1:
/*  54 */         this.uin = tempTlv;
/*  55 */         break;
/*     */       case 4:
/*  58 */         this.url = tempTlv;
/*  59 */         break;
/*     */       case 5:
/*  62 */         this.bosServerAddress = tempTlv;
/*  63 */         break;
/*     */       case 6:
/*  66 */         this.cookie = tempTlv;
/*  67 */         this.readyToConnect = true;
/*  68 */         break;
/*     */       case 8:
/*  71 */         this.errorCode = tempTlv;
/*     */       case 2:
/*     */       case 3:
/*     */       case 7:
/*     */       }
/*     */     }
///*  76 */     Log.info(this.uin.getStringValue() + " conected to: " + this.bosServerAddress.getStringValue());
/*     */   }
/*     */ 
/*     */   public void execute(OscarConnection connection) throws LoginException {
/*     */     try {
/*  81 */       if (this.readyToConnect)
/*  82 */         connectToBos(connection);
/*     */       else
/*  84 */         throw new LoginException(getErrorType());
/*     */     }
/*     */     catch (IOException IOE) {
/*  87 */       throw new LoginException(IOE.getMessage(), IOE);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void connectToBos(OscarConnection connection) throws IOException
/*     */   {
/*  93 */     connection.getClient().disconnect();
/*     */ 
/*  95 */     OscarClient bosClient = new OscarClient(getBosServerAddress(), getBosServerPort(), connection.getPacketAnalyser());
/*     */ 
/*  99 */     connection.setClient(bosClient);
/*     */ 
/* 101 */     connection.setCookie(this.cookie);
/*     */ 
/* 103 */     connection.getClient().connect();
/*     */   }
/*     */ 
/*     */   public String getUin()
/*     */   {
/* 112 */     return this.uin.getStringValue();
/*     */   }
/*     */ 
/*     */   public String getBosServerAddress()
/*     */   {
/* 121 */     int dbpt = this.bosServerAddress.getStringValue().indexOf(':');
/* 122 */     return this.bosServerAddress.getStringValue().substring(0, dbpt);
/*     */   }
/*     */ 
/*     */   public int getBosServerPort()
/*     */   {
/* 131 */     int dbpt = this.bosServerAddress.getStringValue().indexOf(':');
/* 132 */     return Integer.parseInt(this.bosServerAddress.getStringValue().substring(dbpt + 1, this.bosServerAddress.getStringValue().length()));
/*     */   }
/*     */ 
/*     */   public Tlv getCookie()
/*     */   {
/* 142 */     return this.cookie;
/*     */   }
/*     */ 
/*     */   public int getErrorcode()
/*     */   {
/* 151 */     return this.errorCode.getValue();
/*     */   }
/*     */ 
/*     */   public String getUrl()
/*     */   {
/* 161 */     return this.url.getStringValue();
/*     */   }
/*     */ 
/*     */   private LoginErrorTypeEnum getErrorType() {
/* 165 */     if (this.errorCode != null) {
/* 166 */       switch (this.errorCode.getValue()) {
/*     */       case 1:
/* 168 */         return new LoginErrorTypeEnum(1);
/*     */       case 4:
/*     */       case 5:
/* 172 */         return new LoginErrorTypeEnum(2);
/*     */       case 7:
/*     */       case 8:
/* 176 */         return new LoginErrorTypeEnum(3);
/*     */       case 22:
/*     */       case 23:
/* 180 */         return new LoginErrorTypeEnum(5);
/*     */       case 24:
/*     */       case 29:
/* 184 */         return new LoginErrorTypeEnum(4);
/*     */       case 27:
/*     */       case 28:
/* 188 */         return new LoginErrorTypeEnum(6);
/*     */       case 30:
/* 191 */         return new LoginErrorTypeEnum(7);
/*     */       case 2:
/*     */       case 3:
/*     */       case 6:
/*     */       case 9:
/*     */       case 10:
/*     */       case 11:
/*     */       case 12:
/*     */       case 13:
/*     */       case 14:
/*     */       case 15:
/*     */       case 16:
/*     */       case 17:
/*     */       case 18:
/*     */       case 19:
/*     */       case 20:
/*     */       case 21:
/*     */       case 25:
/* 194 */       case 26: } return new LoginErrorTypeEnum(0);
/*     */     }
/*     */ 
/* 198 */     return new LoginErrorTypeEnum(0);
/*     */   }
/*     */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.received.AuthorizationReply
 * JD-Core Version:    0.6.0
 */