/*    */ package ru.caffeineim.protocols.icq.packet.sent.generic;
/*    */ 
/*    */ import ru.caffeineim.protocols.icq.Flap;
/*    */ import ru.caffeineim.protocols.icq.RawData;
/*    */ import ru.caffeineim.protocols.icq.Tlv;
/*    */ 
/*    */ public class SignonCommand extends Flap
/*    */ {
/*    */   public SignonCommand(Tlv cookie)
/*    */   {
/* 29 */     super(1);
/*    */ 
/* 33 */     addRawDataToFlap(new RawData(1, 4));
/*    */ 
/* 35 */     addTlvToFlap(cookie);
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.sent.generic.SignonCommand
 * JD-Core Version:    0.6.0
 */