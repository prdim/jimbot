/*    */ package ru.caffeineim.protocols.icq.packet.received.ssi;
/*    */ 
/*    */ import java.util.List;
/*    */ import ru.caffeineim.protocols.icq.RawData;
/*    */ import ru.caffeineim.protocols.icq.Snac;
/*    */ import ru.caffeineim.protocols.icq.core.OscarConnection;
/*    */ import ru.caffeineim.protocols.icq.integration.events.SsiModifyingAckEvent;
/*    */ import ru.caffeineim.protocols.icq.integration.listeners.ContactListListener;
/*    */ import ru.caffeineim.protocols.icq.packet.received.ReceivedPacket;
/*    */ import ru.caffeineim.protocols.icq.setting.enumerations.SsiResultModeEnum;
/*    */ 
/*    */ public class SsiModifyingAck__19_14 extends ReceivedPacket
/*    */ {
/*    */   private SsiResultModeEnum[] results;
/*    */ 
/*    */   public SsiModifyingAck__19_14(byte[] array)
/*    */   {
/* 34 */     super(array, true);
/* 35 */     int position = 0;
/*    */ 
/* 37 */     byte[] data = getSnac().getDataFieldByteArray();
/*    */ 
/* 40 */     int count = data.length / 2;
/* 41 */     this.results = new SsiResultModeEnum[count];
/* 42 */     for (int i = 0; i < count; i++) {
/* 43 */       this.results[i] = new SsiResultModeEnum(new RawData(data, position, 2).getValue());
/* 44 */       position += 2;
/*    */     }
/*    */   }
/*    */ 
/*    */   public void notifyEvent(OscarConnection connection) {
/* 49 */     SsiModifyingAckEvent e = new SsiModifyingAckEvent(this);
/* 50 */     for (int i = 0; i < connection.getContactListListeners().size(); i++) {
/* 51 */       ContactListListener l = (ContactListListener)connection.getContactListListeners().get(i);
/* 52 */       l.onSsiModifyingAck(e);
/*    */     }
/*    */   }
/*    */ 
/*    */   public SsiResultModeEnum[] getResuls() {
/* 57 */     return this.results;
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.received.ssi.SsiModifyingAck__19_14
 * JD-Core Version:    0.6.0
 */