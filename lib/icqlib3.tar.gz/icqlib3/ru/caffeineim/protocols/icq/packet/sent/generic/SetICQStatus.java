/*    */ package ru.caffeineim.protocols.icq.packet.sent.generic;
/*    */ 
/*    */ import ru.caffeineim.protocols.icq.Flap;
/*    */ import ru.caffeineim.protocols.icq.RawData;
/*    */ import ru.caffeineim.protocols.icq.Snac;
/*    */ import ru.caffeineim.protocols.icq.Tlv;
/*    */ import ru.caffeineim.protocols.icq.setting.enumerations.StatusFlagEnum;
/*    */ import ru.caffeineim.protocols.icq.setting.enumerations.StatusModeEnum;
/*    */ import ru.caffeineim.protocols.icq.setting.enumerations.TcpConnectionFlagEnum;
/*    */ 
/*    */ public class SetICQStatus extends Flap
/*    */ {
/* 32 */   private static final byte[] unknownFields = { 0, 11, 0, 0, 0, 0, 0, 0, 0, 80, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
/*    */ 
/*    */   public SetICQStatus(int statusMode, StatusFlagEnum statusFlag, TcpConnectionFlagEnum tcpConnectionFlag, byte[] localIP, int p2pPort)
/*    */   {
/* 45 */     super(2);
/* 46 */     Snac snac = new Snac(1, 30, 0, 0, 0);
/*    */ 
/* 48 */     snac.addTlvToSnac(new Tlv(statusMode | statusFlag.getFlag(), 4, 6));
/*    */ 
/* 50 */     snac.addTlvToSnac(new Tlv(0, 2, 8));
/*    */ 
/* 52 */     snac.addRawDataToSnac(new RawData(786469, 4));
/*    */ 
/* 55 */     snac.addRawDataToSnac(new RawData(localIP));
/*    */ 
/* 57 */     snac.addRawDataToSnac(new RawData(p2pPort, 4));
/* 58 */     snac.addRawDataToSnac(new RawData(tcpConnectionFlag.getTcpConnectionFlag(), 1));
/*    */ 
/* 61 */     snac.addRawDataToSnac(new RawData(unknownFields));
/*    */ 
/* 63 */     addSnac(snac);
/*    */   }
/*    */ 
/*    */   public SetICQStatus(int statusMode)
/*    */   {
/* 69 */     super(2);
/* 70 */     Snac snac = new Snac(1, 30, 0, 0, 0);
/*    */ 
/* 72 */     snac.addTlvToSnac(new Tlv(StatusModeEnum.Mode(statusMode), 4, 6));
/* 73 */     addSnac(snac);
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.sent.generic.SetICQStatus
 * JD-Core Version:    0.6.0
 */