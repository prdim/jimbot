/*    */ package ru.caffeineim.protocols.icq.packet.sent.buddylist;
/*    */ 
/*    */ import ru.caffeineim.protocols.icq.Flap;
/*    */ import ru.caffeineim.protocols.icq.Snac;
/*    */ 
/*    */ public class BuddyListRightsRequest extends Flap
/*    */ {
/*    */   public BuddyListRightsRequest()
/*    */   {
/* 28 */     super(2);
/*    */ 
/* 30 */     Snac snac = new Snac(3, 2, 0, 0, 0);
/* 31 */     addSnac(snac);
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.sent.buddylist.BuddyListRightsRequest
 * JD-Core Version:    0.6.0
 */