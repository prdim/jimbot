/*    */ package ru.caffeineim.protocols.icq.packet.received.icbm;
/*    */ 
/*    */ import java.util.List;
/*    */ import ru.caffeineim.protocols.icq.RawData;
/*    */ import ru.caffeineim.protocols.icq.Snac;
/*    */ import ru.caffeineim.protocols.icq.core.OscarConnection;
/*    */ import ru.caffeineim.protocols.icq.integration.events.MessageErrorEvent;
/*    */ import ru.caffeineim.protocols.icq.integration.listeners.MessagingListener;
/*    */ import ru.caffeineim.protocols.icq.packet.received.ReceivedPacket;
/*    */ import ru.caffeineim.protocols.icq.setting.enumerations.GlobalErrorsEnum;
/*    */ 
/*    */ public class ServerICBMError__4_1 extends ReceivedPacket
/*    */ {
/*    */   private GlobalErrorsEnum error;
/*    */ 
/*    */   public ServerICBMError__4_1(byte[] array)
/*    */   {
/* 36 */     super(array, true);
/*    */ 
/* 38 */     byte[] data = getSnac().getDataFieldByteArray();
/*    */ 
/* 41 */     RawData code = new RawData(data, 0, 2);
/*    */ 
/* 43 */     this.error = new GlobalErrorsEnum(code.getValue());
/*    */   }
/*    */ 
/*    */   public GlobalErrorsEnum getError() {
/* 47 */     return this.error;
/*    */   }
/*    */ 
/*    */   public void notifyEvent(OscarConnection connection) {
/* 51 */     MessageErrorEvent e = new MessageErrorEvent(this);
/* 52 */     for (int i = 0; i < connection.getMessagingListeners().size(); i++) {
/* 53 */       MessagingListener l = (MessagingListener)connection.getMessagingListeners().get(i);
/* 54 */       l.onMessageError(e);
/*    */     }
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.received.icbm.ServerICBMError__4_1
 * JD-Core Version:    0.6.0
 */