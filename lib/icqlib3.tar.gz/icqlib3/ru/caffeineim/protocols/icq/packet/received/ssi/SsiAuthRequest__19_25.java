/*    */ package ru.caffeineim.protocols.icq.packet.received.ssi;
/*    */ 
/*    */ import java.util.List;
/*    */ import ru.caffeineim.protocols.icq.RawData;
/*    */ import ru.caffeineim.protocols.icq.Snac;
/*    */ import ru.caffeineim.protocols.icq.core.OscarConnection;
/*    */ import ru.caffeineim.protocols.icq.exceptions.ConvertStringException;
/*    */ import ru.caffeineim.protocols.icq.integration.events.SsiAuthRequestEvent;
/*    */ import ru.caffeineim.protocols.icq.integration.listeners.ContactListListener;
/*    */ import ru.caffeineim.protocols.icq.packet.received.ReceivedPacket;
/*    */ import ru.caffeineim.protocols.icq.tool.StringTools;
/*    */ 
/*    */ public class SsiAuthRequest__19_25 extends ReceivedPacket
/*    */ {
/*    */   private String senderUin;
/*    */   private String message;
/*    */ 
/*    */   public SsiAuthRequest__19_25(byte[] array)
/*    */     throws ConvertStringException
/*    */   {
/* 37 */     super(array, true);
/* 38 */     int position = 0;
/*    */ 
/* 40 */     byte[] data = getSnac().getDataFieldByteArray();
/*    */ 
/* 43 */     position += 8;
/*    */ 
/* 46 */     RawData len = new RawData(data[(position++)]);
/* 47 */     this.senderUin = new String(data, position, len.getValue());
/* 48 */     position += len.getValue();
/*    */ 
/* 51 */     len = new RawData(data, position, 2);
/* 52 */     position += 2;
/* 53 */     this.message = StringTools.utf8ByteArrayToString(data, position, len.getValue());
/*    */   }
/*    */ 
/*    */   public void notifyEvent(OscarConnection connection) {
/* 57 */     SsiAuthRequestEvent e = new SsiAuthRequestEvent(this);
/* 58 */     for (int i = 0; i < connection.getContactListListeners().size(); i++) {
/* 59 */       ContactListListener l = (ContactListListener)connection.getContactListListeners().get(i);
/* 60 */       l.onSsiAuthRequest(e);
/*    */     }
/*    */   }
/*    */ 
/*    */   public String getSenderUin() {
/* 65 */     return this.senderUin;
/*    */   }
/*    */ 
/*    */   public String getMessage() {
/* 69 */     return this.message;
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.received.ssi.SsiAuthRequest__19_25
 * JD-Core Version:    0.6.0
 */