/*    */ package ru.caffeineim.protocols.icq.packet.sent.meta;
/*    */ 
/*    */ public class RequestFullUserInfo extends RequestUserInfo
/*    */ {
/*    */   public RequestFullUserInfo(String uinSearch, String uinForRequest)
/*    */   {
/* 33 */     super(uinSearch, uinForRequest, 1202);
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.sent.meta.RequestFullUserInfo
 * JD-Core Version:    0.6.0
 */