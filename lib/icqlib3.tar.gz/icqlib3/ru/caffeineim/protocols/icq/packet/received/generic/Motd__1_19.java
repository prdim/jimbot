/*    */ package ru.caffeineim.protocols.icq.packet.received.generic;
/*    */ 
/*    */ import ru.caffeineim.protocols.icq.RawData;
/*    */ import ru.caffeineim.protocols.icq.Snac;
/*    */ import ru.caffeineim.protocols.icq.Tlv;
/*    */ import ru.caffeineim.protocols.icq.core.OscarConnection;
/*    */ import ru.caffeineim.protocols.icq.packet.received.ReceivedPacket;
/*    */ 
/*    */ public class Motd__1_19 extends ReceivedPacket
/*    */ {
/*    */   public static final short MTD_MDT_UPGRAGE = 1;
/*    */   public static final short MTD_ADV_UPGRAGE = 2;
/*    */   public static final short MTD_SYS_BULLETIN = 3;
/*    */   public static final short MTD_NORMAL = 4;
/*    */   public static final short MTD_NONE = 5;
/*    */   public static final short MTD_NEWS = 6;
/*    */   private short type;
/*    */   private String msg;
/*    */ 
/*    */   public Motd__1_19(byte[] array)
/*    */   {
/* 39 */     super(array, true);
/* 40 */     this.msg = null;
/* 41 */     byte[] data = getSnac().getDataFieldByteArray();
/* 42 */     this.type = (short)new RawData(data, 0, 2).getValue();
/* 43 */     Tlv tlv1 = new Tlv(data, 2);
/* 44 */     Tlv tlv2 = new Tlv(data, 6 + tlv1.getLength());
/*    */ 
/* 46 */     if (this.type != 5)
/* 47 */       this.msg = new Tlv(data, 10 + tlv1.getLength() + tlv2.getLength()).getStringValue();
/*    */   }
/*    */ 
/*    */   public short getType() {
/* 51 */     return this.type;
/*    */   }
/*    */ 
/*    */   public String getMessage() {
/* 55 */     return this.msg;
/*    */   }
/*    */ 
/*    */   public void notifyEvent(OscarConnection connection)
/*    */   {
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.received.generic.Motd__1_19
 * JD-Core Version:    0.6.0
 */