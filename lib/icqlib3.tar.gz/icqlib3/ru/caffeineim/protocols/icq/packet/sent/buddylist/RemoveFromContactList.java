/*    */ package ru.caffeineim.protocols.icq.packet.sent.buddylist;
/*    */ 
/*    */ import ru.caffeineim.protocols.icq.Flap;
/*    */ import ru.caffeineim.protocols.icq.RawData;
/*    */ import ru.caffeineim.protocols.icq.Snac;
/*    */ 
/*    */ public class RemoveFromContactList extends Flap
/*    */ {
/*    */   public RemoveFromContactList(String uin)
/*    */   {
/* 35 */     super(2);
/* 36 */     Snac snac = new Snac(3, 5, 0, 0, 0);
/*    */ 
/* 39 */     snac.addRawDataToSnac(new RawData(uin.length(), 1));
/*    */ 
/* 42 */     snac.addRawDataToSnac(new RawData(uin));
/*    */ 
/* 44 */     addSnac(snac);
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.sent.buddylist.RemoveFromContactList
 * JD-Core Version:    0.6.0
 */