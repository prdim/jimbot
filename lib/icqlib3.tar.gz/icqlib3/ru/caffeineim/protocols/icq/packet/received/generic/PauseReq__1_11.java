/*    */ package ru.caffeineim.protocols.icq.packet.received.generic;
/*    */ 
/*    */ import ru.caffeineim.protocols.icq.core.OscarConnection;
/*    */ import ru.caffeineim.protocols.icq.packet.received.ReceivedPacket;
/*    */ import ru.caffeineim.protocols.icq.packet.sent.generic.PauseAck;
/*    */ 
/*    */ public class PauseReq__1_11 extends ReceivedPacket
/*    */ {
/*    */   public PauseReq__1_11(byte[] array)
/*    */   {
/* 29 */     super(array, true);
/*    */   }
/*    */ 
/*    */   public void execute(OscarConnection connection) {
/* 33 */     connection.sendFlap(new PauseAck());
/*    */   }
/*    */ 
/*    */   public void notifyEvent(OscarConnection oscarconnection)
/*    */   {
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.received.generic.PauseReq__1_11
 * JD-Core Version:    0.6.0
 */