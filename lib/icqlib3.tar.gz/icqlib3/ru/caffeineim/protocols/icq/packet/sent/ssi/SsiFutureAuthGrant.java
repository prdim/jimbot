/*    */ package ru.caffeineim.protocols.icq.packet.sent.ssi;
/*    */ 
/*    */ import ru.caffeineim.protocols.icq.Flap;
/*    */ import ru.caffeineim.protocols.icq.RawData;
/*    */ import ru.caffeineim.protocols.icq.Snac;
/*    */ import ru.caffeineim.protocols.icq.exceptions.ConvertStringException;
/*    */ import ru.caffeineim.protocols.icq.tool.StringTools;
/*    */ 
/*    */ public class SsiFutureAuthGrant extends Flap
/*    */ {
/*    */   public SsiFutureAuthGrant(String uin, String message)
/*    */     throws ConvertStringException
/*    */   {
/* 35 */     super(2);
/* 36 */     Snac snac = new Snac(19, 20, 0, 0, 20);
/*    */ 
/* 39 */     snac.addRawDataToSnac(new RawData(uin.length(), 1));
/*    */ 
/* 42 */     snac.addRawDataToSnac(new RawData(uin));
/*    */ 
/* 45 */     snac.addRawDataToSnac(new RawData(message.length(), 2));
/*    */ 
/* 48 */     snac.addRawDataToSnac(new RawData(StringTools.stringToByteArray(message)));
/*    */ 
/* 51 */     snac.addRawDataToSnac(new RawData(0, 2));
/*    */ 
/* 53 */     addSnac(snac);
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.sent.ssi.SsiFutureAuthGrant
 * JD-Core Version:    0.6.0
 */