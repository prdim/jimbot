/*    */ package ru.caffeineim.protocols.icq.packet.sent.generic;
/*    */ 
/*    */ import ru.caffeineim.protocols.icq.Flap;
/*    */ import ru.caffeineim.protocols.icq.RawData;
/*    */ import ru.caffeineim.protocols.icq.Snac;
/*    */ import ru.caffeineim.protocols.icq.setting.enumerations.IdleTimeEnum;
/*    */ 
/*    */ public class SetIdleTime extends Flap
/*    */ {
/*    */   public SetIdleTime(IdleTimeEnum idleTimeMode)
/*    */   {
/* 30 */     super(2);
/* 31 */     Snac snac = new Snac(1, 17, 0, 0, 0);
/* 32 */     snac.addRawDataToSnac(new RawData(idleTimeMode.getIdleTimeMode(), 4));
/*    */ 
/* 34 */     addSnac(snac);
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.sent.generic.SetIdleTime
 * JD-Core Version:    0.6.0
 */