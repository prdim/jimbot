/*    */ package ru.caffeineim.protocols.icq.packet.received.location;
/*    */ 
/*    */ import ru.caffeineim.protocols.icq.core.OscarConnection;
/*    */ import ru.caffeineim.protocols.icq.packet.received.ReceivedPacket;
/*    */ import ru.caffeineim.protocols.icq.packet.sent.buddylist.BuddyListRightsRequest;
/*    */ import ru.caffeineim.protocols.icq.packet.sent.location.SetLocationInformation;
/*    */ 
/*    */ public class LocationRightsReply__2_3 extends ReceivedPacket
/*    */ {
/*    */   public LocationRightsReply__2_3(byte[] array)
/*    */   {
/* 30 */     super(array, true);
/*    */   }
/*    */ 
/*    */   public void execute(OscarConnection connection) {
/* 34 */     connection.sendFlap(new SetLocationInformation());
/* 35 */     connection.sendFlap(new BuddyListRightsRequest());
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.received.location.LocationRightsReply__2_3
 * JD-Core Version:    0.6.0
 */