/*    */ package ru.caffeineim.protocols.icq.packet.sent.icbm;
/*    */ 
/*    */ import ru.caffeineim.protocols.icq.RawData;
/*    */ import ru.caffeineim.protocols.icq.Snac;
/*    */ import ru.caffeineim.protocols.icq.Tlv;
/*    */ import ru.caffeineim.protocols.icq.setting.enumerations.MessageChannelEnum;
/*    */ 
/*    */ public class SendType4Message extends SendMessage
/*    */ {
/*    */   public SendType4Message(String senderUin, String receiverUin, String message)
/*    */   {
/* 31 */     super(receiverUin, new MessageChannelEnum(4));
/*    */ 
/* 33 */     Tlv tlv5 = new Tlv(5);
/*    */ 
/* 36 */     RawData senderId = new RawData(Integer.parseInt(senderUin), 4);
/* 37 */     senderId.invertIndianness();
/*    */ 
/* 39 */     tlv5.appendRawDataToTlv(senderId);
/*    */ 
/* 42 */     tlv5.appendRawDataToTlv(new RawData(1, 1));
/*    */ 
/* 45 */     tlv5.appendRawDataToTlv(new RawData(0, 1));
/*    */ 
/* 48 */     RawData messageLength = new RawData(message.length(), 2);
/* 49 */     messageLength.invertIndianness();
/* 50 */     tlv5.appendRawDataToTlv(messageLength);
/*    */ 
/* 53 */     tlv5.appendRawDataToTlv(new RawData(message));
/*    */ 
/* 56 */     this.snac.addTlvToSnac(tlv5);
/*    */ 
/* 59 */     this.snac.addRawDataToSnac(new RawData(3, 2));
/* 60 */     this.snac.addRawDataToSnac(new RawData(0, 2));
/*    */ 
/* 63 */     this.snac.addRawDataToSnac(new RawData(6, 2));
/* 64 */     this.snac.addRawDataToSnac(new RawData(0, 2));
/*    */ 
/* 66 */     addSnac(this.snac);
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.sent.icbm.SendType4Message
 * JD-Core Version:    0.6.0
 */