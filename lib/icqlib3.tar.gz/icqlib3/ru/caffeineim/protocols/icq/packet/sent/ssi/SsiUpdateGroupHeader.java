/*    */ package ru.caffeineim.protocols.icq.packet.sent.ssi;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import ru.caffeineim.protocols.icq.Flap;
/*    */ import ru.caffeineim.protocols.icq.RawData;
/*    */ import ru.caffeineim.protocols.icq.Snac;
/*    */ import ru.caffeineim.protocols.icq.Tlv;
/*    */ import ru.caffeineim.protocols.icq.contacts.ContactListItem;
/*    */ import ru.caffeineim.protocols.icq.contacts.Group;
/*    */ import ru.caffeineim.protocols.icq.exceptions.ConvertStringException;
/*    */ import ru.caffeineim.protocols.icq.tool.StringTools;
/*    */ 
/*    */ public class SsiUpdateGroupHeader extends Flap
/*    */ {
/*    */   public SsiUpdateGroupHeader(Group grp)
/*    */     throws ConvertStringException
/*    */   {
/* 40 */     super(2);
/* 41 */     Snac snac = new Snac(19, 9, 0, 0, 9);
/*    */ 
/* 43 */     byte[] groupId = StringTools.stringToByteArray(grp.getId());
/*    */ 
/* 46 */     snac.addRawDataToSnac(new RawData(groupId.length, 2));
/*    */ 
/* 49 */     snac.addRawDataToSnac(new RawData(groupId));
/*    */ 
/* 52 */     snac.addRawDataToSnac(new RawData(grp.getGroupId(), 2));
/*    */ 
/* 55 */     snac.addRawDataToSnac(new RawData(0, 2));
/*    */ 
/* 58 */     snac.addRawDataToSnac(new RawData(1, 2));
/*    */ 
/* 61 */     if ((grp.getContainedItems() != null) && (grp.getContainedItems().size() > 0))
/*    */     {
/* 64 */       snac.addRawDataToSnac(new RawData(4 + grp.getContainedItems().size() * 2, 2));
/*    */ 
/* 67 */       Tlv tlv = new Tlv(200);
/* 68 */       for (Iterator iter = grp.getContainedItems().iterator(); iter.hasNext(); ) {
/* 69 */         tlv.appendRawDataToTlv(new RawData(((ContactListItem)iter.next()).getItemId(), 2));
/*    */       }
/* 71 */       snac.addTlvToSnac(tlv);
/*    */     }
/*    */     else
/*    */     {
/* 75 */       snac.addRawDataToSnac(new RawData(0, 2));
/*    */     }
/*    */ 
/* 78 */     addSnac(snac);
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.sent.ssi.SsiUpdateGroupHeader
 * JD-Core Version:    0.6.0
 */