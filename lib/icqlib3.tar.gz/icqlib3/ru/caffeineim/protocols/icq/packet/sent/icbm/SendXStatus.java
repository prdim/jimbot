/*     */ package ru.caffeineim.protocols.icq.packet.sent.icbm;
/*     */ 
/*     */ import ru.caffeineim.protocols.icq.Flap;
/*     */ import ru.caffeineim.protocols.icq.RawData;
/*     */ import ru.caffeineim.protocols.icq.Snac;
/*     */ import ru.caffeineim.protocols.icq.exceptions.ConvertStringException;
/*     */ import ru.caffeineim.protocols.icq.setting.enumerations.XStatusModeEnum;
/*     */ import ru.caffeineim.protocols.icq.tool.StringTools;
/*     */ 
/*     */ public class SendXStatus extends Flap
/*     */ {
/*     */   public Snac snac;
/*  33 */   private static final byte[] CAPABILITY = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
/*     */ 
/*  38 */   private static final byte[] CAPABILITY2 = { 26, 0, 0, 0, 1, 0, 1, 0, 0, 79, 0, 59, 96, -77, -17, -40 };
/*     */ 
/*  43 */   private static final byte[] CAPABILITY3 = { 42, 108, 69, -92, -32, -100, 90, 94, 103, -24, 101, 8, 0, 42, 0, 0 };
/*     */ 
/*  49 */   private static final byte[] UNKNOWN = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
/*     */ 
/*     */   public SendXStatus(int Time, int msgID, String userId, String myId, int senderTcpVersion, XStatusModeEnum xstatus, String msg, String extmsg)
/*     */     throws ConvertStringException
/*     */   {
/*  55 */     super(2);
/*  56 */     this.snac = new Snac(4, 11, 0, 0, 0);
/*     */ 
/*  59 */     this.snac.addRawDataToSnac(new RawData(Time, 4));
/*     */ 
/*  62 */     this.snac.addRawDataToSnac(new RawData(msgID, 4));
/*     */ 
/*  65 */     this.snac.addRawDataToSnac(new RawData(2, 2));
/*     */ 
/*  68 */     this.snac.addRawDataToSnac(new RawData(userId.length(), 1));
/*  69 */     this.snac.addRawDataToSnac(new RawData(userId));
/*     */ 
/*  72 */     this.snac.addRawDataToSnac(new RawData(3, 2));
/*     */ 
/*  75 */     this.snac.addRawDataToSnac(new RawData(6912, 2));
/*     */ 
/*  78 */     this.snac.addRawDataToSnac(new RawData(senderTcpVersion, 2));
/*     */ 
/*  81 */     this.snac.addRawDataToSnac(new RawData(0, 2));
/*     */ 
/*  84 */     this.snac.addRawDataToSnac(new RawData(CAPABILITY));
/*     */ 
/*  87 */     this.snac.addRawDataToSnac(new RawData(1, 1));
/*     */ 
/*  90 */     this.snac.addRawDataToSnac(new RawData(0, 4));
/*     */ 
/*  93 */     this.snac.addRawDataToSnac(new RawData(114, 1));
/*     */ 
/*  96 */     this.snac.addRawDataToSnac(new RawData(6414, 2));
/*     */ 
/* 100 */     this.snac.addRawDataToSnac(new RawData(114, 2));
/*     */ 
/* 103 */     this.snac.addRawDataToSnac(new RawData(6400, 2));
/*     */ 
/* 106 */     this.snac.addRawDataToSnac(new RawData(0, 4));
/* 107 */     this.snac.addRawDataToSnac(new RawData(0, 4));
/* 108 */     this.snac.addRawDataToSnac(new RawData(0, 2));
/* 109 */     this.snac.addRawDataToSnac(new RawData(0, 1));
/*     */ 
/* 112 */     this.snac.addRawDataToSnac(new RawData(CAPABILITY2));
/* 113 */     this.snac.addRawDataToSnac(new RawData(CAPABILITY3));
/*     */ 
/* 116 */     this.snac.addRawDataToSnac(new RawData(0, 1));
/*     */ 
/* 119 */     this.snac.addRawDataToSnac(new RawData("Script Plug-in: Remote Notification Arrive"));
/* 120 */     this.snac.addRawDataToSnac(new RawData(0, 1));
/*     */ 
/* 124 */     this.snac.addRawDataToSnac(new RawData(1, 2));
/*     */ 
/* 126 */     this.snac.addRawDataToSnac(new RawData(UNKNOWN));
/*     */ 
/* 128 */     this.snac.addRawDataToSnac(new RawData(-184483840, 4));
/*     */ 
/* 130 */     this.snac.addRawDataToSnac(new RawData(-251592704, 4));
/*     */ 
/* 133 */     this.snac.addRawDataToSnac(new RawData("<NR><RES>&lt;ret event='OnRemoteNotification'&gt;&lt;srv&gt;&lt;id&gt;cAwaySrv&lt;/id&gt;&lt;val srv_id='cAwaySrv'&gt;&lt;Root&gt;&lt;CASXtraSetAwayMessage&gt;&lt;/CASXtraSetAwayMessage&gt;&lt;uin&gt;" + myId + "&lt;/uin&gt;&lt;index&gt;" + xstatus.getXStatus() + "&lt;/index&gt;&lt;title&gt;"));
/*     */ 
/* 135 */     this.snac.addRawDataToSnac(new RawData(StringTools.stringToByteArray(msg)));
/* 136 */     this.snac.addRawDataToSnac(new RawData("&lt;/title&gt;&lt;desc&gt;"));
/*     */ 
/* 138 */     this.snac.addRawDataToSnac(new RawData(StringTools.stringToByteArray(extmsg)));
/* 139 */     this.snac.addRawDataToSnac(new RawData("&lt;/desc&gt;&lt;/Root&gt;\r\n"));
/* 140 */     this.snac.addRawDataToSnac(new RawData("&lt;/val&gt;&lt;/srv&gt;&lt;srv&gt;&lt;id&gt;cRandomizerSrv&lt;/id&gt;&lt;val srv_id='cRandomizerSrv'&gt;undefined&lt;/val&gt;&lt;/srv&gt;&lt;/ret&gt;</RES></NR>\r\n"));
/*     */ 
/* 142 */     addSnac(this.snac);
/*     */   }
/*     */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.packet.sent.icbm.SendXStatus
 * JD-Core Version:    0.6.0
 */