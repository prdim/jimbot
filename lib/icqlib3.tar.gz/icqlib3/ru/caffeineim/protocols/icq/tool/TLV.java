/*    */ package ru.caffeineim.protocols.icq.tool;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ public class TLV
/*    */ {
/*    */   private short type;
/*    */   private ArrayList<Byte> data;
/*    */ 
/*    */   public TLV(short type, ArrayList<Byte> data)
/*    */   {
/* 18 */     this.type = type;
/* 19 */     this.data = data;
/*    */   }
/*    */ 
/*    */   public void setData(ArrayList<Byte> newData) {
/* 23 */     this.data = newData;
/*    */   }
/*    */ 
/*    */   public short getTLVSize() {
/* 27 */     return (short)(this.data.size() + 4);
/*    */   }
/*    */ 
/*    */   public short getDataSize()
/*    */   {
/* 32 */     return (short)this.data.size();
/*    */   }
/*    */ 
/*    */   public short getType() {
/* 36 */     return this.type;
/*    */   }
/*    */ 
/*    */   public ArrayList<Byte> getData() {
/* 40 */     return this.data;
/*    */   }
/*    */ 
/*    */   public static TLV readTLV(ArrayList<Byte> data)
/*    */   {
/* 46 */     short type = ProtocolUtils.readShort(data);
/* 47 */     short length = ProtocolUtils.readShort(data);
/* 48 */     ArrayList b = ProtocolUtils.readBytes(data, length);
/* 49 */     return new TLV(type, b);
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.tool.TLV
 * JD-Core Version:    0.6.0
 */