/*     */ package ru.caffeineim.protocols.icq.tool;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ public class CharSetUtils
/*     */ {
/*     */   public static ArrayList<Byte> UNICODEtoCP_1251_8(String s)
/*     */   {
/* 202 */     byte[] data = null;
/*     */     try {
/* 204 */       data = s.getBytes("CP1251");
/*     */     } catch (UnsupportedEncodingException e) {
/* 206 */       e.printStackTrace();
/*     */     }
/* 208 */     if (data == null) return null;
/* 209 */     ArrayList b = new ArrayList(data.length);
/* 210 */     for (byte aData : data) {
/* 211 */       b.add(Byte.valueOf(aData));
/*     */     }
/* 213 */     return b;
/*     */   }
/*     */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.tool.CharSetUtils
 * JD-Core Version:    0.6.0
 */