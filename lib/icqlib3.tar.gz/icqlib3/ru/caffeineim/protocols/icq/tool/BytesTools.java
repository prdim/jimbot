/*    */ package ru.caffeineim.protocols.icq.tool;
/*    */ 
/*    */ public class BytesTools
/*    */ {
/*    */   public static boolean byteArrayEquals(byte[] buf1, int off1, byte[] buf2, int off2, int len)
/*    */   {
/* 42 */     if ((off1 + len > buf1.length) || (off2 + len > buf2.length)) {
/* 43 */       return false;
/*    */     }
/*    */ 
/* 47 */     for (int i = 0; i < len; i++) {
/* 48 */       if (buf1[(off1 + i)] != buf2[(off2 + i)]) {
/* 49 */         return false;
/*    */       }
/*    */ 
/*    */     }
/*    */ 
/* 54 */     return true;
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.tool.BytesTools
 * JD-Core Version:    0.6.0
 */