/*     */ package ru.caffeineim.protocols.icq.tool;
/*     */ 
/*     */ public class Dumper
/*     */ {
/*     */   public static String dump(byte[] packet, boolean stringTranslation)
/*     */   {
/*  35 */     return dump(packet, stringTranslation, 4, 8);
/*     */   }
/*     */ 
/*     */   public static String dump(byte[] packet, boolean stringTranslation, int spacer, int breaker)
/*     */   {
/*  50 */     String hexa = "";
/*     */ 
/*  52 */     byte[] hexaChar = new byte[breaker];
/*     */ int i;
/*  55 */     for (i = 1; i < packet.length + 1; i++) {
/*  56 */       hexa = hexa + toUnsignedHex(packet[(i - 1)]) + " ";
/*     */ 
/*  58 */       if (i % spacer == 0) {
/*  59 */         hexa = hexa + " ";
/*  60 */         if (i % breaker == 0) {
/*  61 */           if (stringTranslation) {
/*  62 */             System.arraycopy(packet, i - breaker, hexaChar, 0, breaker);
/*  63 */             hexa = hexa + stringTranslation(hexaChar);
/*     */           }
/*  65 */           hexa = hexa + "\n";
/*     */         }
/*     */       }
/*     */     }
/*  69 */     if (stringTranslation) {
/*  70 */       i--;
/*  71 */       byte[] lastLine = new byte[i % breaker];
/*  72 */       System.arraycopy(packet, i - i % breaker, lastLine, 0, i % breaker);
/*  73 */       hexa = hexa + align(i % breaker, breaker);
/*  74 */       hexa = hexa + stringTranslation(lastLine);
/*     */     }
/*     */ 
/*  77 */     return hexa;
/*     */   }
/*     */ 
/*     */   private static String toUnsignedHex(byte b)
/*     */   {
/*  88 */     String hex = Integer.toHexString(b & 0xFF);
/*     */ 
/*  91 */     if (hex.length() == 1) {
/*  92 */       hex = "0" + hex;
/*     */     }
/*  94 */     return hex.toUpperCase();
/*     */   }
/*     */ 
/*     */   private static String stringTranslation(byte[] array)
/*     */   {
/* 105 */     String ent = new String(array);
/* 106 */     String res = new String();
/*     */ 
/* 108 */     for (int i = 0; i < ent.length(); i++) {
/* 109 */       if (Character.getType(ent.charAt(i)) == 15)
/* 110 */         res = res + ".";
/*     */       else {
/* 112 */         res = res + ent.charAt(i);
/*     */       }
/*     */     }
/* 115 */     return res;
/*     */   }
/*     */ 
/*     */   private static String align(int wrote, int expected)
/*     */   {
/* 128 */     String result = "";
/* 129 */     for (int i = 0; i < expected - wrote; i++) {
/* 130 */       result = result + "   ";
/*     */     }
/* 132 */     result = result + "  ";
/*     */ 
/* 134 */     return result;
/*     */   }
/*     */ 
/*     */   public static void log(byte[] packet, boolean stringTranslation, int spacer, int breaker)
/*     */   {
/*     */   }
/*     */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.tool.Dumper
 * JD-Core Version:    0.6.0
 */