/*     */ package ru.caffeineim.protocols.icq.tool;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import ru.caffeineim.protocols.icq.exceptions.ConvertStringException;
/*     */ 
/*     */ public class StringTools
/*     */ {
/*     */   public static final String UTF8_ENCODING = "UTF-8";
/*     */ 
/*     */   public static byte[] stringToByteArray(String s)
/*     */     throws ConvertStringException
/*     */   {
/*     */     try
/*     */     {
/*  45 */       return s.getBytes("UTF-8");
/*     */     } catch (UnsupportedEncodingException e) {
/*     */     }
/*  48 */     throw new ConvertStringException("UTF-8 not supported in your system");
/*     */   }
/*     */ 
/*     */   public static String utf8ByteArrayToString(byte[] arr, int off, int len)
/*     */     throws ConvertStringException
/*     */   {
/*  64 */     if (off + len > arr.length) {
/*  65 */       return "";
/*     */     }
/*     */ 
/*  69 */     while ((len > 0) && (arr[(off + len - 1)] == 0))
/*     */     {
/*  71 */       len--;
/*     */     }
/*     */     try
/*     */     {
/*  75 */       return new String(arr, off, len, "UTF-8");
/*     */     } catch (UnsupportedEncodingException e) {
/*     */     }
/*  78 */     throw new ConvertStringException("UTF-8 not supported in your system");
/*     */   }
/*     */ 
/*     */   public static byte[] stringToUcs2beByteArray(String s)
/*     */   {
/*  89 */     String str = restoreCrLf(s);
/*  90 */     byte[] ucs2be = new byte[str.length() * 2];
/*  91 */     for (int i = 0; i < str.length(); i++) {
/*  92 */       ucs2be[(i * 2)] = (byte)(str.charAt(i) >> '\b' & 0xFF);
/*  93 */       ucs2be[(i * 2 + 1)] = (byte)(str.charAt(i) & 0xFF);
/*     */     }
/*     */ 
/*  96 */     return ucs2be;
/*     */   }
/*     */ 
/*     */   public static String ucs2beByteArrayToString(byte[] arr, int off, int len)
/*     */   {
/* 109 */     if ((off + len > arr.length) || (len % 2 != 0)) {
/* 110 */       return "";
/*     */     }
/*     */ 
/* 114 */     StringBuffer sb = new StringBuffer();
/*     */ 
/* 116 */     for (int i = off; i < off + len; i += 2)
/*     */     {
/* 118 */       char ch = (char)(arr[i] << 8 & 0xFF00 | arr[(i + 1)] & 0xFF);
/* 119 */       sb.append(ch);
/*     */     }
/*     */ 
/* 122 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public static String byteArrayToString(byte[] arr, int off, int len)
/*     */     throws ConvertStringException
/*     */   {
/* 136 */     if (off + len > arr.length) {
/* 137 */       return "";
/*     */     }
/*     */ 
/* 141 */     return byteArray1251ToString(arr, off, len);
/*     */   }
/*     */ 
/*     */   public static String byteArray1251ToString(byte[] data, int off, int len)
/*     */   {
/* 152 */     String s = new String(data, off, len);
/*     */ 
/* 154 */     StringBuffer stringbuffer = new StringBuffer(len);
/* 155 */     for (int k = 0; k < len; k++) {
/* 156 */       int l = data[(k + off)] & 0xFF;
/*     */ 
/* 158 */       switch (l) {
/*     */       case 168:
/* 160 */         stringbuffer.append('Ё');
/* 161 */         break;
/*     */       case 184:
/* 163 */         stringbuffer.append('ё');
/* 164 */         break;
/*     */       case 165:
/* 168 */         stringbuffer.append('Ґ');
/* 169 */         break;
/*     */       case 170:
/* 171 */         stringbuffer.append('Є');
/* 172 */         break;
/*     */       case 175:
/* 174 */         stringbuffer.append('Ї');
/* 175 */         break;
/*     */       case 178:
/* 177 */         stringbuffer.append('І');
/* 178 */         break;
/*     */       case 179:
/* 180 */         stringbuffer.append('і');
/* 181 */         break;
/*     */       case 180:
/* 183 */         stringbuffer.append('ґ');
/* 184 */         break;
/*     */       case 186:
/* 186 */         stringbuffer.append('є');
/* 187 */         break;
/*     */       case 191:
/* 189 */         stringbuffer.append('ї');
/* 190 */         break;
/*     */       case 166:
/*     */       case 167:
/*     */       case 169:
/*     */       case 171:
/*     */       case 172:
/*     */       case 173:
/*     */       case 174:
/*     */       case 176:
/*     */       case 177:
/*     */       case 181:
/*     */       case 182:
/*     */       case 183:
/*     */       case 185:
/*     */       case 187:
/*     */       case 188:
/*     */       case 189:
/*     */       case 190:
/*     */       default:
/* 194 */         if ((l >= 192) && (l <= 255)) {
/* 195 */           stringbuffer.append((char)(1040 + l - 192));
/*     */         }
/*     */         else {
/* 198 */           stringbuffer.append(s.charAt(k));
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 204 */     return stringbuffer.toString();
/*     */   }
/*     */ 
/*     */   public static String restoreCrLf(String s)
/*     */   {
/* 214 */     StringBuffer result = new StringBuffer();
/*     */ 
/* 216 */     int size = s.length();
/* 217 */     for (int i = 0; i < size; i++) {
/* 218 */       char chr = s.charAt(i);
/* 219 */       if (chr != '\r')
/* 220 */         if (chr == '\n') result.append("\r\n"); else
/* 221 */           result.append(chr);
/*     */     }
/* 223 */     return result.toString();
/*     */   }
/*     */ 
/*     */   public static String removeCr(String s)
/*     */   {
/* 233 */     StringBuffer result = new StringBuffer();
/*     */ 
/* 235 */     for (int i = 0; i < s.length(); i++) {
/* 236 */       char chr = s.charAt(i);
/* 237 */       if ((chr != 0) && (chr != '\r'))
/* 238 */         result.append(chr);
/*     */     }
/* 240 */     return result.toString();
/*     */   }
/*     */ 
/*     */   public static String stringCP1251ToUTF8(String s)
/*     */     throws ConvertStringException
/*     */   {
/* 251 */     String res = "";
/*     */     try
/*     */     {
/* 254 */       ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 255 */       DataOutputStream dos = new DataOutputStream(baos);
/* 256 */       dos.writeUTF(s);
/* 257 */       byte[] raw = baos.toByteArray();
/* 258 */       byte[] result = new byte[raw.length - 2];
/* 259 */       System.arraycopy(raw, 2, result, 0, raw.length - 2);
/*     */ 
/* 261 */       String ent = new String(result);
/* 262 */       for (int i = 0; i < ent.length(); i++)
/* 263 */         if (Character.getType(ent.charAt(i)) == 15)
/* 264 */           res = res + ".";
/*     */         else
/* 266 */           res = res + ent.charAt(i);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 270 */       e.printStackTrace();
/*     */     }
/*     */     try
/*     */     {
/* 274 */       return new String(res.getBytes(), "UTF-8");
/*     */     } catch (UnsupportedEncodingException e) {
/*     */     }
/* 277 */     throw new ConvertStringException("UTF-8 not supported in your system");
/*     */   }
/*     */ 
/*     */   public static String UTF8ToStringCP1251(String s)
/*     */   {
/* 288 */     byte[] buf = s.getBytes();
/* 289 */     String res = "";
/*     */     try {
/* 291 */       byte[] buf2 = new byte[buf.length + 2];
/*     */ 
/* 293 */       buf2[0] = (byte)(buf.length >> 8 & 0xFF);
/* 294 */       buf2[1] = (byte)(buf.length & 0xFF);
/* 295 */       System.arraycopy(buf, 0, buf2, 2, buf.length);
/*     */ 
/* 298 */       ByteArrayInputStream bais = new ByteArrayInputStream(buf2);
/* 299 */       DataInputStream dis = new DataInputStream(bais);
/*     */ 
/* 301 */       res = dis.readUTF();
/*     */     }
/*     */     catch (Exception e) {
/* 304 */       e.printStackTrace();
/*     */     }
/*     */ 
/* 307 */     return res;
/*     */   }
/*     */ 
/*     */   public static boolean isEmpty(String string)
/*     */   {
/* 316 */     return (string == null) || (string.length() < 1);
/*     */   }
/*     */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.tool.StringTools
 * JD-Core Version:    0.6.0
 */