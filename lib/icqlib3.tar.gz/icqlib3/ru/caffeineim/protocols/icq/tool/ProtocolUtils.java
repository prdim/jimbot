/*     */ package ru.caffeineim.protocols.icq.tool;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ public class ProtocolUtils
/*     */ {
/*     */   public static void appendByte(ArrayList<Byte> data, byte b)
/*     */   {
/* 390 */     data.add(Byte.valueOf(b));
/*     */   }
/*     */ 
/*     */   public static void appendBytes(ArrayList<Byte> data, ArrayList<Byte> b)
/*     */   {
/* 407 */     for (Byte v : b)
/* 408 */       data.add(v);
/*     */   }
/*     */ 
/*     */   public static void appendShort(ArrayList<Byte> data, short v)
/*     */   {
/* 432 */     data.add(Byte.valueOf((byte)(v >>> 8)));
/* 433 */     data.add(Byte.valueOf((byte)(v >>> 0)));
/*     */   }
/*     */ 
/*     */   public static void appendLeftShort(ArrayList<Byte> data, short v)
/*     */   {
/* 438 */     data.add(Byte.valueOf((byte)(v >>> 0)));
/* 439 */     data.add(Byte.valueOf((byte)(v >>> 8)));
/*     */   }
/*     */ 
/*     */   public static ArrayList<Byte> readBytes(ArrayList<Byte> data, short length)
/*     */   {
/* 472 */     ArrayList b = new ArrayList(length);
/* 473 */     for (short i = 0; i < length; i = (short)(i + 1)) {
/* 474 */       b.add(data.get(0));
/* 475 */       data.remove(0);
/*     */     }
/* 477 */     return b;
/*     */   }
/*     */ 
/*     */   public static short readShort(ArrayList<Byte> data)
/*     */   {
/* 493 */     int ch1 = ((Byte)data.get(0)).byteValue() & 0xFF;
/* 494 */     int ch2 = ((Byte)data.get(1)).byteValue() & 0xFF;
/* 495 */     data.remove(0);
/* 496 */     data.remove(0);
/* 497 */     return (short)((ch1 << 8) + (ch2 << 0));
/*     */   }
/*     */ 
/*     */   public static byte[] getUIN(String UIN)
/*     */   {
/* 556 */     byte[] uin = new byte[4];
/* 557 */     int v = Integer.parseInt(UIN);
/* 558 */     uin[3] = (byte)(v >>> 24);
/* 559 */     uin[2] = (byte)(v >>> 16);
/* 560 */     uin[1] = (byte)(v >>> 8);
/* 561 */     uin[0] = (byte)(v >>> 0);
/* 562 */     return uin;
/*     */   }
/*     */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.tool.ProtocolUtils
 * JD-Core Version:    0.6.0
 */