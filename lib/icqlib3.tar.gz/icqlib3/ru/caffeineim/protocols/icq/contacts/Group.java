/*    */ package ru.caffeineim.protocols.icq.contacts;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import ru.caffeineim.protocols.icq.Item;
/*    */ 
/*    */ public class Group extends ContactListItem
/*    */ {
/* 29 */   private List contacts = new ArrayList(2);
/*    */ 
/*    */   public Group(Item item)
/*    */   {
/* 35 */     super(item);
/*    */   }
/*    */ 
/*    */   public Group(short groupId, String name)
/*    */   {
/* 42 */     super(new Item((short)0, groupId, name));
/*    */   }
/*    */ 
/*    */   public void addItem(ContactListItem item) {
/* 46 */     if (item == null)
/* 47 */       throw new NullPointerException();
/* 48 */     this.contacts.add(item);
/*    */   }
/*    */ 
/*    */   public void removeItem(ContactListItem item) {
/* 52 */     if (item == null)
/* 53 */       throw new NullPointerException();
/* 54 */     this.contacts.remove(item);
/*    */   }
/*    */ 
/*    */   public List getContainedItems() {
/* 58 */     return this.contacts;
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.contacts.Group
 * JD-Core Version:    0.6.0
 */