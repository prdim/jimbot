/*     */ package ru.caffeineim.protocols.icq.contacts;
/*     */ 
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Iterator;
/*     */ import ru.caffeineim.protocols.icq.core.OscarConnection;
/*     */ import ru.caffeineim.protocols.icq.exceptions.ContactListOperationException;
/*     */ import ru.caffeineim.protocols.icq.exceptions.ConvertStringException;
/*     */ import ru.caffeineim.protocols.icq.packet.sent.buddylist.AddToContactList;
/*     */ import ru.caffeineim.protocols.icq.packet.sent.buddylist.RemoveFromContactList;
/*     */ import ru.caffeineim.protocols.icq.packet.sent.meta.RequestShortUserInfo;
/*     */ import ru.caffeineim.protocols.icq.packet.sent.ssi.SsiAddItem;
/*     */ import ru.caffeineim.protocols.icq.packet.sent.ssi.SsiBeginEdit;
/*     */ import ru.caffeineim.protocols.icq.packet.sent.ssi.SsiEndEdit;
/*     */ import ru.caffeineim.protocols.icq.packet.sent.ssi.SsiRemoveItem;
/*     */ import ru.caffeineim.protocols.icq.packet.sent.ssi.SsiRemoveYourself;
/*     */ import ru.caffeineim.protocols.icq.packet.sent.ssi.SsiSendAuthReplyMessage;
/*     */ import ru.caffeineim.protocols.icq.packet.sent.ssi.SsiSendAuthRequestMessage;
/*     */ import ru.caffeineim.protocols.icq.packet.sent.ssi.SsiSendYouWereAdded;
/*     */ import ru.caffeineim.protocols.icq.packet.sent.ssi.SsiUpdateGroupHeader;
/*     */ import ru.caffeineim.protocols.icq.tool.StringTools;
/*     */ 
/*     */ public class ContactList
/*     */   implements IContactList
/*     */ {
/*     */   private static final String GROUP_TITLE_FMT = "{0}:\n";
/*     */   private static final String CONTACT_TITLE_FMT = "   {0} ({1})\n";
/*  48 */   private short maxGroupId = 0;
/*     */ 
/*  50 */   private short maxContactId = 0;
/*     */   private OscarConnection connection;
/*     */   private Group rootGroup;
/*     */   private int count;
/*     */ 
/*     */   public ContactList(OscarConnection connection, Group rootGroup, int count)
/*     */   {
/*  59 */     this.connection = connection;
/*  60 */     this.rootGroup = rootGroup;
/*  61 */     this.count = count;
/*     */ 
/*  63 */     for (Iterator iter = rootGroup.getContainedItems().iterator(); iter.hasNext(); ) {
/*  64 */       ContactListItem item = (ContactListItem)iter.next();
/*  65 */       if ((item instanceof Group)) {
/*  66 */         Group grp = (Group)item;
/*     */ 
/*  68 */         if (grp.getGroupId() > this.maxGroupId) {
/*  69 */           this.maxGroupId = grp.getGroupId();
/*     */         }
/*  71 */         for (Iterator grpiter = rootGroup.getContainedItems().iterator(); grpiter.hasNext(); ) {
/*  72 */           ContactListItem cntct = (ContactListItem)grpiter.next();
/*  73 */           if ((cntct instanceof Contact)) {
/*  74 */             Contact cnt = (Contact)cntct;
/*  75 */             if (cnt.getItemId() > this.maxContactId)
/*  76 */               this.maxContactId = cnt.getItemId();
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addContact(String userId, String groupName) throws ContactListOperationException
/*     */   {
/*  87 */     addContact(userId, getGroupByName(groupName));
/*     */   }
/*     */ 
/*     */   public void addContact(String userId, Group group)
/*     */     throws ContactListOperationException
/*     */   {
/*  94 */     Contact contact = new Contact(this.maxContactId = (short)(this.maxContactId + 1), group.getGroupId(), userId);
/*  95 */     addContact(contact, group);
/*     */   }
/*     */ 
/*     */   public void addContact(Contact contact, Group group)
/*     */     throws ContactListOperationException
/*     */   {
/* 102 */     if (group == null) {
/* 103 */       throw new ContactListOperationException("Group could not be null");
/*     */     }
/* 105 */     group.addItem(contact);
/* 106 */     this.count += 1;
/*     */     try
/*     */     {
/* 109 */       this.connection.sendFlap(new SsiBeginEdit());
/* 110 */       this.connection.sendFlap(new SsiAddItem(contact));
/* 111 */       this.connection.sendFlap(new SsiUpdateGroupHeader(group));
/* 112 */       this.connection.sendFlap(new SsiEndEdit());
/*     */ 
/* 114 */       this.connection.sendFlap(new AddToContactList(contact.getId()));
/*     */ 
/* 116 */       if (StringTools.isEmpty(contact.getNickName()))
/* 117 */         this.connection.sendFlap(new RequestShortUserInfo(contact.getId(), this.connection.getUserId()));
/*     */     }
/*     */     catch (ConvertStringException e)
/*     */     {
/* 121 */       throw new ContactListOperationException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void removeContact(String userId)
/*     */     throws ContactListOperationException
/*     */   {
/* 129 */     Contact contact = getContactById(userId);
/* 130 */     if (contact != null)
/* 131 */       removeContact(contact);
/*     */   }
/*     */ 
/*     */   public void removeContact(Contact contact)
/*     */     throws ContactListOperationException
/*     */   {
/* 139 */     Group group = getGroupById(contact.getGroupId());
/* 140 */     if (group == null) {
/* 141 */       throw new ContactListOperationException("Group could not be null");
/*     */     }
/* 143 */     group.removeItem(contact);
/*     */     try
/*     */     {
/* 146 */       this.connection.sendFlap(new SsiBeginEdit());
/* 147 */       this.connection.sendFlap(new SsiRemoveItem(contact));
/* 148 */       this.connection.sendFlap(new SsiUpdateGroupHeader(group));
/* 149 */       this.connection.sendFlap(new SsiEndEdit());
/*     */ 
/* 151 */       this.connection.sendFlap(new RemoveFromContactList(contact.getId()));
/*     */     }
/*     */     catch (ConvertStringException e) {
/* 154 */       throw new ContactListOperationException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addGroup(String group)
/*     */     throws ContactListOperationException
/*     */   {
/* 162 */     addGroup(new Group(this.maxGroupId = (short)(this.maxGroupId + 1), group));
/*     */   }
/*     */ 
/*     */   public void addGroup(Group group)
/*     */     throws ContactListOperationException
/*     */   {
/* 169 */     if (group == null) {
/* 170 */       throw new ContactListOperationException("Group could not be null");
/*     */     }
/* 172 */     this.rootGroup.addItem(group);
/*     */     try
/*     */     {
/* 175 */       this.connection.sendFlap(new SsiBeginEdit());
/* 176 */       this.connection.sendFlap(new SsiAddItem(group));
/* 177 */       this.connection.sendFlap(new SsiEndEdit());
/*     */     }
/*     */     catch (ConvertStringException e) {
/* 180 */       throw new ContactListOperationException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void removeGroup(Group group)
/*     */     throws ContactListOperationException
/*     */   {
/* 188 */     if (group == null) {
/* 189 */       throw new ContactListOperationException("Group could not be null");
/*     */     }
/* 191 */     this.rootGroup.removeItem(group);
/*     */     try
/*     */     {
/* 194 */       this.connection.sendFlap(new SsiBeginEdit());
/* 195 */       this.connection.sendFlap(new SsiRemoveItem(group));
/* 196 */       this.connection.sendFlap(new SsiEndEdit());
/*     */     }
/*     */     catch (ConvertStringException e) {
/* 199 */       throw new ContactListOperationException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void removeYourself(String userId)
/*     */   {
/* 207 */     this.connection.sendFlap(new SsiRemoveYourself(userId));
/*     */   }
/*     */ 
/*     */   public void sendAuthRequestMessage(String userId, String request)
/*     */     throws ContactListOperationException
/*     */   {
/*     */     try
/*     */     {
/* 215 */       this.connection.sendFlap(new SsiSendAuthRequestMessage(userId, request));
/*     */     }
/*     */     catch (ConvertStringException e) {
/* 218 */       throw new ContactListOperationException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void sendAuthReplyMessage(String userId, String reply, boolean auth)
/*     */     throws ContactListOperationException
/*     */   {
/*     */     try
/*     */     {
/* 227 */       this.connection.sendFlap(new SsiSendAuthReplyMessage(userId, reply, auth));
/*     */     }
/*     */     catch (ConvertStringException e) {
/* 230 */       throw new ContactListOperationException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void sendYouWereAdded(String userId)
/*     */   {
/* 238 */     this.connection.sendFlap(new SsiSendYouWereAdded(userId));
/*     */   }
/*     */ 
/*     */   public Group getRootGroup()
/*     */   {
/* 245 */     return this.rootGroup;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 249 */     StringBuilder sb = new StringBuilder(1500);
/* 250 */     for (Iterator iter = this.rootGroup.getContainedItems().iterator(); iter.hasNext(); ) {
/* 251 */       ContactListItem item = (ContactListItem)iter.next();
/* 252 */       sb.append(MessageFormat.format("{0}:\n", new Object[] { item.getId() }));
/* 253 */       if ((item instanceof Group)) {
/* 254 */         Group grp = (Group)item;
/* 255 */         for (Iterator grpiter = grp.getContainedItems().iterator(); grpiter.hasNext(); ) {
/* 256 */           ContactListItem grpitem = (ContactListItem)grpiter.next();
/* 257 */           if ((grpitem instanceof Contact)) {
/* 258 */             Contact cnt = (Contact)grpitem;
/* 259 */             sb.append(MessageFormat.format("   {0} ({1})\n", new Object[] { cnt.getNickName(), cnt.getId() }));
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 265 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   private Group getGroupById(short id)
/*     */   {
/* 273 */     for (Iterator iter = this.rootGroup.getContainedItems().iterator(); iter.hasNext(); ) {
/* 274 */       ContactListItem item = (ContactListItem)iter.next();
/* 275 */       if (item.getGroupId() == id) {
/* 276 */         return (Group)item;
/*     */       }
/*     */     }
/*     */ 
/* 280 */     return null;
/*     */   }
/*     */ 
/*     */   private Group getGroupByName(String name)
/*     */   {
/* 288 */     if (name == null) {
/* 289 */       return null;
/*     */     }
/* 291 */     for (Iterator iter = this.rootGroup.getContainedItems().iterator(); iter.hasNext(); ) {
/* 292 */       ContactListItem item = (ContactListItem)iter.next();
/* 293 */       if (name.equals(item.getId())) {
/* 294 */         return (Group)item;
/*     */       }
/*     */     }
/*     */ 
/* 298 */     return null;
/*     */   }
/*     */ 
/*     */   private Contact getContactById(String userId)
/*     */   {
/* 306 */     for (Iterator iter = this.rootGroup.getContainedItems().iterator(); iter.hasNext(); ) {
/* 307 */       ContactListItem item = (ContactListItem)iter.next();
/* 308 */       if ((item instanceof Group)) {
/* 309 */         Group grp = (Group)item;
/* 310 */         for (Iterator grpiter = grp.getContainedItems().iterator(); grpiter.hasNext(); ) {
/* 311 */           ContactListItem cntct = (ContactListItem)grpiter.next();
/* 312 */           if (cntct.getId().equals(userId))
/* 313 */             return (Contact)cntct;
/*     */         }
/*     */       }
/*     */     }
/* 318 */     return null;
/*     */   }
/*     */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.contacts.ContactList
 * JD-Core Version:    0.6.0
 */