package ru.caffeineim.protocols.icq.contacts;

import ru.caffeineim.protocols.icq.exceptions.ContactListOperationException;

public abstract interface IContactList
{
  public abstract void addContact(String paramString1, String paramString2)
    throws ContactListOperationException;

  public abstract void addContact(String paramString, Group paramGroup)
    throws ContactListOperationException;

  public abstract void addContact(Contact paramContact, Group paramGroup)
    throws ContactListOperationException;

  public abstract void removeContact(String paramString)
    throws ContactListOperationException;

  public abstract void removeContact(Contact paramContact)
    throws ContactListOperationException;

  public abstract void addGroup(String paramString)
    throws ContactListOperationException;

  public abstract void addGroup(Group paramGroup)
    throws ContactListOperationException;

  public abstract void removeGroup(Group paramGroup)
    throws ContactListOperationException;

  public abstract void removeYourself(String paramString);

  public abstract void sendAuthRequestMessage(String paramString1, String paramString2)
    throws ContactListOperationException;

  public abstract void sendAuthReplyMessage(String paramString1, String paramString2, boolean paramBoolean)
    throws ContactListOperationException;

  public abstract void sendYouWereAdded(String paramString);

  public abstract Group getRootGroup();
}

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.contacts.IContactList
 * JD-Core Version:    0.6.0
 */