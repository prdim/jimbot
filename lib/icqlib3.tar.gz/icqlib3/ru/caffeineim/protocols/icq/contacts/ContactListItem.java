/*    */ package ru.caffeineim.protocols.icq.contacts;
/*    */ 
/*    */ import ru.caffeineim.protocols.icq.Item;
/*    */ 
/*    */ public class ContactListItem
/*    */ {
/*    */   private String id;
/*    */   private short itemid;
/*    */   private short groupid;
/*    */ 
/*    */   public ContactListItem(Item item)
/*    */   {
/* 36 */     this.id = item.getName();
/* 37 */     this.itemid = item.getId();
/* 38 */     this.groupid = item.getGroup();
/*    */   }
/*    */ 
/*    */   public String getId() {
/* 42 */     return this.id;
/*    */   }
/*    */ 
/*    */   public short getItemId() {
/* 46 */     return this.itemid;
/*    */   }
/*    */ 
/*    */   public short getGroupId() {
/* 50 */     return this.groupid;
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.contacts.ContactListItem
 * JD-Core Version:    0.6.0
 */