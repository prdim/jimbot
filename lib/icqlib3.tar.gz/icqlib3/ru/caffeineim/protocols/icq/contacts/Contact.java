/*     */ package ru.caffeineim.protocols.icq.contacts;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Iterator;
/*     */ import ru.caffeineim.protocols.icq.Item;
/*     */ import ru.caffeineim.protocols.icq.Tlv;
/*     */ import ru.caffeineim.protocols.icq.setting.enumerations.StatusModeEnum;
/*     */ 
/*     */ public class Contact extends ContactListItem
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -4126754352326743822L;
/*     */   private boolean isInVisibleList;
/*     */   private boolean isInInvisibleList;
/*  38 */   private String firstName = "";
/*     */ 
/*  40 */   private String lastName = "";
/*     */ 
/*  42 */   private String nickName = "";
/*     */ 
/*  44 */   private String email = "";
/*     */ 
/*  46 */   private String SMSNumber = "";
/*     */ 
/*  48 */   private String comment = "";
/*     */   private transient StatusModeEnum currentStatus;
/*     */ 
/*     */   public Contact(Item item)
/*     */   {
/*  58 */     super(item);
/*  59 */     this.isInVisibleList = false;
/*  60 */     this.isInInvisibleList = (item.getType() == 14);
/*  61 */     this.currentStatus = new StatusModeEnum(255);
/*     */ 
/*  63 */     Iterator tlvIter = item.getTlvsIterator();
/*  64 */     while (tlvIter.hasNext()) {
/*  65 */       Tlv tlv = (Tlv)tlvIter.next();
/*  66 */       switch (tlv.getType()) {
/*     */       case 109:
/*  68 */         break;
/*     */       case 305:
/*  70 */         setNickName(tlv.getStringValue());
/*  71 */         break;
/*     */       case 311:
/*  73 */         setEmail(tlv.getStringValue());
/*  74 */         break;
/*     */       case 314:
/*  76 */         setSMS(tlv.getStringValue());
/*  77 */         break;
/*     */       case 316:
/*  79 */         setComment(tlv.getStringValue());
/*     */       case 317:
/*     */       case 318:
/*     */       case 325:
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public Contact(short itemid, short groupid, String uin)
/*     */   {
/*  90 */     super(new Item(itemid, groupid, uin));
/*  91 */     setNickName(uin);
/*     */   }
/*     */ 
/*     */   public boolean getIsInVisibleList() {
/*  95 */     return this.isInVisibleList;
/*     */   }
/*     */ 
/*     */   public void setIsInVisibleList(boolean isIn) {
/*  99 */     this.isInVisibleList = isIn;
/*     */   }
/*     */ 
/*     */   public boolean getIsInInvisibleList() {
/* 103 */     return this.isInInvisibleList;
/*     */   }
/*     */ 
/*     */   public void setIsInInvisibleList(boolean isIn) {
/* 107 */     this.isInInvisibleList = isIn;
/*     */   }
/*     */ 
/*     */   public String getFirstName() {
/* 111 */     return this.firstName;
/*     */   }
/*     */ 
/*     */   public void setFirstName(String firstName) {
/* 115 */     this.firstName = firstName;
/*     */   }
/*     */ 
/*     */   public String getLastName() {
/* 119 */     return this.lastName;
/*     */   }
/*     */ 
/*     */   public void setLastName(String lastName) {
/* 123 */     this.lastName = lastName;
/*     */   }
/*     */ 
/*     */   public String getEmail()
/*     */   {
/* 129 */     return this.email;
/*     */   }
/*     */ 
/*     */   public void setEmail(String email) {
/* 133 */     this.email = email;
/*     */   }
/*     */ 
/*     */   public String getNickName() {
/* 137 */     return this.nickName;
/*     */   }
/*     */ 
/*     */   public void setNickName(String nickName) {
/* 141 */     this.nickName = nickName;
/*     */   }
/*     */ 
/*     */   public String getComment() {
/* 145 */     return this.comment;
/*     */   }
/*     */ 
/*     */   public void setComment(String comment) {
/* 149 */     this.comment = comment;
/*     */   }
/*     */ 
/*     */   public String getSMS() {
/* 153 */     return this.SMSNumber;
/*     */   }
/*     */ 
/*     */   public void setSMS(String sms) {
/* 157 */     this.SMSNumber = sms;
/*     */   }
/*     */ 
/*     */   public StatusModeEnum getCurrentStatus() {
/* 161 */     return this.currentStatus;
/*     */   }
/*     */ 
/*     */   public void setCurrentStatus(StatusModeEnum status) {
/* 165 */     this.currentStatus = status;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o) {
/* 169 */     return getId().equals(((Contact)o).getId());
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 173 */     return getNickName() + "(" + getId() + ")";
/*     */   }
/*     */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.contacts.Contact
 * JD-Core Version:    0.6.0
 */