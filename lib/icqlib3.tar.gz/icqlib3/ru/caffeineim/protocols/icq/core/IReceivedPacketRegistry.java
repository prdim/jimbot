package ru.caffeineim.protocols.icq.core;

import java.util.List;

public abstract interface IReceivedPacketRegistry
{
  public abstract List<String> getClassNameList();
}

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.core.IReceivedPacketRegistry
 * JD-Core Version:    0.6.0
 */