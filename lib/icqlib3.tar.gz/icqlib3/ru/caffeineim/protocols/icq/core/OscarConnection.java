/*     */ package ru.caffeineim.protocols.icq.core;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import java.util.ArrayList;
/*     */ import javax.net.SocketFactory;
/*     */ import ru.caffeineim.protocols.icq.Flap;
/*     */ import ru.caffeineim.protocols.icq.Tlv;
/*     */ import ru.caffeineim.protocols.icq.contacts.ContactList;
/*     */ import ru.caffeineim.protocols.icq.contacts.Group;
/*     */ import ru.caffeineim.protocols.icq.contacts.IContactList;
/*     */ import ru.caffeineim.protocols.icq.integration.OscarInterface;
/*     */ import ru.caffeineim.protocols.icq.integration.listeners.ContactListListener;
/*     */ import ru.caffeineim.protocols.icq.integration.listeners.MessagingListener;
/*     */ import ru.caffeineim.protocols.icq.integration.listeners.MetaAckListener;
/*     */ import ru.caffeineim.protocols.icq.integration.listeners.MetaInfoListener;
/*     */ import ru.caffeineim.protocols.icq.integration.listeners.OurStatusListener;
/*     */ import ru.caffeineim.protocols.icq.integration.listeners.UserStatusListener;
/*     */ import ru.caffeineim.protocols.icq.integration.listeners.XStatusListener;
/*     */ import ru.caffeineim.protocols.icq.request.Request;
/*     */ import ru.caffeineim.protocols.icq.request.RequestKeeper;
/*     */ import ru.caffeineim.protocols.icq.request.event.RequestListener;
/*     */ import ru.caffeineim.protocols.icq.setting.Tweaker;
/*     */ 
/*     */ public class OscarConnection
/*     */ {
/*     */   private Tlv cookie;
/*     */   private String userId;
/*     */   private String password;
/*  52 */   private boolean authorized = false;
/*  53 */   private boolean connected = false;
/*     */   private IContactList contactList;
/*     */   private OscarPingHandler pingHandler;
/*     */   private Tweaker tweaker;
/*     */   private OscarClient client;
/*     */   private OscarPacketAnalyser analyser;
/*     */   private RequestKeeper requestKeeper;
/*     */   private List messagingListeners;
/*     */   private List userStatusListeners;
/*     */   private List ourStatusListeners;
/*     */   private List xStatusListeners;
/*     */   private List contactListListeners;
/*     */   private List metaInfoListeners;
/*     */   private List metaAckListeners;
/*     */   private Object contactListLock;
/*     */   private int flapSeqNrs;
/*     */ 
/*     */   public OscarConnection(String host, int port, String userId, String password)
/*     */   {
/*  74 */     this(host, port, userId, password, new Tweaker());
/*     */   }
/*     */ 
/*     */   public OscarConnection(String host, int port, String userId, String password, Tweaker tweaker)
/*     */   {
/*  79 */     this(host, port, userId, password, new Tweaker(), null);
/*     */   }
/*     */ 
/*     */   public OscarConnection(String host, int port, String userId, String password, Tweaker tweaker, SocketFactory factory)
/*     */   {
/*  84 */     this.userId = userId;
/*  85 */     this.password = password;
/*  86 */     this.tweaker = tweaker;
/*  87 */     this.flapSeqNrs = 0;
/*  88 */     this.analyser = new OscarPacketAnalyser(this);
/*  89 */     this.client = new OscarClient(host, port, this.analyser, factory);
/*  90 */     this.requestKeeper = new RequestKeeper();
/*  91 */     this.messagingListeners = new ArrayList(1);
/*  92 */     this.ourStatusListeners = new ArrayList(1);
/*  93 */     this.userStatusListeners = new ArrayList(1);
/*  94 */     this.xStatusListeners = new ArrayList(1);
/*  95 */     this.contactListListeners = new ArrayList(1);
/*  96 */     this.metaInfoListeners = new ArrayList(1);
/*  97 */     this.metaAckListeners = new ArrayList(1);
/*  98 */     this.contactListLock = new Object();
/*     */   }
/*     */ 
/*     */   public void addMetaAckListener(MetaAckListener listener) {
/* 102 */     this.metaAckListeners.add(listener);
/*     */   }
/*     */ 
/*     */   public boolean removeMetaAckListener(MetaAckListener listener) {
/* 106 */     return this.metaAckListeners.remove(listener);
/*     */   }
/*     */ 
/*     */   public void addMetaInfoListener(MetaInfoListener listener) {
/* 110 */     this.metaInfoListeners.add(listener);
/*     */   }
/*     */ 
/*     */   public boolean removeMetaInfoListener(MetaInfoListener listener) {
/* 114 */     return this.metaInfoListeners.remove(listener);
/*     */   }
/*     */ 
/*     */   public void addContactListListener(ContactListListener listener) {
/* 118 */     this.contactListListeners.add(listener);
/*     */   }
/*     */ 
/*     */   public boolean removeContactListListener(ContactListListener listener) {
/* 122 */     return this.contactListListeners.remove(listener);
/*     */   }
/*     */ 
/*     */   public void addMessagingListener(MessagingListener listener) {
/* 126 */     this.messagingListeners.add(listener);
/*     */   }
/*     */ 
/*     */   public boolean removeMessagingListener(MessagingListener listener) {
/* 130 */     return this.messagingListeners.remove(listener);
/*     */   }
/*     */ 
/*     */   public void addUserStatusListener(UserStatusListener listener) {
/* 134 */     this.userStatusListeners.add(listener);
/*     */   }
/*     */ 
/*     */   public boolean removeUserStatusListener(UserStatusListener listener) {
/* 138 */     return this.userStatusListeners.remove(listener);
/*     */   }
/*     */ 
/*     */   public void addXStatusListener(XStatusListener listener) {
/* 142 */     this.xStatusListeners.add(listener);
/*     */   }
/*     */ 
/*     */   public boolean removeXStatusListener(XStatusListener listener) {
/* 146 */     return this.xStatusListeners.remove(listener);
/*     */   }
/*     */ 
/*     */   public void addOurStatusListener(OurStatusListener listener) {
/* 150 */     this.ourStatusListeners.add(listener);
/*     */   }
/*     */ 
/*     */   public boolean removeOurStatusListener(OurStatusListener listener) {
/* 154 */     return this.ourStatusListeners.remove(listener);
/*     */   }
/*     */ 
/*     */   public synchronized void sendFlap(Flap flapPacket)
/*     */   {
/* 162 */     if (flapPacket.getSequenceNumber() == 2147483647) {
/* 163 */       this.flapSeqNrs += 1;
/*     */ 
/* 165 */       if (this.flapSeqNrs > 65535) {
/* 166 */         this.flapSeqNrs = 0;
/*     */       }
/* 168 */       flapPacket.setSequenceNumber(this.flapSeqNrs);
/*     */     }
/*     */     try
/*     */     {
/* 172 */       this.client.sendPacket(flapPacket.getByteArray());
/*     */     }
/*     */     catch (IOException e) {
/* 177 */         notifyOnLogout(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected synchronized void notifyOnLogout(Exception exception)
/*     */   {
/* 183 */     for (int i = 0; i < getOurStatusListeners().size(); i++) {
/* 184 */       OurStatusListener l = (OurStatusListener)getOurStatusListeners().get(i);
/* 185 */       l.onLogout(exception);
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized Request sendMonitoredFlap(Flap flapPacket, RequestListener listener)
/*     */   {
/* 201 */     Request request = null;
/*     */ 
/* 203 */     if (flapPacket.hasSnac()) {
/* 204 */       int requestId = this.requestKeeper.nextAvailableRequestId();
/* 205 */       flapPacket.getSnac().setRequestId(requestId);
/*     */ 
/* 207 */       request = new Request(flapPacket, listener);
/* 208 */       this.requestKeeper.addRequest(request);
/*     */     }
/* 210 */     sendFlap(flapPacket);
/*     */ 
/* 212 */     return request;
/*     */   }
/*     */ 
/*     */   public synchronized void connect()
/*     */   {
/*     */     try
/*     */     {
/* 221 */       this.client.connect();
/* 222 */       this.connected = true;
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 229 */       notifyOnLogout(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized void close()
/*     */   {
/*     */     try
/*     */     {
/* 240 */       if (this.connected)
/* 241 */         this.client.disconnect();
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/*     */     }
/*     */     finally {
/* 247 */       this.connected = false;
/* 248 */       setAuthorized(false);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected synchronized void setAuthorized(boolean status) {
/* 253 */     this.authorized = status;
/* 254 */     if (this.authorized)
/* 255 */       for (int i = 0; i < getOurStatusListeners().size(); i++) {
/* 256 */         OurStatusListener l = (OurStatusListener)getOurStatusListeners().get(i);
/* 257 */         l.onLogin();
/*     */       }
/*     */   }
/*     */ 
/*     */   public boolean isAuthorized()
/*     */   {
/* 263 */     return this.authorized;
/*     */   }
/*     */ 
/*     */   public String getUserId() {
/* 267 */     return this.userId;
/*     */   }
/*     */ 
/*     */   public String getPassword() {
/* 271 */     return this.password;
/*     */   }
/*     */ 
/*     */   public Tlv getCookie() {
/* 275 */     return this.cookie;
/*     */   }
/*     */ 
/*     */   public void setCookie(Tlv cookie) {
/* 279 */     this.cookie = cookie;
/*     */   }
/*     */ 
/*     */   public OscarClient getClient() {
/* 283 */     return this.client;
/*     */   }
/*     */ 
/*     */   public void setClient(OscarClient client) {
/* 287 */     this.client = client;
/*     */   }
/*     */ 
/*     */   public Tweaker getTweaker() {
/* 291 */     return this.tweaker;
/*     */   }
/*     */ 
/*     */   public OscarPacketAnalyser getPacketAnalyser() {
/* 295 */     return this.analyser;
/*     */   }
/*     */ 
/*     */   public List getMessagingListeners() {
/* 299 */     return this.messagingListeners;
/*     */   }
/*     */ 
/*     */   public List getOurStatusListeners() {
/* 303 */     return this.ourStatusListeners;
/*     */   }
/*     */ 
/*     */   public List getUserStatusListeners() {
/* 307 */     return this.userStatusListeners;
/*     */   }
/*     */ 
/*     */   public List getXStatusListeners() {
/* 311 */     return this.xStatusListeners;
/*     */   }
/*     */ 
/*     */   public List getContactListListeners() {
/* 315 */     return this.contactListListeners;
/*     */   }
/*     */ 
/*     */   public List getMetaInfoListeners() {
/* 319 */     return this.metaInfoListeners;
/*     */   }
/*     */ 
/*     */   public List getMetaAckListeners() {
/* 323 */     return this.metaAckListeners;
/*     */   }
/*     */ 
/*     */   public RequestKeeper getRequestKeeper() {
/* 327 */     return this.requestKeeper;
/*     */   }
/*     */ 
/*     */   public IContactList getContactList()
/*     */   {
/* 332 */     if (this.contactList == null) {
/* 333 */       OscarInterface.sendContatListRequest(this);
/*     */     }
/*     */ 
/* 336 */     return this.contactList;
/*     */   }
/*     */ 
/*     */   public void buildContactList(Group rootGroup, int count) {
/* 340 */     synchronized (this.contactListLock) {
/* 341 */       this.contactList = new ContactList(this, rootGroup, count);
/*     */ 
/* 343 */       this.contactListLock.notifyAll();
/*     */     }
/*     */   }
/*     */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.core.OscarConnection
 * JD-Core Version:    0.6.0
 */