/*    */ package ru.caffeineim.protocols.icq.core;
/*    */ 
/*    */ import ru.caffeineim.protocols.icq.core.exceptions.LoginException;
/*    */ import ru.caffeineim.protocols.icq.integration.events.LoginErrorEvent;
/*    */ import ru.caffeineim.protocols.icq.integration.listeners.OurStatusListener;
/*    */ 
/*    */ public class OscarPacketHandler
/*    */   implements Runnable
/*    */ {
/*    */   public static final String THREAD_NAME = "OscarPacketHandlerThread";
/*    */   private Thread thread;
/*    */   private OscarClient client;
/*    */   private boolean runnable;
/*    */ 
/*    */   public OscarPacketHandler(OscarClient client)
/*    */   {
/* 37 */     this.client = client;
/* 38 */     this.runnable = true;
/* 39 */     this.thread = new Thread(this);
/* 40 */     this.thread.start();
/*    */   }
/*    */ 
/*    */   public void run() {
/*    */     try {
/* 45 */       while (this.runnable) {
/* 46 */         if (!this.client.getMessageQueue().isEmpty()) {
/* 47 */           this.client.getAnalyser().handlePacket(this.client.getMessageQueue().poll()); continue;
/*    */         }
/*    */         try {
/* 50 */           Thread.sleep(100);
/*    */         }
/*    */         catch (InterruptedException ex)
/*    */         {
/*    */         }
/*    */       }
/*    */     }
/*    */     catch (LoginException ex)
/*    */     {
/* 59 */       LoginErrorEvent e = new LoginErrorEvent(ex.getErrorType());
/* 60 */       for (int i = 0; i < this.client.getAnalyser().getConnection().getOurStatusListeners().size(); i++) {
/* 61 */         OurStatusListener l = (OurStatusListener)this.client.getAnalyser().getConnection().getOurStatusListeners().get(i);
/*    */ 
/* 64 */         l.onAuthorizationFailed(e);
/*    */       }
/* 66 */       this.runnable = false;
/*    */     }
/*    */   }
/*    */ 
/*    */   public synchronized void stop() {
/* 71 */     this.runnable = false;
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.core.OscarPacketHandler
 * JD-Core Version:    0.6.0
 */