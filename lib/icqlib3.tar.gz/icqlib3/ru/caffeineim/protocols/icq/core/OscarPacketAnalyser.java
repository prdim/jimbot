/*     */ package ru.caffeineim.protocols.icq.core;
/*     */ 
/*     */ import ru.caffeineim.protocols.icq.core.exceptions.LoginException;
/*     */ import ru.caffeineim.protocols.icq.packet.received.AuthorizationReply;
/*     */ import ru.caffeineim.protocols.icq.packet.received.ReceivedPacket;
/*     */ import ru.caffeineim.protocols.icq.packet.sent.generic.AuthorizationRequest;
/*     */ import ru.caffeineim.protocols.icq.packet.sent.generic.SignonCommand;
/*     */ import ru.caffeineim.protocols.icq.tool.Dumper;
/*     */ 
/*     */ public class OscarPacketAnalyser
/*     */ {
/*     */   private OscarConnection connection;
/*  35 */   private int nbPacket = 0;
/*     */ 
/*     */   public OscarPacketAnalyser(OscarConnection connection) {
/*  38 */     this.connection = connection;
/*     */   }
/*     */ 
/*     */   protected void handlePacket(byte[] packet)
/*     */     throws LoginException
/*     */   {
/*     */     boolean handled;
/*     */     try
/*     */     {
/*  53 */       handled = handleInitialPackets(packet);
/*     */     } catch (LoginException E) {
/*  55 */       throw new LoginException(E.getErrorType(), E);
/*     */     }
/*     */ 
/*  59 */     if (!handled)
/*     */       try {
/*  61 */         handleService(packet);
/*     */       }
/*     */       catch (Exception e) {
/*     */       }
/*     */   }
/*     */ 
/*     */   private boolean handleInitialPackets(byte[] packet) throws LoginException {
/*  68 */     if (this.nbPacket == 0) {
/*  69 */       this.nbPacket += 1;
/*  70 */       this.connection.sendFlap(new AuthorizationRequest(this.connection.getUserId(), this.connection.getPassword()));
/*  71 */     } else if (this.nbPacket == 1) {
/*  72 */       this.nbPacket += 1;
/*  73 */       AuthorizationReply reply = new AuthorizationReply(packet);
/*  74 */       reply.execute(this.connection);
/*  75 */     } else if (this.nbPacket == 2) {
/*  76 */       this.nbPacket += 1;
/*  78 */       this.connection.sendFlap(new SignonCommand(this.connection.getCookie()));
/*     */     } else {
/*  80 */       return false;
/*     */     }
/*  82 */     return true;
/*     */   }
/*     */ 
/*     */   protected void handleService(byte[] packet) throws Exception {
/*  86 */     ReceivedPacket receivedFlap = new ReceivedPacket(packet, true);
/*  87 */     int familyId = receivedFlap.getSnac().getFamilyId();
/*  88 */     int subTypeId = receivedFlap.getSnac().getSubTypeId();
/*     */ 
/*  92 */     Dumper.log(packet, true, 8, 16);
/*     */ 
/*  94 */     Class<ReceivedPacket> loadedClass = ReceivedPackedClassLoader.loadClass(familyId, subTypeId);
/*  95 */     if (loadedClass != null) {
/*  96 */       Class constructorParam = packet.getClass();
/*  97 */       Object param = packet;
/*     */       try
/*     */       {
/* 100 */         receivedFlap = loadedClass.getConstructor(constructorParam).newInstance(param);
/*     */ 
/* 102 */         receivedFlap.execute(this.connection);
/* 103 */         receivedFlap.notifyEvent(this.connection);
/*     */ 
/* 105 */         packet = null;
/*     */       }
/*     */       catch (Exception ex)
/*     */       {
/*     */       }
/*     */     }
/* 111 */     receivedFlap.matchRequest(this.connection);
/*     */ 
/* 114 */     if ((familyId == 9) && (subTypeId == 3))
/* 115 */       this.connection.setAuthorized(true);
/*     */   }
/*     */ 
/*     */   public OscarConnection getConnection()
/*     */   {
/* 124 */     return this.connection;
/*     */   }
/*     */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.core.OscarPacketAnalyser
 * JD-Core Version:    0.6.0
 */