/*    */ package ru.caffeineim.protocols.icq.core;
/*    */ 
/*    */ import java.util.Properties;
/*    */ 
/*    */ public class OscarConfiguration
/*    */ {
/*    */   private static final String CONFIG_FILE = "/icqlib.properties";
/*    */   public static final String VERSION = "VERSION";
/*    */   public static final String PING_TIMEOUT = "PING_TIMEOUT";
/* 32 */   private static Properties properties = new Properties();
/*    */ 
/* 34 */   private static boolean loaded = false;
/*    */ 
/*    */   public static void load()
/*    */   {
/* 38 */     loaded = true;
/*    */   }
/*    */ 
/*    */   public static String get(String property) {
/* 42 */     if (!loaded) {
/* 43 */       load();
/*    */     }
/* 45 */     if (!properties.containsKey(property)) {
/* 46 */       throw new IllegalStateException("Could not find property " + property);
/*    */     }
/* 48 */     return properties.getProperty(property);
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.core.OscarConfiguration
 * JD-Core Version:    0.6.0
 */