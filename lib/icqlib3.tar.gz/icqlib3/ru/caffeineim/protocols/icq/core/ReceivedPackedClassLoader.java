/*    */ package ru.caffeineim.protocols.icq.core;
/*    */ 
import ru.caffeineim.protocols.icq.packet.received.ReceivedPacket;
/*    */ 
/*    */ public class ReceivedPackedClassLoader{
/*    */ 
/*    */   public static Class<ReceivedPacket> loadClass(int commandId, int subCommandId) {
/* 33 */     Class ret = null;
/*    */       try {
switch(commandId){
    case 1:
        switch(subCommandId){
            case 3:
                ret = Class.forName("ru.caffeineim.protocols.icq.packet.received.generic.ServerReady__1_3");
            break;
            case 7:
                ret = Class.forName("ru.caffeineim.protocols.icq.packet.received.generic.RateReply__1_7");
            break;
            case 11:
                ret = Class.forName("ru.caffeineim.protocols.icq.packet.received.generic.PauseReq__1_11");
            break;
            case 15:
                ret = Class.forName("ru.caffeineim.protocols.icq.packet.received.generic.OnlineInfoResp__1_15");
            break;
            case 18:
                ret = Class.forName("ru.caffeineim.protocols.icq.packet.received.generic.BOSMigration__1_18");
            break;
            case 19:
                ret = Class.forName("ru.caffeineim.protocols.icq.packet.received.generic.Motd__1_19");
            break;
            case 24:
                ret = Class.forName("ru.caffeineim.protocols.icq.packet.received.generic.ServerFamilies__1_24");
            break;
        }
    break;
    case 2:
        switch(subCommandId){
            case 3:
                ret = Class.forName("ru.caffeineim.protocols.icq.packet.received.location.LocationRightsReply__2_3");
            break;
        }
    break;
    case 3:
        switch(subCommandId){
            case 3:
                ret = Class.forName("ru.caffeineim.protocols.icq.packet.received.byddylist.BuddyListRightsReply__3_3");
            break;
            case 10:
                ret = Class.forName("ru.caffeineim.protocols.icq.packet.received.byddylist.RefusedContact__3_10");
            break;
            case 11:
                ret = Class.forName("ru.caffeineim.protocols.icq.packet.received.byddylist.IncomingUser__3_11");
            break;
            case 12:
                ret = Class.forName("ru.caffeineim.protocols.icq.packet.received.byddylist.OffgoingUser__3_12");
            break;
        }
    break;
    case 4:
        switch(subCommandId){
            case 1:
                ret = Class.forName("ru.caffeineim.protocols.icq.packet.received.icbm.ServerICBMError__4_1");
            break;
            case 5:
                ret = Class.forName("ru.caffeineim.protocols.icq.packet.received.icbm.ICBMParametersReply__4_5");
            break;
            case 7:
                ret = Class.forName("ru.caffeineim.protocols.icq.packet.received.icbm.IncomingMessage__4_7");
            break;
            case 10:
                ret = Class.forName("ru.caffeineim.protocols.icq.packet.received.icbm.MissedMessage__4_10");
            break;
            case 11:
                ret = Class.forName("ru.caffeineim.protocols.icq.packet.received.icbm.MessageAutoReply__4_11");
            break;
            case 12:
                ret = Class.forName("ru.caffeineim.protocols.icq.packet.received.icbm.MessageAck__4_12");
            break;
            case 20:
                ret = Class.forName("ru.caffeineim.protocols.icq.packet.received.icbm.TypingNotif__4_20");
            break;
        }
    break;
    case 19:
        switch(subCommandId){
            case 6:
                ret = Class.forName("ru.caffeineim.protocols.icq.packet.received.ssi.SsiContactListReply__19_6");
            break;
            case 14:
                ret = Class.forName("ru.caffeineim.protocols.icq.packet.received.ssi.SsiModifyingAck__19_14");
            break;
            case 20:
                ret = Class.forName("ru.caffeineim.protocols.icq.packet.received.ssi.SsiFutureAuthGranted__19_20");
            break;
            case 25:
                ret = Class.forName("ru.caffeineim.protocols.icq.packet.received.ssi.SsiAuthRequest__19_25");
            break;
            case 27:
                ret = Class.forName("ru.caffeineim.protocols.icq.packet.received.ssi.SsiAuthReply__19_27");
            break;
        }
    break;
    case 21:
        switch(subCommandId){
            case 1:
                ret = Class.forName("ru.caffeineim.protocols.icq.packet.received.meta.MetaError__21_1");
            break;
            case 3:
                ret = Class.forName("ru.caffeineim.protocols.icq.packet.received.meta.ServerMetaReply__21_3");
            break;
        }
    break;
    case 9:
        switch(subCommandId){
            case 3:
                ret = Class.forName("ru.caffeineim.protocols.icq.packet.received.privacy.BosRightReply__9_3");
            break;
        }
    break;
    case 11:
        switch(subCommandId){
            case 2:
                ret = Class.forName("ru.caffeineim.protocols.icq.packet.received.usagestats.MinReportInterval__11_2");
            break;
        }
    break;
    case 23:
        switch(subCommandId){
            case 1:
                ret = Class.forName("ru.caffeineim.protocols.icq.packet.received.authorization.UINRegistrationFailed__23_1");
            break;
            case 5:
                ret = Class.forName("ru.caffeineim.protocols.icq.packet.received.authorization.UINRegistrationSuccess__23_5");
            break;
        }
    break;
}
/*    */ 
/*    */       }catch (ClassNotFoundException CNFE)
/*    */       {
/*    */       }
/* 45 */     return ret;
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.core.ReceivedPackedClassLoader
 * JD-Core Version:    0.6.0
 */