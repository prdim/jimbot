/*    */ package ru.caffeineim.protocols.icq.core.exceptions;
/*    */ 
/*    */ import ru.caffeineim.protocols.icq.setting.enumerations.LoginErrorTypeEnum;
/*    */ 
/*    */ public class LoginException extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 5005784558498444971L;
/*    */   private LoginErrorTypeEnum errorType;
/*    */ 
/*    */   public LoginException(LoginErrorTypeEnum type)
/*    */   {
/* 30 */     super(type.toString());
/* 31 */     this.errorType = type;
/*    */   }
/*    */ 
/*    */   public LoginException(LoginErrorTypeEnum type, Throwable t) {
/* 35 */     super(type.toString(), t);
/* 36 */     this.errorType = type;
/*    */   }
/*    */ 
/*    */   public LoginException(String s, Throwable t) {
/* 40 */     super(s, t);
/* 41 */     this.errorType = new LoginErrorTypeEnum(0);
/*    */   }
/*    */ 
/*    */   public LoginErrorTypeEnum getErrorType() {
/* 45 */     return this.errorType;
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.core.exceptions.LoginException
 * JD-Core Version:    0.6.0
 */