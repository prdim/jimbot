/*     */ package ru.caffeineim.protocols.icq.core;
/*     */ 
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.Socket;
import java.util.concurrent.ConcurrentLinkedQueue;
/*     */ import javax.net.SocketFactory;
/*     */ 
/*     */ public class OscarClient
/*     */   implements Runnable
/*     */ {
/*     */   public static final String THREAD_NAME = "OscarClientThread";
/*     */   private OscarPacketAnalyser analyser;
/*     */   private OscarPacketHandler handler;
/*     */   private String host;
/*     */   private int port;
/*     */   private Socket socketClient;
/*     */   private InputStream in;
/*     */   private OutputStream out;
/*     */   private Thread runner;
/*  48 */   private boolean running = true;
/*  49 */   private ConcurrentLinkedQueue<byte[]> messagesQueue = null;
/*     */   private SocketFactory factory;
/*     */ 
/*     */   public OscarClient(String host, int port, OscarPacketAnalyser analyser)
/*     */   {
/*  61 */     this.analyser = analyser;
/*  62 */     this.host = host;
/*  63 */     this.port = port;
/*  64 */     this.runner = new Thread(this, "OscarClientThread");
/*  65 */     this.messagesQueue = new ConcurrentLinkedQueue<byte[]>();
/*     */   }
/*     */ 
/*     */   public OscarClient(String host, int port, OscarPacketAnalyser analyser, SocketFactory factory)
/*     */   {
/*  79 */     this.analyser = analyser;
/*  80 */     this.host = host;
/*  81 */     this.port = port;
/*  82 */     this.factory = factory;
/*  83 */     this.runner = new Thread(this, "OscarClientThread");
/*  84 */     this.messagesQueue = new ConcurrentLinkedQueue<byte[]>();
/*     */   }
/*     */ 
/*     */   public synchronized void connect()
/*     */     throws IOException
/*     */   {
/*  95 */     if (this.factory == null)
/*  96 */       this.socketClient = new Socket(this.host, this.port);
/*     */     else {
/*  98 */       this.socketClient = this.factory.createSocket(this.host, this.port);
/*     */     }
/*     */ 
/* 101 */     this.out = new DataOutputStream(this.socketClient.getOutputStream());
/* 102 */     this.in = this.socketClient.getInputStream();
/*     */ 
/* 105 */     this.runner.start();
/*     */ 
/* 108 */     this.handler = new OscarPacketHandler(this);
/*     */   }
/*     */ 
/*     */   public synchronized void disconnect()
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 117 */       if (this.socketClient != null)
/* 118 */         this.socketClient.shutdownInput();
/*     */     }
/*     */     finally {
/*     */       try {
/* 122 */         if (this.socketClient != null)
/* 123 */           this.socketClient.shutdownOutput();
/*     */       }
/*     */       finally {
/*     */         try {
/* 127 */           this.socketClient.close();
/*     */         }
/*     */         finally {
/* 130 */           this.running = false;
/* 131 */           this.handler.stop();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void run()
/*     */   {
/* 148 */     byte[] header = new byte[6];
/* 149 */     byte[] packet = null;
/* 150 */     int packetLen = 0;
/* 151 */     boolean waitData = false;
/*     */     try
/*     */     {
/* 154 */       while (this.running) {
/* 155 */         if (!waitData)
/*     */         {
/* 157 */           if (this.in.available() >= 6) {
/* 158 */             this.in.read(header, 0, 6);
/*     */ 
/* 160 */             packetLen = getPacketLen(header);
/* 161 */             packet = new byte[packetLen + 6];
/* 162 */             waitData = true;
/*     */           }
/*     */ 
/*     */         }
/* 166 */         else if (this.in.available() >= packetLen) {
/* 167 */           this.in.read(packet, 6, packetLen);
/*     */ 
/* 169 */           System.arraycopy(header, 0, packet, 0, 6);
/* 170 */           getMessageQueue().add(packet);
/* 171 */           waitData = false;
/*     */         }
/*     */ 
/* 175 */         if (this.in.available() == 0)
/* 176 */           Thread.sleep(100L);
/*     */       }
/*     */     }

/*     */     catch (IOException ex) {
/* 180 */       ex.printStackTrace();
/*     */     }catch(InterruptedException ex) {
/* 180 */       ex.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public byte[] getInetaddress()
/*     */   {
/* 193 */     return this.socketClient.getLocalAddress().getAddress();
/*     */   }
/*     */ 
/*     */   public ConcurrentLinkedQueue<byte[]> getMessageQueue() {
/* 197 */     return this.messagesQueue;
/*     */   }
/*     */ 
/*     */   public OscarPacketAnalyser getAnalyser() {
/* 201 */     return this.analyser;
/*     */   }
/*     */ 
/*     */   private static int getPacketLen(byte[] header)
/*     */   {
/* 210 */     int result = header[4] << 8 & 0xFF00;
/* 211 */     result |= header[5] & 0xFF;
/* 212 */     return result;
/*     */   }
/*     */ 
/*     */   public void sendPacket(byte[] packet)
/*     */     throws IOException
/*     */   {
///* 224 */     Dumper.log(packet, true, 8, 16);
/*     */ 
/* 226 */     this.out.write(packet);
/* 227 */     this.out.flush();
/*     */   }
/*     */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.core.OscarClient
 * JD-Core Version:    0.6.0
 */