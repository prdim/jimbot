/*    */ package ru.caffeineim.protocols.icq.core;
/*    */ 
/*    */ public class OscarPingHandler
/*    */   implements Runnable
/*    */ {
/*    */   public static final String THREAD_NAME = "OscarPingHandlerThread";
/* 28 */   private static long uin = 300300L;
/*    */   private Thread thread;
/*    */   private long interval;
/*    */   private OscarConnection connection;
/*    */   private boolean running;
/*    */ 
/*    */   public OscarPingHandler(OscarConnection connection, long interval)
/*    */   {
/* 36 */     this.connection = connection;
/* 37 */     this.interval = interval;
/* 38 */     this.running = true;
/*    */ 
/* 40 */     this.thread = new Thread(this, "OscarPingHandlerThread");
/* 41 */     this.thread.start();
/*    */   }
/*    */ 
/*    */   public void run()
/*    */   {
/*    */   }
/*    */ 
/*    */   public synchronized void stop() {
/* 49 */     this.running = false;
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.core.OscarPingHandler
 * JD-Core Version:    0.6.0
 */