package ru.caffeineim.protocols.icq.core;

public abstract interface IReceivable
{
  public abstract void execute(OscarConnection paramOscarConnection)
    throws Exception;

  public abstract void notifyEvent(OscarConnection paramOscarConnection);
}

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.core.IReceivable
 * JD-Core Version:    0.6.0
 */