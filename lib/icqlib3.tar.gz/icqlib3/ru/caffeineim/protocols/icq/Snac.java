/*     */ package ru.caffeineim.protocols.icq;
/*     */ 
/*     */ public class Snac extends DataContainer
/*     */ {
/*     */   private static final int SNAC_HEADER_SIZE = 10;
/*     */   private RawData familyId;
/*     */   private RawData subTypeId;
/*     */   private RawData flag0;
/*     */   private RawData flag1;
/*     */   private RawData requestId;
/*     */   private byte[] headerByteArray;
/*     */ 
/*     */   private Snac()
/*     */   {
/*  34 */     this.headerByteArray = new byte[10];
/*     */   }
/*     */ 
/*     */   public Snac(int familyID, int subTypeID, int flag0, int flag1, int requestID)
/*     */   {
/*  47 */     this();
/*  48 */     this.familyId = new RawData(familyID, 2);
/*  49 */     this.subTypeId = new RawData(subTypeID, 2);
/*  50 */     this.flag0 = new RawData(flag0, 1);
/*  51 */     this.flag1 = new RawData(flag1, 1);
/*  52 */     this.requestId = new RawData(requestID, 4);
/*     */   }
/*     */ 
/*     */   public Snac(byte[] array, int start) {
/*  56 */     this();
/*  57 */     byte[] famArray = new byte[2];
/*  58 */     byte[] subFamArray = new byte[2];
/*  59 */     byte[] requestArray = new byte[4];
/*  60 */     byte[] dataFieldArray = new byte[array.length - (start + 10)];
/*     */ 
/*  62 */     System.arraycopy(array, start, famArray, 0, 2);
/*  63 */     this.familyId = new RawData(famArray);
/*  64 */     System.arraycopy(array, start + 2, subFamArray, 0, 2);
/*  65 */     this.subTypeId = new RawData(subFamArray);
/*     */ 
/*  67 */     this.flag0 = new RawData(array[(start + 4)]);
/*  68 */     this.flag1 = new RawData(array[(start + 5)]);
/*     */ 
/*  70 */     System.arraycopy(array, start + 6, requestArray, 0, 4);
/*  71 */     this.requestId = new RawData(requestArray);
/*     */ 
/*  73 */     System.arraycopy(array, start + 10, dataFieldArray, 0, array.length - (start + 10));
/*     */ 
/*  75 */     addRawDataToSnac(new RawData(dataFieldArray));
/*     */   }
/*     */ 
/*     */   public int getFamilyId()
/*     */   {
/*  83 */     return this.familyId.getValue();
/*     */   }
/*     */ 
/*     */   public int getSubTypeId()
/*     */   {
/*  91 */     return this.subTypeId.getValue();
/*     */   }
/*     */ 
/*     */   public int getFlag0()
/*     */   {
/*  99 */     return this.flag0.getValue();
/*     */   }
/*     */ 
/*     */   public int getFlag1()
/*     */   {
/* 107 */     return this.flag1.getValue();
/*     */   }
/*     */ 
/*     */   public int getRequestId()
/*     */   {
/* 115 */     return this.requestId.getValue();
/*     */   }
/*     */ 
/*     */   public void setRequestId(int requestId)
/*     */   {
/* 124 */     this.requestId = new RawData(requestId, 4);
/* 125 */     this.headerModified = true;
/*     */   }
/*     */ 
/*     */   public void addTlvToSnac(Tlv tlv)
/*     */   {
/* 134 */     addDataField(tlv);
/*     */   }
/*     */ 
/*     */   public void addRawDataToSnac(RawData rawData)
/*     */   {
/* 143 */     addDataField(rawData);
/*     */   }
/*     */ 
/*     */   public byte[] getHeaderByteArray() {
/* 147 */     if (this.headerModified) {
/* 148 */       int position = 0;
/*     */ 
/* 150 */       System.arraycopy(this.familyId.getByteArray(), 0, this.headerByteArray, position, this.familyId.getByteArray().length);
/*     */ 
/* 152 */       position += this.familyId.getByteArray().length;
/* 153 */       System.arraycopy(this.subTypeId.getByteArray(), 0, this.headerByteArray, position, this.familyId.getByteArray().length);
/*     */ 
/* 155 */       position += this.familyId.getByteArray().length;
/* 156 */       System.arraycopy(this.flag0.getByteArray(), 0, this.headerByteArray, position, this.flag0.getByteArray().length);
/*     */ 
/* 158 */       position += this.flag0.getByteArray().length;
/* 159 */       System.arraycopy(this.flag1.getByteArray(), 0, this.headerByteArray, position, this.flag1.getByteArray().length);
/*     */ 
/* 161 */       position += this.flag1.getByteArray().length;
/* 162 */       System.arraycopy(this.requestId.getByteArray(), 0, this.headerByteArray, position, this.requestId.getByteArray().length);
/*     */ 
/* 164 */       this.headerModified = false;
/*     */     }
/*     */ 
/* 167 */     return this.headerByteArray;
/*     */   }
/*     */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.Snac
 * JD-Core Version:    0.6.0
 */