/*    */ package ru.caffeineim.protocols.icq.exceptions;
/*    */ 
/*    */ public class ConvertStringException extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = -1762433449639556815L;
/*    */ 
/*    */   public ConvertStringException()
/*    */   {
/* 27 */     this("Could not convert string to bytes array");
/*    */   }
/*    */ 
/*    */   public ConvertStringException(String message) {
/* 31 */     super(message);
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.exceptions.ConvertStringException
 * JD-Core Version:    0.6.0
 */