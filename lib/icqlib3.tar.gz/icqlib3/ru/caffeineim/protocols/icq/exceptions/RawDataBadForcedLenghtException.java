/*    */ package ru.caffeineim.protocols.icq.exceptions;
/*    */ 
/*    */ public class RawDataBadForcedLenghtException extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = 6449626761309289881L;
/*    */ 
/*    */   public RawDataBadForcedLenghtException(String s)
/*    */   {
/* 32 */     super(s);
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.exceptions.RawDataBadForcedLenghtException
 * JD-Core Version:    0.6.0
 */