/*    */ package ru.caffeineim.protocols.icq.exceptions;
/*    */ 
/*    */ public class ContactListOperationException extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = -2693101766944086413L;
/*    */ 
/*    */   public ContactListOperationException(String message)
/*    */   {
/* 27 */     super(message);
/*    */   }
/*    */ 
/*    */   public ContactListOperationException(String message, Throwable t) {
/* 31 */     super(message, t);
/*    */   }
/*    */ 
/*    */   public ContactListOperationException(Throwable t) {
/* 35 */     super(t);
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.exceptions.ContactListOperationException
 * JD-Core Version:    0.6.0
 */