/*     */ package ru.caffeineim.protocols.icq.request;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import ru.caffeineim.protocols.icq.Flap;
/*     */ import ru.caffeineim.protocols.icq.Snac;
/*     */ import ru.caffeineim.protocols.icq.request.event.RequestListener;
/*     */ 
/*     */ public class Request
/*     */ {
/*     */   private Flap monitoredFlap;
/*     */   private ArrayList listeners;
/*     */ 
/*     */   public Request(Flap packet, RequestListener listener)
/*     */   {
/*  40 */     this.monitoredFlap = packet;
/*  41 */     this.listeners = new ArrayList();
/*  42 */     this.listeners.add(listener);
/*     */   }
/*     */ 
/*     */   public boolean containsListener(RequestListener listener)
/*     */   {
/*  53 */     return this.listeners.contains(listener);
/*     */   }
/*     */ 
/*     */   public void addListener(RequestListener listener)
/*     */   {
/*  62 */     if (!containsListener(listener))
/*  63 */       this.listeners.add(listener);
/*     */   }
/*     */ 
/*     */   public void removeListener(RequestListener listener)
/*     */   {
/*  72 */     if (containsListener(listener))
/*  73 */       this.listeners.remove(listener);
/*     */   }
/*     */ 
/*     */   public void removeAllListener()
/*     */   {
/*  80 */     this.listeners.clear();
/*     */   }
/*     */ 
/*     */   public int getRequestId()
/*     */   {
/*  89 */     return this.monitoredFlap.getSnac().getRequestId();
/*     */   }
/*     */ 
/*     */   public Flap getMonitoredFlap()
/*     */   {
/*  98 */     return this.monitoredFlap;
/*     */   }
/*     */ 
/*     */   public int getNbListeners()
/*     */   {
/* 107 */     return this.listeners.size();
/*     */   }
/*     */ 
/*     */   public RequestListener getRequestListener(int index)
/*     */     throws IndexOutOfBoundsException
/*     */   {
/* 118 */     return (RequestListener)this.listeners.get(index);
/*     */   }
/*     */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.request.Request
 * JD-Core Version:    0.6.0
 */