/*    */ package ru.caffeineim.protocols.icq.request.event;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ import ru.caffeineim.protocols.icq.Flap;
/*    */ 
/*    */ public class RequestAnswerEvent extends EventObject
/*    */ {
/*    */   private static final long serialVersionUID = 1877859126220384940L;
/*    */   private Flap request;
/*    */ 
/*    */   public RequestAnswerEvent(Flap requestPacket, Flap requestAnswerPacket)
/*    */   {
/* 40 */     super(requestAnswerPacket);
/* 41 */     this.request = requestPacket;
/*    */   }
/*    */ 
/*    */   public Flap getRequestAnswerPacket()
/*    */   {
/* 50 */     return (Flap)getSource();
/*    */   }
/*    */ 
/*    */   public Flap getRequestPacket()
/*    */   {
/* 59 */     return this.request;
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.request.event.RequestAnswerEvent
 * JD-Core Version:    0.6.0
 */