/*     */ package ru.caffeineim.protocols.icq.request;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.TreeMap;
/*     */ import ru.caffeineim.protocols.icq.Flap;
/*     */ import ru.caffeineim.protocols.icq.Snac;
/*     */ import ru.caffeineim.protocols.icq.request.event.RequestListener;
/*     */ 
/*     */ public class RequestKeeper extends TreeMap
/*     */ {
/*     */   private static final long serialVersionUID = -5562290489832818366L;
/*     */   private ArrayList freeRequestId;
/*  33 */   private int requestId = 0;
/*     */ 
/*     */   public RequestKeeper()
/*     */   {
/*  40 */     this.freeRequestId = new ArrayList(2);
/*     */   }
/*     */ 
/*     */   public void addRequest(Flap packet, RequestListener listener)
/*     */   {
/*  50 */     if (packet.hasSnac())
/*     */     {
/*  52 */       if (containsRequest(packet.getSnac().getRequestId())) {
/*  53 */         Request request = getRequest(packet.getSnac().getRequestId());
/*  54 */         request.addListener(listener);
/*     */       }
/*     */       else
/*     */       {
/*  58 */         Request request = new Request(packet, listener);
/*  59 */         put(new Integer(packet.getSnac().getRequestId()), request);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addRequest(Request request)
/*     */   {
/*  72 */     if (containsRequest(request.getRequestId())) {
/*  73 */       Request existingRequest = getRequest(request.getRequestId());
/*  74 */       for (int i = 0; i < request.getNbListeners(); i++) {
/*  75 */         if (!existingRequest.containsListener(request.getRequestListener(i)))
/*  76 */           existingRequest.addListener(request.getRequestListener(i));
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/*  81 */       put(new Integer(request.getRequestId()), request);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void removeRequestListener(Flap packet, RequestListener listener)
/*     */   {
/*  98 */     if (packet.hasSnac())
/*  99 */       removeRequestListener(packet.getSnac().getRequestId(), listener);
/*     */   }
/*     */ 
/*     */   public void removeRequestListener(int requestId, RequestListener listener)
/*     */   {
/* 115 */     if (containsKey(new Integer(requestId))) {
/* 116 */       Request request = (Request)get(new Integer(requestId));
/* 117 */       request.removeListener(listener);
/* 118 */       this.freeRequestId.add(new Integer(requestId));
/* 119 */       if (request.getNbListeners() == 0)
/* 120 */         remove(new Integer(requestId));
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean containsRequest(int requestId)
/*     */   {
/* 135 */     return containsKey(new Integer(requestId));
/*     */   }
/*     */ 
/*     */   public boolean containsRequest(Flap packet)
/*     */   {
/* 149 */     if (packet.hasSnac()) {
/* 150 */       return containsRequest(packet.getSnac().getRequestId());
/*     */     }
/* 152 */     return false;
/*     */   }
/*     */ 
/*     */   public Request getRequest(int requestId)
/*     */   {
/* 164 */     return (Request)get(new Integer(requestId));
/*     */   }
/*     */ 
/*     */   public Request getRequest(Flap packet)
/*     */   {
/* 176 */     return getRequest(packet.getSnac().getRequestId());
/*     */   }
/*     */ 
/*     */   public int nextAvailableRequestId()
/*     */   {
/*     */     int rId;
/* 187 */     if (this.freeRequestId.size() > 0) {
/* 188 */       rId = ((Integer)this.freeRequestId.get(0)).intValue();
/* 189 */       this.freeRequestId.remove(0);
/*     */     }
/*     */     else {
/* 192 */       rId = ++this.requestId;
/* 193 */     }return rId;
/*     */   }
/*     */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.request.RequestKeeper
 * JD-Core Version:    0.6.0
 */