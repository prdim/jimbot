package ru.caffeineim.protocols.icq;

public abstract class DataField
{
  protected byte[] byteArray;

  protected abstract byte[] getByteArray();
}

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.DataField
 * JD-Core Version:    0.6.0
 */