/*     */ package ru.caffeineim.protocols.icq;
/*     */ 
/*     */ public class Flap extends DataContainer
/*     */ {
/*     */   private static final int FLAP_HEADER_SIZE = 6;
/*     */   private RawData commandStart;
/*     */   private RawData channelId;
/*     */   private RawData sequenceNumber;
/*     */   private RawData dataFieldLength;
/*     */   private byte[] headerByteArray;
/*  32 */   private boolean hasSnac = false;
/*     */ 
/*     */   public Flap()
/*     */   {
/*  39 */     this.headerByteArray = new byte[6];
/*  40 */     this.commandStart = new RawData(42);
/*  41 */     this.sequenceNumber = null;
/*     */   }
/*     */ 
/*     */   public Flap(int channelId)
/*     */   {
/*  51 */     this();
/*  52 */     this.channelId = new RawData(channelId, 1);
/*     */   }
/*     */ 
/*     */   public Flap(int channelId, Snac snac)
/*     */   {
/*  62 */     this(channelId);
/*  63 */     addSnac(snac);
/*     */   }
/*     */ 
/*     */   public int getChannelId()
/*     */   {
/*  72 */     return this.channelId.getValue();
/*     */   }
/*     */ 
/*     */   public void setChannelId(int channelId)
/*     */   {
/*  81 */     this.channelId = new RawData(channelId, 1);
/*  82 */     this.headerModified = true;
/*     */   }
/*     */ 
/*     */   public int getSequenceNumber()
/*     */   {
/*  91 */     if (this.sequenceNumber == null) {
/*  92 */       return 2147483647;
/*     */     }
/*  94 */     return this.sequenceNumber.getValue();
/*     */   }
/*     */ 
/*     */   public void setSequenceNumber(int sequenceNumber)
/*     */   {
/* 103 */     this.sequenceNumber = new RawData(sequenceNumber, 2);
/* 104 */     this.headerModified = true;
/*     */   }
/*     */ 
/*     */   public boolean hasSnac()
/*     */   {
/* 113 */     return this.hasSnac;
/*     */   }
/*     */ 
/*     */   public Snac getSnac()
/*     */   {
/* 120 */     return (Snac)elementAt(0);
/*     */   }
/*     */ 
/*     */   public void addSnac(Snac snac)
/*     */   {
/* 129 */     addDataField(snac);
/* 130 */     this.hasSnac = true;
/*     */   }
/*     */ 
/*     */   public void addTlvToFlap(Tlv tlv)
/*     */   {
/* 139 */     addDataField(tlv);
/*     */   }
/*     */ 
/*     */   public void addRawDataToFlap(RawData rawData)
/*     */   {
/* 148 */     addDataField(rawData);
/*     */   }
/*     */ 
/*     */   public byte[] getHeaderByteArray() {
/* 152 */     if (this.headerModified)
/*     */     {
/* 154 */       this.dataFieldLength = new RawData(getDataFieldByteArray().length, 2);
/*     */ 
/* 156 */       int position = 0;
/*     */ 
/* 158 */       System.arraycopy(this.commandStart.getByteArray(), 0, this.headerByteArray, position, this.commandStart.getByteArray().length);
/*     */ 
/* 160 */       position += this.commandStart.getByteArray().length;
/* 161 */       System.arraycopy(this.channelId.getByteArray(), 0, this.headerByteArray, position, this.channelId.getByteArray().length);
/*     */ 
/* 163 */       position += this.channelId.getByteArray().length;
/* 164 */       System.arraycopy(this.sequenceNumber.getByteArray(), 0, this.headerByteArray, position, this.sequenceNumber.getByteArray().length);
/*     */ 
/* 166 */       position += this.sequenceNumber.getByteArray().length;
/* 167 */       System.arraycopy(this.dataFieldLength.getByteArray(), 0, this.headerByteArray, position, this.dataFieldLength.getByteArray().length);
/*     */ 
/* 169 */       this.headerModified = false;
/*     */     }
/*     */ 
/* 172 */     return this.headerByteArray;
/*     */   }
/*     */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.Flap
 * JD-Core Version:    0.6.0
 */