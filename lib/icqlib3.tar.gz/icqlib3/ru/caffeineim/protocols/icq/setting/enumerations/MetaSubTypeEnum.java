/*    */ package ru.caffeineim.protocols.icq.setting.enumerations;
/*    */ 
/*    */ public class MetaSubTypeEnum
/*    */ {
/*    */   public static final int SERVER_META_PROCESSING_ERROR = 1;
/*    */   public static final int SERVER_SET_USER_HOME_INFO = 100;
/*    */   public static final int SERVER_SET_USER_WORK_INFO = 110;
/*    */   public static final int SERVER_SET_USER_MORE_INFO = 120;
/*    */   public static final int SERVER_SET_USER_NOTES_INFO = 130;
/*    */   public static final int SERVER_SET_USER_EMAIL_INFO = 135;
/*    */   public static final int SERVER_SET_USER_INTERESTS_INFO = 140;
/*    */   public static final int SERVER_SET_USER_AFFILATIONS_INFO = 150;
/*    */   public static final int SERVER_SET_USER_PERMISSIONS_INFO = 160;
/*    */   public static final int SERVER_SET_USER_PASSWORD = 170;
/*    */   public static final int SERVER_UNREGISTER_ACCOUNT = 180;
/*    */   public static final int SERVER_SET_USER_HOMEPAGE = 190;
/*    */   public static final int SERVER_BASIC_USER_INFO_REPLY = 200;
/*    */   public static final int SERVER_WORK_USER_INFO_REPLY = 210;
/*    */   public static final int SERVER_MORE_USER_INFO_REPLY = 220;
/*    */   public static final int SERVER_ABOUT_USER_INFO_REPLY = 230;
/*    */   public static final int SERVER_EXTENDED_EMAIL_USER_INFO_REPLY = 235;
/*    */   public static final int SERVER_INTERESTS_USER_INFO_REPLY = 240;
/*    */   public static final int SERVER_AFFILATIONS_USER_INFO_REPLY = 250;
/*    */   public static final int SERVER_SHORT_USER_INFO_REPLY = 260;
/*    */   public static final int SERVER_HOMEPAGE_USER_INFO_REPLY = 270;
/*    */   public static final int SERVER_USER_FOUND = 420;
/*    */   public static final int SERVER_LAST_USER_FOUND = 430;
/*    */   public static final int SERVER_REGISTATION_STATUS = 770;
/*    */   public static final int SERVER_RANDOM_SEARCH_REPLY = 870;
/*    */   public static final int SERVER_VARIABLE_REQUESTED_VIA_XML = 2210;
/*    */   public static final int SERVER_ACK_FOR_FULLINFO = 3135;
/*    */   public static final int SERVER_ACK_FOR_USER_SPAM_REPORT = 8210;
/*    */   public static final int SET_USER_BASIC_INFO = 1002;
/*    */   public static final int SET_USER_WORK_INFO = 1011;
/*    */   public static final int SET_USER_MORE_INFO = 1021;
/*    */   public static final int SET_USER_NOTES_INFO = 1030;
/*    */   public static final int SET_USER_EXTENDED_EMAIL_INFO = 1035;
/*    */   public static final int SET_USER_INTERESTS_INFO = 1040;
/*    */   public static final int SET_USER_AFFILIATIONS_INFO = 1050;
/*    */   public static final int SET_USER_PERMISSIONS_INFO = 1060;
/*    */   public static final int CHANGE_USER_PASSWORD = 1070;
/*    */   public static final int SET_USER_HOMEPAGE_CATEGORY_INFO = 1090;
/*    */   public static final int REQUEST_FULL_USER_INFO = 1202;
/*    */   public static final int REQUEST_SHORT_USER_INFO = 1210;
/*    */   public static final int UNREGISTER_USER = 1220;
/*    */   public static final int REQUEST_FULL_USER_INFO_2 = 1244;
/*    */   public static final int SEARCH_BY_DETAILS_PLAIN = 1301;
/*    */   public static final int SEARCH_BY_UIN_PLAIN = 1311;
/*    */   public static final int SEARCH_BY_EMAIL_PLAIN = 1321;
/*    */   public static final int WHITEPAGES_SEARCH_PLAIN_SIMPLE = 1331;
/*    */   public static final int SEARCH_BY_DETAILS_PLAIN_WILDCARD = 1341;
/*    */   public static final int SEARCH_BY_EMAIL_PLAIN_WILDCARD = 1351;
/*    */   public static final int WHITEPAGES_SEARCH_PLAIN_WILDCARD = 1361;
/*    */   public static final int SEARCH_BY_UIN_TLV = 1385;
/*    */   public static final int WHITEPAGES_SEARCH_TLV = 1375;
/*    */   public static final int SEARCH_BY_EMAIL_TLV = 1395;
/*    */   public static final int RANDOM_CHAT_USER_SEARCH = 1870;
/*    */   public static final int REQUEST_SERVER_VARIABLE_VIA_XML = 2200;
/*    */   public static final int SEND_REGISTRATION_STATS_REPORT = 2725;
/*    */   public static final int SEND_SHORTCUT_BAR_STATS_REPORT = 2735;
/*    */   public static final int SAVE_INFO_TLV_BASED = 3130;
/*    */   public static final int CLIENT_SEND_SMS = 5250;
/*    */   public static final int CLIENT_SPAM_REPORT = 8200;
/*    */   private int subType;
/*    */ 
/*    */   public MetaSubTypeEnum(int subType)
/*    */   {
/* 89 */     this.subType = subType;
/*    */   }
/*    */ 
/*    */   public int getSubType() {
/* 93 */     return this.subType;
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.setting.enumerations.MetaSubTypeEnum
 * JD-Core Version:    0.6.0
 */