/*     */ package ru.caffeineim.protocols.icq.setting.enumerations;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class InterestsEnum
/*     */ {
/*     */   public static final int UNSPECIFIED = 0;
/*     */   public static final int ART = 100;
/*     */   public static final int CARS = 101;
/*     */   public static final int CELEBRITY_FANS = 102;
/*     */   public static final int COLLECTIONS = 103;
/*     */   public static final int COMPUTERS = 104;
/*     */   public static final int CULTURE_LITERATURE = 105;
/*     */   public static final int FITNES = 106;
/*     */   public static final int GAMES = 107;
/*     */   public static final int HOBBIES = 108;
/*     */   public static final int ICQ_PROVIDING_HELP = 109;
/*     */   public static final int INTERNET = 110;
/*     */   public static final int LIFESTYLE = 111;
/*     */   public static final int MOVIES_TV = 112;
/*     */   public static final int MUSIC = 113;
/*     */   public static final int OUTDOOR_ACTIVITIES = 114;
/*     */   public static final int PARENTING = 115;
/*     */   public static final int PETS = 116;
/*     */   public static final int RELIGION = 117;
/*     */   public static final int SCIENCE = 118;
/*     */   public static final int SKILLS = 119;
/*     */   public static final int SPORTS = 120;
/*     */   public static final int WEB_DESIGN = 121;
/*     */   public static final int NATURE_AND_ENVIRONMENT = 122;
/*     */   public static final int NEWS_AND_MEDIA = 123;
/*     */   public static final int GOVERNMENT = 124;
/*     */   public static final int BUSINESS_ECONOMY = 125;
/*     */   public static final int MYSTICS = 126;
/*     */   public static final int TRAVEL = 127;
/*     */   public static final int ASTRONOMY = 128;
/*     */   public static final int SPACE = 129;
/*     */   public static final int CLOTHING = 130;
/*     */   public static final int PARTIES = 131;
/*     */   public static final int WOMEN = 132;
/*     */   public static final int SOCIAL_SCIENCE = 133;
/*     */   public static final int L60S = 134;
/*     */   public static final int L70S = 135;
/*     */   public static final int L80S = 136;
/*     */   public static final int L50S = 137;
/*     */   public static final int FINANCE_AND_CORPORATE = 138;
/*     */   public static final int ENTERTAINMENT = 139;
/*     */   public static final int CONSUMER_ELECTRONICS = 140;
/*     */   public static final int RETAIL_STORES = 141;
/*     */   public static final int HEALS_AND_BEAUTY = 142;
/*     */   public static final int MEDIA = 143;
/*     */   public static final int HOUSEHOLD_PRODUCTS = 144;
/*     */   public static final int MAIL_ORDER_CATALOG = 145;
/*     */   public static final int BUSINESS_SERVICES = 146;
/*     */   public static final int AUDIO_AND_VIRTUAL = 147;
/*     */   public static final int SPORTING_AND_ATHLETIC = 148;
/*     */   public static final int PUBLISHING = 149;
/*     */   public static final int HOME_AUTOMATION = 150;
/*  79 */   private static EnumerationsMap allInterests = new EnumerationsMap();
/*     */   private int interest;
/*     */ 
/*     */   public InterestsEnum(int interest)
/*     */   {
/* 138 */     this.interest = interest;
/*     */   }
/*     */ 
/*     */   public int getInterest() {
/* 142 */     return this.interest;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 146 */     if (allInterests.containsKey(getInterest())) {
/* 147 */       return (String)allInterests.get(getInterest());
/*     */     }
/*     */ 
/* 150 */     return "";
/*     */   }
/*     */ 
/*     */   public static Map getAllInterestsMap()
/*     */   {
/* 159 */     return allInterests;
/*     */   }
/*     */ 
/*     */   public static String[] getAllInterests()
/*     */   {
/* 167 */     return (String[])(String[])allInterests.values().toArray(new String[allInterests.size()]);
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  81 */     allInterests.put(0, "Unspecified");
/*  82 */     allInterests.put(100, "Art");
/*  83 */     allInterests.put(101, "Cars");
/*  84 */     allInterests.put(102, "Celebrity Fans");
/*  85 */     allInterests.put(103, "Collections");
/*  86 */     allInterests.put(104, "Computers");
/*  87 */     allInterests.put(105, "Culture & Literature");
/*  88 */     allInterests.put(106, "Fitness");
/*  89 */     allInterests.put(107, "Games");
/*  90 */     allInterests.put(108, "Hobbies");
/*  91 */     allInterests.put(109, "ICQ - Providing Help");
/*  92 */     allInterests.put(110, "Internet");
/*  93 */     allInterests.put(111, "Lifestyle");
/*  94 */     allInterests.put(112, "Movies/TV");
/*  95 */     allInterests.put(113, "Music");
/*  96 */     allInterests.put(114, "Outdoor Activities");
/*  97 */     allInterests.put(115, "Parenting");
/*  98 */     allInterests.put(116, "Pets/Animals");
/*  99 */     allInterests.put(117, "Religion");
/* 100 */     allInterests.put(118, "Science/Technology");
/* 101 */     allInterests.put(119, "Skills");
/* 102 */     allInterests.put(120, "Sports");
/* 103 */     allInterests.put(121, "Web Design");
/* 104 */     allInterests.put(122, "Nature and Environment");
/* 105 */     allInterests.put(123, "News & Media");
/* 106 */     allInterests.put(124, "Government");
/* 107 */     allInterests.put(125, "Business & Economy");
/* 108 */     allInterests.put(126, "Mystics");
/* 109 */     allInterests.put(127, "Travel");
/* 110 */     allInterests.put(128, "Astronomy");
/* 111 */     allInterests.put(129, "Space");
/* 112 */     allInterests.put(130, "Clothing");
/* 113 */     allInterests.put(131, "Parties");
/* 114 */     allInterests.put(132, "Women");
/* 115 */     allInterests.put(133, "Social science");
/* 116 */     allInterests.put(134, "60's");
/* 117 */     allInterests.put(135, "70's");
/* 118 */     allInterests.put(136, "80's");
/* 119 */     allInterests.put(137, "50's");
/* 120 */     allInterests.put(138, "Finance and corporate");
/* 121 */     allInterests.put(139, "Entertainment");
/* 122 */     allInterests.put(140, "Consumer electronics");
/* 123 */     allInterests.put(141, "Retail stores");
/* 124 */     allInterests.put(142, "Health and beauty");
/* 125 */     allInterests.put(143, "Media");
/* 126 */     allInterests.put(144, "Household products");
/* 127 */     allInterests.put(145, "Mail order catalog");
/* 128 */     allInterests.put(146, "Business services");
/* 129 */     allInterests.put(147, "Audio and visual");
/* 130 */     allInterests.put(148, "Sporting and athletic");
/* 131 */     allInterests.put(149, "Publishing");
/* 132 */     allInterests.put(150, "Home automation");
/*     */   }
/*     */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.setting.enumerations.InterestsEnum
 * JD-Core Version:    0.6.0
 */