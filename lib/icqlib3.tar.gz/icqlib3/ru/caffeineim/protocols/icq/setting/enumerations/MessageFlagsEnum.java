/*    */ package ru.caffeineim.protocols.icq.setting.enumerations;
/*    */ 
/*    */ public class MessageFlagsEnum
/*    */ {
/*    */   public static final int NORMAL_MESSAGE = 0;
/*    */   public static final int MULTIPLE_RECIPIENT = 80;
/*    */   public static final int AUTO_REPLY_MESSAGE_REQUEST = 3;
/*    */   private int flag;
/*    */ 
/*    */   public MessageFlagsEnum(int flag)
/*    */   {
/* 31 */     this.flag = flag;
/*    */   }
/*    */ 
/*    */   public int getFlag() {
/* 35 */     return this.flag;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 39 */     String ret = "";
/* 40 */     switch (this.flag) {
/*    */     case 0:
/* 42 */       ret = "Normal message";
/* 43 */       break;
/*    */     case 80:
/* 45 */       ret = "Multiple recipient";
/* 46 */       break;
/*    */     case 3:
/* 48 */       ret = "Auto reply message request";
/*    */     }
/*    */ 
/* 52 */     return ret;
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.setting.enumerations.MessageFlagsEnum
 * JD-Core Version:    0.6.0
 */