/*     */ package ru.caffeineim.protocols.icq.setting.enumerations;
/*     */ 
/*     */ public class XStatusModeEnum
/*     */ {
/*     */   public static final int NONE = 0;
/*     */   public static final int ANGRY = 1;
/*     */   public static final int TAKING_A_BATH = 2;
/*     */   public static final int TIRED = 3;
/*     */   public static final int PARTY = 4;
/*     */   public static final int DRINKING_BEER = 5;
/*     */   public static final int THINKING = 6;
/*     */   public static final int EATING = 7;
/*     */   public static final int WATCHING_TV = 8;
/*     */   public static final int MEETING = 9;
/*     */   public static final int COFFEE = 10;
/*     */   public static final int LISTENING_TO_MUSIC = 11;
/*     */   public static final int BUSINESS = 12;
/*     */   public static final int SHOOTING = 13;
/*     */   public static final int HAVING_FUN = 14;
/*     */   public static final int ON_THE_PHONE = 15;
/*     */   public static final int GAMING = 16;
/*     */   public static final int STUDYING = 17;
/*     */   public static final int SHOPPING = 18;
/*     */   public static final int FEELING_SICK = 19;
/*     */   public static final int SLEEPING = 20;
/*     */   public static final int SURFING = 21;
/*     */   public static final int BROWSING = 22;
/*     */   public static final int WORKING = 23;
/*     */   public static final int TYPING = 24;
/*     */   public static final int PICNIC = 25;
/*     */   public static final int COOKING = 26;
/*     */   public static final int SMOKING = 27;
/*     */   public static final int I_HIGH = 28;
/*     */   public static final int ON_WC = 29;
/*     */   public static final int QUESTION = 30;
/*     */   public static final int WATCHING_PRO7 = 31;
/*     */   public static final int LOVE = 32;
/*     */   public static final int GOOGLE = 33;
/*     */   public static final int NOTEPAD = 34;
/*  63 */   public static final XStatusModeEnum[] AVAILABLE_X_STATUSES = { new XStatusModeEnum(0), new XStatusModeEnum(1), new XStatusModeEnum(2), new XStatusModeEnum(3), new XStatusModeEnum(4), new XStatusModeEnum(5), new XStatusModeEnum(6), new XStatusModeEnum(7), new XStatusModeEnum(8), new XStatusModeEnum(9), new XStatusModeEnum(10), new XStatusModeEnum(11), new XStatusModeEnum(12), new XStatusModeEnum(13), new XStatusModeEnum(14), new XStatusModeEnum(15), new XStatusModeEnum(16), new XStatusModeEnum(17), new XStatusModeEnum(18), new XStatusModeEnum(19), new XStatusModeEnum(20), new XStatusModeEnum(21), new XStatusModeEnum(22), new XStatusModeEnum(23), new XStatusModeEnum(24), new XStatusModeEnum(25), new XStatusModeEnum(26), new XStatusModeEnum(27), new XStatusModeEnum(28), new XStatusModeEnum(29), new XStatusModeEnum(30), new XStatusModeEnum(31), new XStatusModeEnum(32), new XStatusModeEnum(33), new XStatusModeEnum(34) };
/*     */ 
/* 100 */   private byte[][] statusMatrix = { { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }, { 1, -40, -41, -18, -84, 59, 73, 42, -91, -115, -45, -40, 119, -26, 107, -110 }, { 90, 88, 30, -95, -27, -128, 67, 12, -96, 111, 97, 34, -104, -73, -28, -57 }, { -125, -55, -73, -114, 119, -25, 67, 120, -78, -59, -5, 108, -4, -61, 91, -20 }, { -26, 1, -28, 28, 51, 115, 75, -47, -68, 6, -127, 29, 108, 50, 61, -127 }, { -116, 80, -37, -82, -127, -19, 71, -122, -84, -54, 22, -52, 50, 19, -57, -73 }, { 63, -80, -67, 54, -81, 59, 74, 96, -98, -17, -49, 25, 15, 106, 90, 127 }, { -8, -24, -41, -78, -126, -60, 65, 66, -112, -8, 16, -58, -50, 10, -119, -90 }, { -128, 83, 125, -30, -92, 103, 74, 118, -77, 84, 109, -3, 7, 95, 94, -58 }, { -15, -118, -75, 46, -36, 87, 73, 29, -103, -36, 100, 68, 80, 36, 87, -81 }, { 27, 120, -82, 49, -6, 11, 77, 56, -109, -47, -103, 126, -18, -81, -78, 24 }, { 97, -66, -32, -35, -117, -35, 71, 93, -115, -18, 95, 75, -86, -49, 25, -89 }, { 72, -114, 20, -119, -118, -54, 74, 8, -126, -86, 119, -50, 122, 22, 82, 8 }, { 16, 122, -102, 24, 18, 50, 77, -92, -74, -51, 8, 121, -37, 120, 15, 9 }, { 111, 73, 48, -104, 79, 124, 74, -1, -94, 118, 52, -96, 59, -50, -82, -89 }, { 18, -110, -27, 80, 27, 100, 79, 102, -78, 6, -78, -102, -13, 120, -28, -115 }, { -44, -90, 17, -48, -113, 1, 78, -64, -110, 35, -59, -74, -66, -58, -52, -16 }, { 96, -99, 82, -8, -94, -102, 73, -90, -78, -96, 37, 36, -59, -23, -46, 96 }, { 99, 98, 115, 55, -96, 63, 73, -1, -128, -27, -9, 9, -51, -32, -92, -18 }, { 31, 122, 64, 113, -65, 59, 78, 96, -68, 50, 76, 87, -121, -80, 76, -15 }, { 120, 94, -116, 72, 64, -45, 76, 101, -120, 111, 4, -49, 63, 63, 67, -33 }, { -90, -19, 85, 126, 107, -9, 68, -44, -91, -44, -46, -25, -39, 92, -24, 31 }, { 18, -48, 126, 62, -8, -123, 72, -98, -114, -105, -89, 42, 101, 81, -27, -115 }, { -70, 116, -37, 62, -98, 36, 67, 75, -121, -74, 47, 107, -115, -2, -27, 15 }, { 99, 79, 107, -40, -83, -46, 74, -95, -86, -71, 17, 91, -62, 109, 5, -95 }, { 44, -32, -28, -27, 124, 100, 67, 112, -100, 58, 122, 28, -24, 120, -89, -36 }, { 16, 17, 23, -55, -93, -80, 64, -7, -127, -84, 73, -31, 89, -5, -43, -44 }, { 22, 12, 96, -69, -35, 68, 67, -13, -111, 64, 5, 15, 0, -26, -64, 9 }, { 100, 67, -58, -81, 34, 96, 69, 23, -75, -116, -41, -33, -114, 41, 3, 82 }, { 22, -11, -73, 111, -87, -46, 64, 53, -116, -59, -64, -124, 112, 60, -104, -6 }, { 99, 20, 54, -1, 63, -118, 64, -48, -91, -53, 123, 102, -32, 81, -77, 100 }, { -73, 8, 103, -11, 56, 37, 67, 39, -95, -1, -49, 76, -63, -109, -105, -105 }, { -35, -49, 14, -87, 113, -107, 64, 72, -87, -58, 65, 50, 6, -42, -14, -128 }, { -44, -30, -80, -70, 51, 78, 79, -91, -104, -48, 17, 125, -65, 77, 60, -56 }, { 0, 114, -39, 8, 74, -47, 67, -35, -111, -103, 111, 2, 105, 102, 2, 111 } };
/*     */   private int status;
/*     */   public static Object[] AVAILABLE_STATUSES;
/*     */ 
/*     */   public XStatusModeEnum(int status)
/*     */   {
/* 218 */     this.status = status;
/*     */   }
/*     */ 
/*     */   public int getXStatus()
/*     */   {
/* 226 */     return this.status;
/*     */   }
/*     */ 
/*     */   public byte[] getXStatusData()
/*     */   {
/* 234 */     return this.statusMatrix[this.status];
/*     */   }
/*     */ 
/*     */   public static byte[] getXStatusData(int s) {
/* 238 */     return AVAILABLE_X_STATUSES[s].getXStatusData();
/*     */   }
/*     */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.setting.enumerations.XStatusModeEnum
 * JD-Core Version:    0.6.0
 */