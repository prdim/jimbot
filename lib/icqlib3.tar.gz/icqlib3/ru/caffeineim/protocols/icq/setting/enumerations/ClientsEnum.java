/*     */ package ru.caffeineim.protocols.icq.setting.enumerations;
/*     */ 
/*     */ public class ClientsEnum
/*     */ {
/*     */   public static final byte CLI_NONE = 0;
/*     */   public static final byte CLI_QIP = 1;
/*     */   public static final byte CLI_MIRANDA = 2;
/*     */   public static final byte CLI_LICQ = 3;
/*     */   public static final byte CLI_TRILLIAN = 4;
/*     */   public static final byte CLI_SIM = 5;
/*     */   public static final byte CLI_KOPETE = 6;
/*     */   public static final byte CLI_MICQ = 7;
/*     */   public static final byte CLI_ANDRQ = 8;
/*     */   public static final byte CLI_IM2 = 9;
/*     */   public static final byte CLI_MACICQ = 10;
/*     */   public static final byte CLI_AIM = 11;
/*     */   public static final byte CLI_UIM = 12;
/*     */   public static final byte CLI_WEBICQ = 13;
/*     */   public static final byte CLI_GAIM = 14;
/*     */   public static final byte CLI_ALICQ = 15;
/*     */   public static final byte CLI_STRICQ = 16;
/*     */   public static final byte CLI_YSM = 17;
/*     */   public static final byte CLI_VICQ = 18;
/*     */   public static final byte CLI_LIBICQ2000 = 19;
/*     */   public static final byte CLI_JIMM = 20;
/*     */   public static final byte CLI_SMARTICQ = 21;
/*     */   public static final byte CLI_ICQLITE4 = 22;
/*     */   public static final byte CLI_ICQLITE5 = 23;
/*     */   public static final byte CLI_ICQ98 = 24;
/*     */   public static final byte CLI_ICQ99 = 25;
/*     */   public static final byte CLI_ICQ2001B = 26;
/*     */   public static final byte CLI_ICQ2002A2003A = 27;
/*     */   public static final byte CLI_ICQ2000 = 28;
/*     */   public static final byte CLI_ICQ2003B = 29;
/*     */   public static final byte CLI_ICQLITE = 30;
/*     */   public static final byte CLI_GNOMEICQ = 31;
/*     */   public static final byte CLI_AGILE = 32;
/*     */   public static final byte CLI_SPAM = 33;
/*     */   public static final byte CLI_CENTERICQ = 34;
/*     */   public static final byte CLI_LIBICQJABBER = 35;
/*     */   public static final byte CLI_ICQ2GO = 36;
/*     */   public static final byte CLI_ICQPPC = 37;
/*     */   public static final byte CLI_STICQ = 38;
/*     */   public static final byte CLI_MCHAT = 39;
/* 109 */   private static final String[] clientNames = { "Not detected", "QIP", "Miranda", "LIcq", "Trillian", "SIM", "Kopete", "MICQ", "&RQ", "IM2", "ICQ for MAC", "AIM", "UIM", "WebICQ", "Gaim", "Alicq", "StrICQ", "YSM", "vICQ", "Libicq2000", "Jimm", "SmartICQ", "ICQ Lite v4", "ICQ Lite v5", "ICQ 98", "ICQ 99", "ICQ 2001b", "ICQ 2002a/2003a", "ICQ 2000", "ICQ 2003b", "ICQ Lite", "Gnome ICQ", "Agile Messenger", "SPAM:)", "CenterICQ", "Libicq2000 from Jabber", "ICQ2GO!", "ICQ for Pocket PC", "StIcq", "" };
/*     */ 
/* 119 */   private int type = 0;
/*     */ 
/* 121 */   private static byte[][] clientMatrix = { { 106, 105, 109, 98, 111, 116, 32, 98, 121, 32, 66, 108, 97, 99, 107, 32, 75, 111, 74 }, { 0, -25, -32, -33, -87, -48, 79, -31, -111, 98, -56, -112, -102, 19, 42, 27 }, { 9, 73, 19, 68, 76, 127, 17, -47, -126, 34, 68, 69, 83, 84, 0, 0 }, { 16, -49, 64, -47, 76, 127, 17, -47, -126, 34, 68, 69, 83, 84, 0, 0 }, { 38, 82, 81, 105, 110, 115, 105, 100, 101 }, { 46, 122, 100, 117, -6, -33, 77, -56, -120, 111, -22, 53, -107, -3, -74, -33 }, { 65, 103, 101, 110, 116, 87, 77 }, { 67, 79, 82, 69, 32, 80, 97, 103, 101, 114, 0, 0, 0, 0, 0, 0 }, { 68, 91, 105, 93, 67, 104, 97, 116, 32 }, { 68, -27, -65, -50, -80, -106, -27, 71, -67, 101, -17, -42, -93, 126, 54, 2 }, { 71, 108, 73, 67, 81, 0 }, { 73, 77, 32, 71, 97, 116, 101, 119, 97, 121, 32 }, { 73, 77, 97, 100, 101, 114, 105, 110, 103, 32, 67, 108, 105, 101, 110, 116 }, { 74, 50, 77, 69, 32, 109, 64, 97, 103, 101, 110, 116, 0 }, { 74, 73, 67, 81 }, { 74, 73, 84 }, { 74, 105, 109, 109 }, { 75, 111, 112, 101, 116, 101, 32, 73, 67, 81, 32, 32 }, { 76, 105, 99, 113, 32, 99, 108, 105, 101, 110, 116, 32 }, { 76, 107, -112, -93, 61, 45, 72, 14, -119, -42, 46, 75, 44, 16, -39, -97 }, { 76, 111, 99, 73, 68 }, { 77, 73, 77, 47 }, { 77, 73, 80 }, { 77, 105, 114, 97, 110, 100, 97, 65 }, { 77, 105, 114, 97, 110, 100, 97, 77 }, { 77, 105, 114, 97, 110, 100, 97, 77, 111, 98, 105, 108, 101 }, { 78, 97, 116, 73, 67, 81 }, { 80, 72, 80, 67, 111, 114, 101, 32 }, { 80, 73, 71, 69, 79, 78, 33 }, { 81, -83, -47, -112, 114, 4, 71, 61, -95, -95, 73, -12, -93, -105, -92, 31 }, { 82, 38, 81, 105, 110, 115, 105, 100, 101 }, { 83, 73, 77, 32, 99, 108, 105, 101, 110, 116, 32, 32 }, { 83, 73, 77, 80, 83, 73, 77, 80, 83, 73, 77, 80, 83, 73, 77, 80 }, { 83, 73, 77, 80, 95, 80, 82, 79, 83, 73, 77, 80, 95, 80, 82, 79 }, { 83, 109, 97, 112, 101, 114, 32 }, { 86, 63, -56, 9, 11, 111, 65, 81, 73, 80, 32, 32, 32, 32, 32, 33 }, { 86, 63, -56, 9, 11, 111, 65, 81, 73, 80, 32, 32, 32, 32, 32, 34 }, { 86, 63, -56, 9, 11, 111, 65, 81, 73, 80, 32, 50, 48, 48, 53, 97 }, { 86, 109, 73, 67, 81, 32 }, { 89, 97, 112, 112 }, { 98, 97, 121, 97, 110, 73, 67, 81 }, { 99, 108, 105, 109, 109, -87, 32, 82, 46, 75, 46, 32 }, { 100, 105, 103, 115, 98, 121 }, { 105, 99, 113, 106 }, { 105, 99, 113, 106, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32 }, { 105, 99, 113, 106, 32, 83, 101, 99, 117, 114, 101, 32, 73, 77, 32, 32 }, { 105, 99, 113, 112 }, { 106, 97, 112, 112 }, { 109, 67, 104, 97, 116, 32, 105, 99, 113 }, { 109, 73, 67, 81, 32, -87, 32, 82, 46, 75, 46, 32 }, { 113, 117, 116, 105, 109 }, { 115, 105, 110, 106 }, { 116, -19, -61, 54, 68, -33, 72, 91, -117, 28, 103, 26, 31, -122, 9, -97 }, { 124, 115, 117, 2, -61, -66, 79, 62, -90, -97, 1, 83, 19, 67, 30, 26 }, { 126, 17, -73, 120, -93, 83, 73, 38, -88, 2, 68, 115, 82, 8, -60, 42 }, { -114, -51, -112, -25, 79, 24, 40, -8, 2, -20, -42, 24, -92, -23, -34, 104 }, { -105, -79, 39, 81, 36, 60, 67, 52, -83, 34, -42, -85, -9, 63, 20, 0 }, { -105, -79, 39, 81, 36, 60, 67, 52, -83, 34, -42, -85, -9, 63, 20, 9 }, { -96, -23, 63, 55, 76, 127, 17, -47, -126, 34, 68, 69, 83, 84, 0, 0 }, { -96, -23, 63, 55, 79, -23, -45, 17, -68, -46, 0, 4, -84, -106, -35, -106 }, { -89, -28, 10, -106, -77, -96, 71, -102, -72, 69, -55, -28, 103, -59, 107, 31 }, { -35, 22, -14, 2, -124, -26, 17, -44, -112, -37, 0, 16, 75, -101, 75, 125 }, { -1, -1, -1, -1, 110, 97, 105, 109 }, { 83, 105, 109, 112, 108, 101, 73, 77 }, { 9, 70, 15, 7, 76, 127, 17, -47, -126, 34, 68, 69, 83, 84, 0, 0 }, { 9, 70, 15, 8, 76, 127, 17, -47, -126, 34, 68, 69, 83, 84, 0, 0 }, { 9, 70, -32, 0, 76, 127, 17, -47, -126, 34, 68, 69, 83, 84, 0, 0 } };
/*     */ 
/* 209 */   private int caps = 0;
/*     */ 
/*     */   public static byte[] getClientData(int client)
/*     */   {
/* 206 */     return clientMatrix[client];
/*     */   }
/*     */ 
/*     */   public ClientsEnum(int type, int caps)
/*     */   {
/* 212 */     this.type = type;
/* 213 */     this.caps = caps;
/*     */   }
/*     */ 
/*     */   public int getType() {
/* 217 */     return this.type;
/*     */   }
/*     */ 
/*     */   public void setType(int type) {
/* 221 */     this.type = type;
/*     */   }
/*     */ 
/*     */   public int getCaps() {
/* 225 */     return this.caps;
/*     */   }
/*     */ 
/*     */   public void setCaps(int caps) {
/* 229 */     this.caps = caps;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 233 */     return clientNames[this.type];
/*     */   }
/*     */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.setting.enumerations.ClientsEnum
 * JD-Core Version:    0.6.0
 */