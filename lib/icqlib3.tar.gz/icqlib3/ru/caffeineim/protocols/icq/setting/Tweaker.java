/*     */ package ru.caffeineim.protocols.icq.setting;
/*     */ 
/*     */ import java.util.TreeMap;
/*     */ import ru.caffeineim.protocols.icq.setting.enumerations.StatusFlagEnum;
/*     */ import ru.caffeineim.protocols.icq.setting.enumerations.StatusModeEnum;
/*     */ import ru.caffeineim.protocols.icq.setting.enumerations.TcpConnectionFlagEnum;
/*     */ 
/*     */ public class Tweaker
/*     */ {
/*  31 */   private static final Integer INITIAL_STATUS_MODE = new Integer(511);
/*  32 */   private static final Integer INITIAL_STATUS_FLAGS = new Integer(767);
/*  33 */   private static final Integer TCP_CONNECTION_FLAG = new Integer(1023);
/*  34 */   private static final Integer P2P_PORT_LISTENING = new Integer(1279);
/*  35 */   private static final Integer REQUEST_FREE_FOR_CHAT_MESSAGE = new Integer(236);
/*     */ 
/*  37 */   private static final Integer REQUEST_DND_MESSAGE = new Integer(235);
/*     */ 
/*  39 */   private static final Integer REQUEST_OCCUPIED_MESSAGE = new Integer(233);
/*     */ 
/*  41 */   private static final Integer REQUEST_NA_MESSAGE = new Integer(234);
/*     */ 
/*  43 */   private static final Integer REQUEST_AWAY_MASSEGE = new Integer(232);
/*     */   private TreeMap map;
/*     */ 
/*     */   public Tweaker()
/*     */   {
/*  49 */     this.map = new TreeMap();
/*  50 */     this.map.put(INITIAL_STATUS_MODE, new StatusModeEnum(0));
/*  51 */     this.map.put(INITIAL_STATUS_FLAGS, new StatusFlagEnum(268435456, false, false, false));
/*     */ 
/*  53 */     this.map.put(TCP_CONNECTION_FLAG, new TcpConnectionFlagEnum(4));
/*     */ 
/*  55 */     this.map.put(P2P_PORT_LISTENING, new Integer(5000));
/*     */   }
/*     */ 
/*     */   public StatusFlagEnum getInitialStatusFlags() {
/*  59 */     return (StatusFlagEnum)this.map.get(INITIAL_STATUS_FLAGS);
/*     */   }
/*     */ 
/*     */   public void setInitialStatusFlags(StatusFlagEnum flags) {
/*  63 */     this.map.put(INITIAL_STATUS_FLAGS, flags);
/*     */   }
/*     */ 
/*     */   public StatusModeEnum getInitialStatusMode() {
/*  67 */     return (StatusModeEnum)this.map.get(INITIAL_STATUS_MODE);
/*     */   }
/*     */ 
/*     */   public void setInitialStatusMode(StatusModeEnum mode) {
/*  71 */     this.map.put(INITIAL_STATUS_MODE, mode);
/*     */   }
/*     */ 
/*     */   public TcpConnectionFlagEnum getTcpConnectionFlag() {
/*  75 */     return (TcpConnectionFlagEnum)this.map.get(TCP_CONNECTION_FLAG);
/*     */   }
/*     */ 
/*     */   public void setTcpConnectionFlag(TcpConnectionFlagEnum flag) {
/*  79 */     this.map.put(TCP_CONNECTION_FLAG, flag);
/*     */   }
/*     */ 
/*     */   public int getP2PPortListening() {
/*  83 */     return ((Integer)this.map.get(P2P_PORT_LISTENING)).intValue();
/*     */   }
/*     */ 
/*     */   public void setP2PPortListening(int port) {
/*  87 */     this.map.put(P2P_PORT_LISTENING, new Integer(port));
/*     */   }
/*     */ 
/*     */   public String getRequestMessage(int modeRequest) {
/*  91 */     String stored = (String)this.map.get(new Integer(modeRequest));
/*  92 */     if (stored != null) {
/*  93 */       return "" + stored;
/*     */     }
/*     */ 
/*  96 */     return "";
/*     */   }
/*     */ 
/*     */   public void setFreeForChatRequestMessage(String message)
/*     */   {
/* 101 */     this.map.put(REQUEST_FREE_FOR_CHAT_MESSAGE, new Integer(message));
/*     */   }
/*     */ 
/*     */   public void setDNDRequestMessage(String message) {
/* 105 */     this.map.put(REQUEST_DND_MESSAGE, new Integer(message));
/*     */   }
/*     */ 
/*     */   public void setOccupiedRequestMessage(String message) {
/* 109 */     this.map.put(REQUEST_OCCUPIED_MESSAGE, new Integer(message));
/*     */   }
/*     */ 
/*     */   public void setNARequestMessage(String message) {
/* 113 */     this.map.put(REQUEST_NA_MESSAGE, new Integer(message));
/*     */   }
/*     */ 
/*     */   public void setAwayRequestMessage(String message) {
/* 117 */     this.map.put(REQUEST_AWAY_MASSEGE, new Integer(message));
/*     */   }
/*     */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.setting.Tweaker
 * JD-Core Version:    0.6.0
 */