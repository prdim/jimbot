/*    */ package ru.caffeineim.protocols.icq.setting.enumerations;
/*    */ 
/*    */ public class StatusModeEnum
/*    */ {
/*    */   public static final int ONLINE = 0;
/*    */   public static final int AWAY = 1;
/*    */   public static final int DND = 2;
/*    */   public static final int NA = 4;
/*    */   public static final int OCCUPIED = 16;
/*    */   public static final int FREE_FOR_CHAT = 32;
/*    */   public static final int OFFLINE = 255;
/*    */   public static final int INVISIBLE = 256;
/*    */   public static final int LUNCH = 8193;
/*    */   public static final int EVIL = 12288;
/*    */   public static final int DEPRESSION = 16384;
/*    */   public static final int HOME = 20480;
/*    */   public static final int WORK = 24576;
/* 42 */   public static final StatusModeEnum[] AVAILABLE_STATUSES = { new StatusModeEnum(0), new StatusModeEnum(8193), new StatusModeEnum(12288), new StatusModeEnum(16384), new StatusModeEnum(20480), new StatusModeEnum(24576), new StatusModeEnum(1), new StatusModeEnum(4), new StatusModeEnum(16), new StatusModeEnum(2), new StatusModeEnum(32), new StatusModeEnum(256), new StatusModeEnum(255) };
/*    */   private int status;
/*    */ 
/*    */   public StatusModeEnum(int status)
/*    */   {
/* 61 */     this.status = status;
/*    */   }
/*    */ 
/*    */   public int getMode() {
/* 65 */     return this.status;
/*    */   }
/*    */ 
/*    */   public static int Mode(int s) {
/* 69 */     return AVAILABLE_STATUSES[s].getMode();
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.setting.enumerations.StatusModeEnum
 * JD-Core Version:    0.6.0
 */