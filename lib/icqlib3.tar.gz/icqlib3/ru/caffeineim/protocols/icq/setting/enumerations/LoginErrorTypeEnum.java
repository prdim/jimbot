/*    */ package ru.caffeineim.protocols.icq.setting.enumerations;
/*    */ 
/*    */ public class LoginErrorTypeEnum
/*    */ {
/*    */   public static final int UNKNOWN_ERROR = 0;
/*    */   public static final int BAD_UIN_ERROR = 1;
/*    */   public static final int PASSWORD_ERROR = 2;
/*    */   public static final int NOT_EXISTS_ERROR = 3;
/*    */   public static final int LIMIT_EXCEEDED_ERROR = 4;
/*    */   public static final int MAXIMUM_USERS_IP_ERROR = 5;
/*    */   public static final int OLDER_ICQ_VERSION_ERROR = 6;
/*    */   public static final int CANT_REGISTER_ERROR = 7;
/*    */   private int error;
/*    */ 
/*    */   public LoginErrorTypeEnum(int error)
/*    */   {
/* 36 */     this.error = error;
/*    */   }
/*    */ 
/*    */   public int getError() {
/* 40 */     return this.error;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 44 */     String ret = "";
/* 45 */     switch (this.error) {
/*    */     case 0:
/* 47 */       ret = "Unknown Error";
/* 48 */       break;
/*    */     case 1:
/* 50 */       ret = "Bad UIN.";
/* 51 */       break;
/*    */     case 2:
/* 53 */       ret = "Password incorrect.";
/* 54 */       break;
/*    */     case 3:
/* 56 */       ret = "This ICQ number does not exist.";
/* 57 */       break;
/*    */     case 5:
/* 59 */       ret = "The amount of users connected from this IP has reached the maximum.";
/* 60 */       break;
/*    */     case 4:
/* 62 */       ret = "Rate limit exceeded. Please try to reconnect in a few minutes.";
/* 63 */       break;
/*    */     case 6:
/* 65 */       ret = "You are using an older version of ICQ. Please upgrade.";
/* 66 */       break;
/*    */     case 7:
/* 68 */       ret = "Can't register on the ICQ network. Reconnect in a few minutes.";
/*    */     }
/*    */ 
/* 72 */     return ret;
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.setting.enumerations.LoginErrorTypeEnum
 * JD-Core Version:    0.6.0
 */