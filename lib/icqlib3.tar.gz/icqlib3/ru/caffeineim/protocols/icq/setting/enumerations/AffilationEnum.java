/*     */ package ru.caffeineim.protocols.icq.setting.enumerations;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class AffilationEnum
/*     */ {
/*     */   public static final int UNSPECIFIED = 0;
/*     */   public static final int ALUMNI = 200;
/*     */   public static final int CHARITY = 201;
/*     */   public static final int CLUB_SOCIAL = 202;
/*     */   public static final int COMMUNITY = 203;
/*     */   public static final int CULTURAL = 204;
/*     */   public static final int FAN_CLUBS = 205;
/*     */   public static final int FRATERNITY = 206;
/*     */   public static final int HOBBYISTS = 207;
/*     */   public static final int INTERNATIONAL = 208;
/*     */   public static final int NATURE_AND_ENVIRONMENT = 209;
/*     */   public static final int PROFESSIONAL = 210;
/*     */   public static final int SCIENTIFIC = 211;
/*     */   public static final int SELF_IMPROVEMENT = 212;
/*     */   public static final int SPIRITUAL = 213;
/*     */   public static final int SPORTS = 214;
/*     */   public static final int SUPPORT = 215;
/*     */   public static final int TRADE_AND_BUSINESS = 216;
/*     */   public static final int UNION = 217;
/*     */   public static final int VOLUNTEER = 218;
/*     */   public static final int OTHER = 299;
/*  48 */   private static EnumerationsMap allAffiliations = new EnumerationsMap();
/*     */   private int affiliation;
/*     */ 
/*     */   public AffilationEnum(int affiliation)
/*     */   {
/*  76 */     this.affiliation = affiliation;
/*     */   }
/*     */ 
/*     */   public int getAffiliation() {
/*  80 */     return this.affiliation;
/*     */   }
/*     */ 
/*     */   public String toString() {
/*  84 */     if (allAffiliations.containsKey(getAffiliation())) {
/*  85 */       return (String)allAffiliations.get(getAffiliation());
/*     */     }
/*     */ 
/*  88 */     return "";
/*     */   }
/*     */ 
/*     */   public static Map getAllAffiliationsMap()
/*     */   {
/*  97 */     return allAffiliations;
/*     */   }
/*     */ 
/*     */   public static String[] getAllAffiliations()
/*     */   {
/* 105 */     return (String[])(String[])allAffiliations.values().toArray(new String[allAffiliations.size()]);
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  50 */     allAffiliations.put(0, "Unspecified");
/*  51 */     allAffiliations.put(200, "Alumni Org.");
/*  52 */     allAffiliations.put(201, "Charity Org.");
/*  53 */     allAffiliations.put(202, "Club/Social Org.");
/*  54 */     allAffiliations.put(203, "Community Org.");
/*  55 */     allAffiliations.put(204, "Cultural Org.");
/*  56 */     allAffiliations.put(205, "Fan Clubs");
/*  57 */     allAffiliations.put(206, "Fraternity/Sorority");
/*  58 */     allAffiliations.put(207, "Hobbyists Org.");
/*  59 */     allAffiliations.put(208, "International Org.");
/*  60 */     allAffiliations.put(209, "Nature and Environment Org.");
/*  61 */     allAffiliations.put(210, "Professional Org.");
/*  62 */     allAffiliations.put(211, "Scientific/Technical Org.");
/*  63 */     allAffiliations.put(212, "Self Improvement Group");
/*  64 */     allAffiliations.put(213, "Spiritual/Religious Org.");
/*  65 */     allAffiliations.put(214, "Sports Org.");
/*  66 */     allAffiliations.put(215, "Support Org.");
/*  67 */     allAffiliations.put(216, "Trade and Business Org.");
/*  68 */     allAffiliations.put(217, "Union");
/*  69 */     allAffiliations.put(218, "Volunteer Org.");
/*  70 */     allAffiliations.put(299, "Other");
/*     */   }
/*     */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.setting.enumerations.AffilationEnum
 * JD-Core Version:    0.6.0
 */