/*    */ package ru.caffeineim.protocols.icq.setting.enumerations;
/*    */ 
/*    */ public class StatusFlagEnum
/*    */ {
/*    */   public static final int DIRECT_CONNECTION_ALLOWED = 0;
/*    */   public static final int DIRECT_CONNECTION_AUTHORIZATION = 268435456;
/*    */   public static final int DIRECT_CONNECTION_CONTACT = 536870928;
/*    */   public static final int WEBAWARE = 65536;
/*    */   public static final int SHOW_IP = 131072;
/*    */   public static final int BIRTHDAY = 524288;
/*    */   private int flag;
/*    */ 
/*    */   public StatusFlagEnum(int flag, boolean showIp, boolean webAware, boolean birthday)
/*    */   {
/* 34 */     this.flag = flag;
/* 35 */     if (showIp) {
/* 36 */       this.flag |= 131072;
/*    */     }
/* 38 */     if (webAware) {
/* 39 */       this.flag |= 65536;
/*    */     }
/* 41 */     if (birthday)
/* 42 */       this.flag |= 524288;
/*    */   }
/*    */ 
/*    */   public StatusFlagEnum(int flag)
/*    */   {
/* 47 */     this.flag = flag;
/*    */   }
/*    */ 
/*    */   public int getFlag() {
/* 51 */     return this.flag;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 55 */     String ret = "";
/*    */ 
/* 57 */     if (this.flag < 1245184) {
/* 58 */       ret = "Direct connection allowed";
/*    */     }
/* 60 */     else if ((this.flag & 0x10000000) == 268435456)
/*    */     {
/* 62 */       ret = "Direct connection authorization";
/*    */     }
/* 64 */     else if ((this.flag & 0x20000010) == 536870928) {
/* 65 */       ret = "Direct connection contact";
/*    */     }
/* 67 */     if ((this.flag & 0x20000) == 131072) {
/* 68 */       ret = ret + " show ip";
/*    */     }
/* 70 */     if ((this.flag & 0x10000) == 65536) {
/* 71 */       ret = ret + " webaware";
/*    */     }
/* 73 */     if ((this.flag & 0x80000) == 524288) {
/* 74 */       ret = ret + " birthday";
/*    */     }
/*    */ 
/* 77 */     return ret;
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.setting.enumerations.StatusFlagEnum
 * JD-Core Version:    0.6.0
 */