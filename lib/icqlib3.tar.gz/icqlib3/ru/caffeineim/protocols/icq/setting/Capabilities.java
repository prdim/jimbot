/*     */ package ru.caffeineim.protocols.icq.setting;
/*     */ 
/*     */ import ru.caffeineim.protocols.icq.setting.enumerations.ClientsEnum;
/*     */ import ru.caffeineim.protocols.icq.tool.BytesTools;
/*     */ 
/*     */ public class Capabilities
/*     */ {
/*     */   public static final int CAPF_NO_INTERNAL = 0;
/*     */   public static final int CAPF_AIM_SERVERRELAY_INTERNAL = 1;
/*     */   public static final int CAPF_UTF8_INTERNAL = 2;
/*     */   public static final int CAPF_MIRANDAIM = 4;
/*     */   public static final int CAPF_TRILLIAN = 8;
/*     */   public static final int CAPF_TRILCRYPT = 16;
/*     */   public static final int CAPF_SIM = 32;
/*     */   public static final int CAPF_SIMOLD = 64;
/*     */   public static final int CAPF_LICQ = 128;
/*     */   public static final int CAPF_KOPETE = 256;
/*     */   public static final int CAPF_MICQ = 512;
/*     */   public static final int CAPF_ANDRQ = 1024;
/*     */   public static final int CAPF_QIP = 2048;
/*     */   public static final int CAPF_IM2 = 4096;
/*     */   public static final int CAPF_MACICQ = 8192;
/*     */   public static final int CAPF_RICHTEXT = 16384;
/*     */   public static final int CAPF_IS2001 = 32768;
/*     */   public static final int CAPF_IS2002 = 65536;
/*     */   public static final int CAPF_STR20012 = 131072;
/*     */   public static final int CAPF_AIMICON = 262144;
/*     */   public static final int CAPF_AIMCHAT = 524288;
/*     */   public static final int CAPF_UIM = 1048576;
/*     */   public static final int CAPF_RAMBLER = 2097152;
/*     */   public static final int CAPF_ABV = 4194304;
/*     */   public static final int CAPF_NETVIGATOR = 8388608;
/*     */   public static final int CAPF_XTRAZ = 16777216;
/*     */   public static final int CAPF_AIMFILE = 33554432;
/*     */   public static final int CAPF_JIMM = 67108864;
/*     */   public static final int CAPF_AIMIMIMAGE = 134217728;
/*     */   public static final int CAPF_AVATAR = 268435456;
/*     */   public static final int CAPF_DIRECT = 536870912;
/*     */   public static final int CAPF_TYPING = 1073741824;
/*     */   public static final int CAPF_MCHAT = -2147483648;
/* 105 */   private static final byte[] CAP_OLD_HEAD = { 9, 70 };
/*     */ 
/* 107 */   private static final byte[] CAP_OLD_TAIL = { 76, 127, 17, -47, -126, 34, 68, 69, 83, 84, 0, 0 };
/*     */ 
/* 111 */   public static final byte[] CAP_AIM_SERVERRELAY = { 9, 70, 19, 73, 76, 127, 17, -47, -126, 34, 68, 69, 83, 84, 0, 0 };
/*     */ 
/* 116 */   public static final byte[] CAP_UTF8 = { 9, 70, 19, 78, 76, 127, 17, -47, -126, 34, 68, 69, 83, 84, 0, 0 };
/*     */ 
/* 121 */   public static final byte[] CAP_UTF8_GUID = { 123, 48, 57, 52, 54, 49, 51, 52, 69, 45, 52, 67, 55, 70, 45, 49, 49, 68, 49, 45, 56, 50, 50, 50, 45, 52, 52, 52, 53, 53, 51, 53, 52, 48, 48, 48, 48, 125 };
/*     */ 
/* 131 */   private static final byte[] CAP_MIRANDAIM = { 77, 105, 114, 97, 110, 100, 97, 77, 0, 0, 0, 0, 0, 0, 0, 0 };
/*     */ 
/* 136 */   private static final byte[] CAP_TRILLIAN = { -105, -79, 39, 81, 36, 60, 67, 52, -83, 34, -42, -85, -9, 63, 20, 9 };
/*     */ 
/* 141 */   private static final byte[] CAP_TRILCRYPT = { -14, -25, -57, -12, -2, -83, 77, -5, -78, 53, 54, 121, -117, -33, 0, 0 };
/*     */ 
/* 146 */   private static final byte[] CAP_SIM = { 83, 73, 77, 32, 99, 108, 105, 101, 110, 116, 32, 32, 0, 0, 0, 0 };
/*     */ 
/* 149 */   private static final byte[] CAP_SIMOLD = { -105, -79, 39, 81, 36, 60, 67, 52, -83, 34, -42, -85, -9, 63, 20, 0 };
/*     */ 
/* 154 */   private static final byte[] CAP_LICQ = { 76, 105, 99, 113, 32, 99, 108, 105, 101, 110, 116, 32, 0, 0, 0, 0 };
/*     */ 
/* 157 */   private static final byte[] CAP_KOPETE = { 75, 111, 112, 101, 116, 101, 32, 73, 67, 81, 32, 32, 0, 0, 0, 0 };
/*     */ 
/* 161 */   private static final byte[] CAP_MICQ = { 109, 73, 67, 81, 32, -87, 32, 82, 46, 75, 46, 32, 0, 0, 0, 0 };
/*     */ 
/* 165 */   private static final byte[] CAP_ANDRQ = { 38, 82, 81, 105, 110, 115, 105, 100, 101, 0, 0, 0, 0, 0, 0, 0 };
/*     */ 
/* 169 */   private static final byte[] CAP_QIP = { 86, 63, -56, 9, 11, 111, 65, 81, 73, 80, 32, 50, 48, 48, 53, 97 };
/*     */ 
/* 173 */   private static final byte[] CAP_IM2 = { 116, -19, -61, 54, 68, -33, 72, 91, -117, 28, 103, 26, 31, -122, 9, -97 };
/*     */ 
/* 178 */   private static final byte[] CAP_MACICQ = { -35, 22, -14, 2, -124, -26, 17, -44, -112, -37, 0, 16, 75, -101, 75, 125 };
/*     */ 
/* 183 */   private static final byte[] CAP_RICHTEXT = { -105, -79, 39, 81, 36, 60, 67, 52, -83, 34, -42, -85, -9, 63, 20, -110 };
/*     */ 
/* 188 */   private static final byte[] CAP_IS2001 = { 46, 122, 100, 117, -6, -33, 77, -56, -120, 111, -22, 53, -107, -3, -74, -33 };
/*     */ 
/* 193 */   private static final byte[] CAP_IS2002 = { 16, -49, 64, -47, 76, 127, 17, -47, -126, 34, 68, 69, 83, 84, 0, 0 };
/*     */ 
/* 198 */   private static final byte[] CAP_STR20012 = { -96, -23, 63, 55, 79, -23, -45, 17, -68, -46, 0, 4, -84, -106, -35, -106 };
/*     */ 
/* 203 */   private static final byte[] CAP_AIMICON = { 9, 70, 19, 70, 76, 127, 17, -47, -126, 34, 68, 69, 83, 84, 0, 0 };
/*     */ 
/* 208 */   private static final byte[] CAP_AIMIMIMAGE = { 9, 70, 19, 69, 76, 127, 17, -47, -126, 34, 68, 69, 83, 84, 0, 0 };
/*     */ 
/* 213 */   private static final byte[] CAP_AIMCHAT = { 116, -113, 36, 32, 98, -121, 17, -47, -126, 34, 68, 69, 83, 84, 0, 0 };
/*     */ 
/* 218 */   private static final byte[] CAP_UIM = { -89, -28, 10, -106, -77, -96, 71, -102, -72, 69, -55, -28, 103, -59, 107, 31 };
/*     */ 
/* 223 */   private static final byte[] CAP_RAMBLER = { 126, 17, -73, 120, -93, 83, 73, 38, -88, 2, 68, 115, 82, 8, -60, 42 };
/*     */ 
/* 228 */   private static final byte[] CAP_ABV = { 0, -25, -32, -33, -87, -48, 79, -31, -111, 98, -56, -112, -102, 19, 42, 27 };
/*     */ 
/* 233 */   private static final byte[] CAP_NETVIGATOR = { 76, 107, -112, -93, 61, 45, 72, 14, -119, -42, 46, 75, 44, 16, -39, -97 };
/*     */ 
/* 238 */   private static final byte[] CAP_XTRAZ = { 26, 9, 60, 108, -41, -3, 78, -59, -99, 81, -90, 71, 78, 52, -11, -96 };
/*     */ 
/* 243 */   private static final byte[] CAP_AIMFILE = { 9, 70, 19, 67, 76, 127, 17, -47, -126, 34, 68, 69, 83, 84, 0, 0 };
/*     */ 
/* 248 */   private static final byte[] CAP_DIRECT = { 9, 70, 19, 68, 76, 127, 17, -47, -126, 34, 68, 69, 83, 84, 0, 0 };
/*     */ 
/* 253 */   private static final byte[] CAP_JIMM = { 74, 105, 109, 109, 32 };
/*     */ 
/* 255 */   private static final byte[] CAP_AVATAR = { 9, 70, 19, 76, 76, 127, 17, -47, -126, 34, 68, 69, 83, 84, 0, 0 };
/*     */ 
/* 260 */   private static final byte[] CAP_TYPING = { 86, 63, -56, 9, 11, 111, 65, -67, -97, 121, 66, 38, 9, -33, -94, -13 };
/*     */ 
/* 265 */   private static final byte[] CAP_MCHAT = { 109, 67, 104, 97, 116, 32, 105, 99, 113 };
/*     */ 
/*     */   public static byte[] mergeCapabilities(byte[] capabilities_old, byte[] capabilities_new)
/*     */   {
/* 277 */     if (capabilities_new == null) {
/* 278 */       return capabilities_old;
/*     */     }
/* 280 */     if (capabilities_old == null) {
/* 281 */       return capabilities_new;
/*     */     }
/*     */ 
/* 284 */     byte[] extended_new = new byte[capabilities_new.length * 8];
/* 285 */     for (int i = 0; i < capabilities_new.length; i += 2) {
/* 286 */       System.arraycopy(CAP_OLD_HEAD, 0, extended_new, i * 8, CAP_OLD_HEAD.length);
/*     */ 
/* 288 */       System.arraycopy(capabilities_new, i, extended_new, i * 8 + CAP_OLD_HEAD.length, 2);
/*     */ 
/* 290 */       System.arraycopy(CAP_OLD_TAIL, 0, extended_new, i * 8 + CAP_OLD_HEAD.length + 2, CAP_OLD_TAIL.length);
/*     */     }
/*     */ 
/* 295 */     boolean found = false;
/* 296 */     for (int i = 4; i < capabilities_old.length; i += 16) {
/* 297 */       byte[] tmp_old = new byte[16];
/* 298 */       System.arraycopy(capabilities_old, i, tmp_old, 0, 16);
/* 299 */       for (int j = 0; j < extended_new.length; j += 16) {
/* 300 */         byte[] tmp_new = new byte[16];
/* 301 */         System.arraycopy(extended_new, j, tmp_new, 0, 16);
/* 302 */         if (tmp_old == tmp_new) {
/* 303 */           found = true;
/* 304 */           break;
/*     */         }
/*     */       }
/*     */ 
/* 308 */       if (!found) {
/* 309 */         byte[] merged = new byte[extended_new.length + 16];
/* 310 */         System.arraycopy(extended_new, 0, merged, 0, extended_new.length);
/*     */ 
/* 312 */         System.arraycopy(tmp_old, 0, merged, extended_new.length, tmp_old.length);
/*     */ 
/* 314 */         extended_new = merged;
/* 315 */         found = false;
/*     */       }
/*     */     }
/*     */ 
/* 319 */     return extended_new;
/*     */   }
/*     */ 
/*     */   public static ClientsEnum detectUserClient(int dwFP1, int dwFP2, int dwFP3, byte[] capabilities, int wVersion)
/*     */   {
/* 325 */     int client = 0;
/* 326 */     String szVersion = "";
/* 327 */     int caps = 0;
/*     */ 
/* 329 */     if (capabilities != null)
/*     */     {
/* 331 */       for (int j = 0; j < capabilities.length / 16; j++) {
/* 332 */         if (BytesTools.byteArrayEquals(capabilities, j * 16, CAP_AIM_SERVERRELAY, 0, 16))
/*     */         {
/* 334 */           caps |= 1;
/* 335 */         } else if (BytesTools.byteArrayEquals(capabilities, j * 16, CAP_UTF8, 0, 16))
/*     */         {
/* 337 */           caps |= 2;
/* 338 */         } else if (BytesTools.byteArrayEquals(capabilities, j * 16, CAP_MIRANDAIM, 0, 8))
/*     */         {
/* 340 */           caps |= 4;
/* 341 */         } else if (BytesTools.byteArrayEquals(capabilities, j * 16, CAP_TRILLIAN, 0, 16))
/*     */         {
/* 343 */           caps |= 8;
/* 344 */         } else if (BytesTools.byteArrayEquals(capabilities, j * 16, CAP_TRILCRYPT, 0, 16))
/*     */         {
/* 346 */           caps |= 16;
/* 347 */         } else if (BytesTools.byteArrayEquals(capabilities, j * 16, CAP_SIM, 0, 12))
/*     */         {
/* 349 */           caps |= 32;
/* 350 */         } else if (BytesTools.byteArrayEquals(capabilities, j * 16, CAP_SIMOLD, 0, 16))
/*     */         {
/* 352 */           caps |= 64;
/* 353 */         } else if (BytesTools.byteArrayEquals(capabilities, j * 16, CAP_LICQ, 0, 12))
/*     */         {
/* 355 */           caps |= 128;
/* 356 */         } else if (BytesTools.byteArrayEquals(capabilities, j * 16, CAP_KOPETE, 0, 12))
/*     */         {
/* 358 */           caps |= 256;
/* 359 */         } else if (BytesTools.byteArrayEquals(capabilities, j * 16, CAP_MICQ, 0, 16))
/*     */         {
/* 361 */           caps |= 512;
/* 362 */         } else if (BytesTools.byteArrayEquals(capabilities, j * 16, CAP_ANDRQ, 0, 9))
/*     */         {
/* 364 */           caps |= 1024;
/* 365 */         } else if (BytesTools.byteArrayEquals(capabilities, j * 16, CAP_QIP, 0, 11))
/*     */         {
/* 367 */           caps |= 2048;
/* 368 */         } else if (BytesTools.byteArrayEquals(capabilities, j * 16, CAP_IM2, 0, 16))
/*     */         {
/* 370 */           caps |= 4096;
/* 371 */         } else if (BytesTools.byteArrayEquals(capabilities, j * 16, CAP_MACICQ, 0, 16))
/*     */         {
/* 373 */           caps |= 8192;
/* 374 */         } else if (BytesTools.byteArrayEquals(capabilities, j * 16, CAP_RICHTEXT, 0, 16))
/*     */         {
/* 376 */           caps |= 16384;
/* 377 */         } else if (BytesTools.byteArrayEquals(capabilities, j * 16, CAP_IS2001, 0, 16))
/*     */         {
/* 379 */           caps |= 32768;
/* 380 */         } else if (BytesTools.byteArrayEquals(capabilities, j * 16, CAP_IS2002, 0, 16))
/*     */         {
/* 382 */           caps |= 65536;
/* 383 */         } else if (BytesTools.byteArrayEquals(capabilities, j * 16, CAP_STR20012, 0, 16))
/*     */         {
/* 385 */           caps |= 131072;
/* 386 */         } else if (BytesTools.byteArrayEquals(capabilities, j * 16, CAP_AIMICON, 0, 16))
/*     */         {
/* 388 */           caps |= 262144;
/* 389 */         } else if (BytesTools.byteArrayEquals(capabilities, j * 16, CAP_AIMCHAT, 0, 16))
/*     */         {
/* 391 */           caps |= 524288;
/* 392 */         } else if (BytesTools.byteArrayEquals(capabilities, j * 16, CAP_UIM, 0, 16))
/*     */         {
/* 394 */           caps |= 1048576;
/* 395 */         } else if (BytesTools.byteArrayEquals(capabilities, j * 16, CAP_RAMBLER, 0, 16))
/*     */         {
/* 397 */           caps |= 2097152;
/* 398 */         } else if (BytesTools.byteArrayEquals(capabilities, j * 16, CAP_ABV, 0, 16))
/*     */         {
/* 400 */           caps |= 4194304;
/* 401 */         } else if (BytesTools.byteArrayEquals(capabilities, j * 16, CAP_NETVIGATOR, 0, 16))
/*     */         {
/* 403 */           caps |= 8388608;
/* 404 */         } else if (BytesTools.byteArrayEquals(capabilities, j * 16, CAP_XTRAZ, 0, 16))
/*     */         {
/* 406 */           caps |= 16777216;
/* 407 */         } else if (BytesTools.byteArrayEquals(capabilities, j * 16, CAP_AIMFILE, 0, 16))
/*     */         {
/* 409 */           caps |= 33554432;
/* 410 */         } else if (BytesTools.byteArrayEquals(capabilities, j * 16, CAP_JIMM, 0, 5))
/*     */         {
/* 412 */           caps |= 67108864;
/* 413 */         } else if (BytesTools.byteArrayEquals(capabilities, j * 16, CAP_AIMIMIMAGE, 0, 16))
/*     */         {
/* 415 */           caps |= 134217728;
/* 416 */         } else if (BytesTools.byteArrayEquals(capabilities, j * 16, CAP_AVATAR, 0, 16))
/*     */         {
/* 418 */           caps |= 268435456;
/* 419 */         } else if (BytesTools.byteArrayEquals(capabilities, j * 16, CAP_DIRECT, 0, 16))
/*     */         {
/* 421 */           caps |= 536870912;
/* 422 */         } else if (BytesTools.byteArrayEquals(capabilities, j * 16, CAP_TYPING, 0, 16))
/*     */         {
/* 424 */           caps |= 1073741824; } else {
/* 425 */           if (!BytesTools.byteArrayEquals(capabilities, j * 16, CAP_MCHAT, 0, 9))
/*     */             continue;
/* 427 */           caps |= -2147483648;
/*     */         }
/*     */       }
/*     */ 
/* 431 */       if ((caps & 0x80000000) != 0) {
/* 432 */         client = 39;
/*     */       }
/*     */ 
/* 435 */       if ((caps & 0x4000000) != 0) {
/* 436 */         client = 20;
/*     */       }
/*     */ 
/* 439 */       if ((caps & 0x800) != 0) {
/* 440 */         client = 1;
/* 441 */         if ((dwFP1 >> 24 & 0xFF) != 0) {
/* 442 */           szVersion = szVersion + " (" + (dwFP1 >> 24 & 0xFF) + (dwFP1 >> 16 & 0xFF) + (dwFP1 >> 8 & 0xFF) + (dwFP1 & 0xFF) + ")";
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 447 */       if (((caps & 0x18) != 0) && (dwFP1 == 997567497))
/*     */       {
/* 449 */         client = 4;
/*     */       }
/*     */ 
/* 452 */       if (((caps & 0x1000) != 0) && (dwFP1 == 1072798699)) {
/* 453 */         client = 9;
/*     */       }
/*     */ 
/* 456 */       if ((caps & 0x60) != 0) {
/* 457 */         client = 5;
/*     */       }
/*     */ 
/* 460 */       if ((caps & 0x100) != 0) {
/* 461 */         client = 6;
/*     */       }
/*     */ 
/* 464 */       if ((caps & 0x80) != 0) {
/* 465 */         client = 3;
/*     */       }
/*     */ 
/* 468 */       if (((caps & 0x40000) != 0) && ((caps & 0x2000000) != 0) && ((caps & 0x8000000) != 0))
/*     */       {
/* 470 */         client = 14;
/*     */       }
/*     */ 
/* 473 */       if ((caps & 0x2) != 0) {
/* 474 */         switch (wVersion) {
/*     */         case 10:
/* 476 */           if (((caps & 0x40000000) == 0) || ((caps & 0x4000) == 0))
/*     */             break;
/* 478 */           client = 29;
/*     */         case 7:
/* 481 */           if (((caps & 0x1) != 0) || ((caps & 0x20000000) != 0) || (dwFP1 != 0) || (dwFP2 != 0) || (dwFP3 != 0))
/*     */             break;
/* 484 */           client = 36; break;
/*     */         }
/*     */ 
/* 488 */         if ((dwFP1 == 0) && (dwFP2 == 0) && (dwFP3 == 0)) {
/* 489 */           if ((caps & 0x4000) != 0) {
/* 490 */             client = 30;
/* 491 */             if (((caps & 0x10000000) != 0) && ((caps & 0x1000000) != 0))
/*     */             {
/* 493 */               if ((caps & 0x2000000) != 0)
/* 494 */                 client = 23;
/*     */               else
/* 496 */                 client = 22;
/*     */             }
/* 498 */           } else if ((caps & 0x100000) != 0) {
/* 499 */             client = 12;
/*     */           } else {
/* 501 */             client = 32;
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 507 */       label1317: if ((caps & 0x2000) != 0) {
/* 508 */         client = 10;
/*     */       }
/*     */ 
/* 511 */       if ((caps & 0x80000) != 0) {
/* 512 */         client = 11;
/*     */       }
/*     */ 
/* 515 */       if ((dwFP1 & 0xFF7F0000) == 2097152000) {
/* 516 */         client = 3;
/* 517 */         int ver = dwFP1 & 0xFFFF;
/* 518 */         if (ver % 10 != 0) {
/* 519 */           szVersion = ver / 1000 + "." + ver / 10 % 100 + "." + ver % 10;
/*     */         }
/*     */         else {
/* 522 */           szVersion = ver / 1000 + "." + ver / 10 % 100;
/*     */         }
/*     */       }
/*     */ 
/* 526 */       switch (dwFP1) {
/*     */       case -1:
/* 528 */         if ((dwFP3 == -1) && (dwFP2 == -1)) {
/* 529 */           client = 14;
/*     */         }
/*     */         else {
/* 532 */           if ((dwFP2 == 0) && (dwFP3 != -1)) {
/* 533 */             if (wVersion == 7) {
/* 534 */               client = 13;
/* 535 */               break;
/*     */             }
/* 537 */             if ((dwFP3 == 997345517) && ((caps & 0x2) == 0) && ((caps & 0x4000) == 0))
/*     */             {
/* 540 */               client = 33;
/* 541 */               break;
/*     */             }
/*     */           }
/*     */ 
/* 545 */           client = 2;
/* 546 */           szVersion = (dwFP2 >> 24 & 0x7F) + "." + (dwFP2 >> 16 & 0xFF) + "." + (dwFP2 >> 8 & 0xFF) + "." + (dwFP2 & 0xFF);
/*     */         }
/*     */ 
/* 549 */         break;
/*     */       case -2:
/* 552 */         if (dwFP3 != dwFP1) break;
/* 553 */         client = 20; break;
/*     */       case -113:
/* 557 */         client = 16;
/* 558 */         break;
/*     */       case -190:
/* 560 */         client = 7;
/* 561 */         break;
/*     */       case -66:
/* 563 */         client = 15;
/* 564 */         break;
/*     */       case -129:
/* 566 */         client = 8;
/* 567 */         szVersion = (dwFP2 >> 24 & 0xFF) + "." + (dwFP2 >> 16 & 0xFF) + "." + (dwFP2 >> 8 & 0xFF) + "." + (dwFP2 & 0xFF);
/*     */ 
/* 570 */         break;
/*     */       case -85:
/* 572 */         client = 17;
/* 573 */         break;
/*     */       case 67312000:
/* 575 */         client = 18;
/* 576 */         break;
/*     */       case 984052718:
/* 578 */         if ((dwFP2 != 983982976) || (dwFP3 != 981957186)) break;
/* 579 */         if ((wVersion == 7) && 
/* 580 */           ((caps & 0x1) != 0) && ((caps & 0x20000000) != 0))
/*     */         {
/* 582 */           if ((caps & 0x4000) != 0) {
/* 583 */             client = 34;
/*     */           }
/*     */           else
/* 586 */             client = 35;
/*     */         }
/*     */         else
/* 589 */           client = 19; break;
/*     */       case 997567497:
/* 593 */         client = 4;
/* 594 */         break;
/*     */       case 1000922031:
/* 596 */         if (wVersion != 2) break;
/* 597 */         client = 38; break;
/*     */       case 1072798699:
/* 600 */         if ((wVersion != 8) || (dwFP1 != dwFP3))
/*     */         {
/*     */           break;
/*     */         }
/* 604 */         client = 9; break;
/*     */       case 1107424276:
/* 607 */         if (((dwFP2 & dwFP3) != dwFP1) || (wVersion != 8)) break;
/* 608 */         client = 33;
/*     */       }
/*     */ 
/* 612 */       if ((client != 0) && 
/* 613 */         (dwFP1 != 0) && (dwFP1 == dwFP3) && (dwFP3 == dwFP2) && (caps == 0))
/*     */       {
/* 615 */         client = 18;
/*     */       }
/*     */ 
/* 618 */       if (((caps & 0x1) != 0) && ((caps & 0x20000000) != 0) && ((caps & 0x2) != 0) && ((caps & 0x4000) != 0))
/*     */       {
/* 622 */         if ((dwFP1 != 0) && (dwFP2 != 0) && (dwFP3 != 0))
/* 623 */           client = 27;
/*     */       }
/* 625 */       if (((caps & 0x20001) != 0) && ((caps & 0x8000) != 0))
/*     */       {
/* 627 */         if ((dwFP1 == 0) && (dwFP2 == 0) && (dwFP3 == 0) && (wVersion == 0))
/*     */         {
/* 629 */           client = 37;
/*     */         }
/* 631 */         else client = 26;
/*     */ 
/*     */       }
/*     */ 
/* 635 */       if (wVersion == 7) {
/* 636 */         if (((caps & 0x1) != 0) && ((caps & 0x20000000) != 0))
/*     */         {
/* 638 */           if ((dwFP1 == 0) && (dwFP2 == 0) && (dwFP3 == 0))
/* 639 */             client = 8;
/*     */           else
/* 641 */             client = 28;
/*     */         }
/* 643 */         else if ((caps & 0x4000) != 0) {
/* 644 */           client = 31;
/*     */         }
/*     */       }
/*     */ 
/* 648 */       if ((dwFP1 > 889192448) && (dwFP1 < 1073741824)) {
/* 649 */         switch (wVersion) {
/*     */         case 6:
/* 651 */           client = 25;
/* 652 */           break;
/*     */         case 7:
/* 654 */           client = 28;
/* 655 */           break;
/*     */         case 8:
/* 657 */           client = 26;
/* 658 */           break;
/*     */         case 9:
/* 660 */           client = 30;
/* 661 */           break;
/*     */         case 10:
/* 663 */           client = 29;
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 669 */     return new ClientsEnum(client, caps);
/*     */   }
/*     */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.setting.Capabilities
 * JD-Core Version:    0.6.0
 */