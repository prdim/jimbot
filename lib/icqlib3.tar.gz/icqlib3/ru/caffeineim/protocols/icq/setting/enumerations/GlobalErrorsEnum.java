/*    */ package ru.caffeineim.protocols.icq.setting.enumerations;
/*    */ 
/*    */ public class GlobalErrorsEnum
/*    */ {
/*    */   public static final int INVALID_SNAC = 1;
/*    */   public static final int RATE_TO_HOST = 2;
/*    */   public static final int RATE_TO_CLIENT = 3;
/*    */   public static final int NOT_LOGGED_ON = 4;
/*    */   public static final int SERVICE_UNAVAILABLE = 5;
/*    */   public static final int SERVICE_NOT_DEFINED = 6;
/*    */   public static final int OBSOLETE_SNAC = 7;
/*    */   public static final int NOT_SUPPORTED_BY_HOST = 8;
/*    */   public static final int NOT_SUPPORTED_BY_CLIENT = 9;
/*    */   public static final int REFUSED_BY_CLIENT = 10;
/*    */   public static final int RESPONSES_LOST = 12;
/*    */   public static final int REQUEST_DENIED = 13;
/*    */   public static final int BUSTED_SNAC_PAYLOAD = 14;
/*    */   public static final int INSUFFICIENT_RIGHTS = 15;
/*    */   public static final int IN_LOCAL_PERMIT_DENY = 16;
/*    */   public static final int TOO_EVIL_SENDER = 17;
/*    */   public static final int TOO_EVIL_RECEIVER = 18;
/*    */   public static final int USER_TEMP_UNAVAIL = 19;
/*    */   public static final int NO_MATCH = 20;
/*    */   public static final int LIST_OVERFLOW = 21;
/*    */   public static final int REQUEST_AMBIGOUS = 22;
/*    */   public static final int TIMEOUT = 26;
/*    */   public static final int GENERAL_FAILURE = 28;
/*    */   public static final int RESTRICTED_BY_PC = 31;
/*    */   public static final int REMOTE_RESTRICTED_BY_PC = 32;
/* 51 */   private static EnumerationsMap allerrors = new EnumerationsMap();
/*    */   private int code;
/*    */ 
/*    */   public GlobalErrorsEnum(int code)
/*    */   {
/* 83 */     this.code = code;
/*    */   }
/*    */ 
/*    */   public int getCode() {
/* 87 */     return this.code;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 91 */     if (allerrors.containsKey(getCode())) {
/* 92 */       return (String)allerrors.get(getCode());
/*    */     }
/* 94 */     return "";
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/* 53 */     allerrors.put(1, "Not a known SNAC");
/* 54 */     allerrors.put(2, "Exceed the rate limit to server");
/* 55 */     allerrors.put(3, "Exceed the rate limit to the remote user");
/* 56 */     allerrors.put(4, "Remote user is not logged in");
/* 57 */     allerrors.put(5, "Normally available but something is wrong right now");
/* 58 */     allerrors.put(6, "Requested a service that does not exist");
/* 59 */     allerrors.put(7, "This SNAC is known no longer supported");
/* 60 */     allerrors.put(8, "Unknown SNAC");
/* 61 */     allerrors.put(9, "Remote user is on but does not support the request");
/* 62 */     allerrors.put(10, "Message is bigger then remote client wants");
/* 63 */     allerrors.put(12, "Something really messed up");
/* 64 */     allerrors.put(13, "Server said user or client is not allowed to do this");
/* 65 */     allerrors.put(14, "SNAC is too small or is not in the right format");
/* 66 */     allerrors.put(15, "User or client does not have the correct rights to make the request");
/* 67 */     allerrors.put(16, "User is trying to interact with someone blocked by their own settings");
/* 68 */     allerrors.put(17, "Sender is too evil");
/* 69 */     allerrors.put(18, "Receiver is too evil");
/* 70 */     allerrors.put(19, "User is migrating or the server is down");
/* 71 */     allerrors.put(20, "Item was not found");
/* 72 */     allerrors.put(21, "Too many items were specified in a list");
/* 73 */     allerrors.put(22, "Host could not figure out which item to operate on");
/* 74 */     allerrors.put(26, "Some kind of timeout");
/* 75 */     allerrors.put(28, "General failure");
/* 76 */     allerrors.put(31, "Restricted by parental controls");
/* 77 */     allerrors.put(32, "Remote user is restricted by parental controls");
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.setting.enumerations.GlobalErrorsEnum
 * JD-Core Version:    0.6.0
 */