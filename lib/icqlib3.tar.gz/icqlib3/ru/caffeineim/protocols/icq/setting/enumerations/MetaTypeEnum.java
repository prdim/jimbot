/*    */ package ru.caffeineim.protocols.icq.setting.enumerations;
/*    */ 
/*    */ public class MetaTypeEnum
/*    */ {
/*    */   public static final int CLIENT_REQUEST_OFFLINE_MESSAGES = 60;
/*    */   public static final int CLIENT_ACK_OFFLINE_MESSAGES = 62;
/*    */   public static final int CLIENT_ADVANCED_META = 2000;
/*    */   public static final int SERVER_OFFLINE_MESSAGE = 65;
/*    */   public static final int SERVER_END_OF_OFFLINE_MESSAGES = 66;
/*    */   public static final int SERVER_ADVANCED_META = 2010;
/*    */   private int type;
/*    */ 
/*    */   public MetaTypeEnum(int type)
/*    */   {
/* 34 */     this.type = type;
/*    */   }
/*    */ 
/*    */   public int getType() {
/* 38 */     return this.type;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 42 */     String ret = "";
/* 43 */     switch (this.type) {
/*    */     case 60:
/* 45 */       ret = "Client request offline messages";
/* 46 */       break;
/*    */     case 62:
/* 48 */       ret = "Client ack offline messages";
/* 49 */       break;
/*    */     case 2000:
/* 51 */       ret = "Client advanced meta";
/* 52 */       break;
/*    */     case 65:
/* 54 */       ret = "Server offline message";
/* 55 */       break;
/*    */     case 66:
/* 57 */       ret = "Server end of offline messages";
/* 58 */       break;
/*    */     case 2010:
/* 60 */       ret = "Server advanced meta";
/*    */     }
/*    */ 
/* 64 */     return ret;
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.setting.enumerations.MetaTypeEnum
 * JD-Core Version:    0.6.0
 */