/*    */ package ru.caffeineim.protocols.icq.setting.enumerations;
/*    */ 
/*    */ public class MessageChannelEnum
/*    */ {
/*    */   public static final int MESSAGE_CHANNEL_1 = 1;
/*    */   public static final int MESSAGE_CHANNEL_2 = 2;
/*    */   public static final int MESSAGE_CHANNEL_4 = 4;
/*    */   private int channelNumber;
/*    */ 
/*    */   public MessageChannelEnum(int channelNumber)
/*    */   {
/* 31 */     this.channelNumber = channelNumber;
/*    */   }
/*    */ 
/*    */   public int getChannelNumber() {
/* 35 */     return this.channelNumber;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 39 */     String ret = "";
/* 40 */     switch (this.channelNumber) {
/*    */     case 1:
/* 42 */       ret = "Channel 1";
/* 43 */       break;
/*    */     case 2:
/* 45 */       ret = "Channel 2";
/* 46 */       break;
/*    */     case 4:
/* 48 */       ret = "Channel 4";
/*    */     case 3:
/*    */     }
/*    */ 
/* 52 */     return ret;
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.setting.enumerations.MessageChannelEnum
 * JD-Core Version:    0.6.0
 */