/*     */ package ru.caffeineim.protocols.icq.setting.enumerations;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class OccupationEnum
/*     */ {
/*     */   public static final int UNSPECIFIED = 0;
/*     */   public static final int ACADEMIC = 1;
/*     */   public static final int ADMINISTRATIVE = 2;
/*     */   public static final int ART_ENTERTAIMENT = 3;
/*     */   public static final int COLLEGE_STUDENT = 4;
/*     */   public static final int COMPUTERS = 5;
/*     */   public static final int COMMUNITY = 6;
/*     */   public static final int EDUCATION = 7;
/*     */   public static final int ENGINEERING = 8;
/*     */   public static final int FINANCIAL_SERVICES = 9;
/*     */   public static final int GOVERNMENT = 10;
/*     */   public static final int HIGH_SCHOOL_STUDENT = 11;
/*     */   public static final int HOME = 12;
/*     */   public static final int ICQ_PROVIDING_HELP = 13;
/*     */   public static final int LAW = 14;
/*     */   public static final int MANAGERIAL = 15;
/*     */   public static final int MANUFACTURING = 16;
/*     */   public static final int MEDICAL = 17;
/*     */   public static final int MILITARY = 18;
/*     */   public static final int NON_GOVERNMENT = 19;
/*     */   public static final int PROFESSIONAL = 20;
/*     */   public static final int RETAIL = 21;
/*     */   public static final int RETIRED = 22;
/*     */   public static final int SCIENCE = 23;
/*     */   public static final int SPORTS = 24;
/*     */   public static final int TECHNICAL = 25;
/*     */   public static final int UNIVERSITY_STUDENT = 26;
/*     */   public static final int WEB_BUILDING = 27;
/*     */   public static final int OTHER = 99;
/*  56 */   private static EnumerationsMap allOccupations = new EnumerationsMap();
/*     */   private int occupation;
/*     */ 
/*     */   public OccupationEnum(int occupation)
/*     */   {
/*  92 */     this.occupation = occupation;
/*     */   }
/*     */ 
/*     */   public int getOccupation() {
/*  96 */     return this.occupation;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 100 */     if (allOccupations.containsKey(getOccupation())) {
/* 101 */       return (String)allOccupations.get(getOccupation());
/*     */     }
/*     */ 
/* 104 */     return "";
/*     */   }
/*     */ 
/*     */   public static Map getAllOccupationsMap()
/*     */   {
/* 113 */     return allOccupations;
/*     */   }
/*     */ 
/*     */   public static String[] getAllOccupations()
/*     */   {
/* 121 */     return (String[])(String[])allOccupations.values().toArray(new String[allOccupations.size()]);
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  58 */     allOccupations.put(0, "Unspecified");
/*  59 */     allOccupations.put(1, "Academic");
/*  60 */     allOccupations.put(2, "Administrative");
/*  61 */     allOccupations.put(3, "Art/Entertainment");
/*  62 */     allOccupations.put(4, "College Student");
/*  63 */     allOccupations.put(5, "Computers");
/*  64 */     allOccupations.put(6, "Community & Social");
/*  65 */     allOccupations.put(7, "Education");
/*  66 */     allOccupations.put(8, "Engineering");
/*  67 */     allOccupations.put(9, "Financial Services");
/*  68 */     allOccupations.put(10, "Government");
/*  69 */     allOccupations.put(11, "High School Student");
/*  70 */     allOccupations.put(12, "Home");
/*  71 */     allOccupations.put(13, "ICQ - Providing Help");
/*  72 */     allOccupations.put(14, "Law");
/*  73 */     allOccupations.put(15, "Managerial");
/*  74 */     allOccupations.put(16, "Manufacturing");
/*  75 */     allOccupations.put(17, "Medical/Health");
/*  76 */     allOccupations.put(18, "Military");
/*  77 */     allOccupations.put(19, "Non-Government Organization");
/*  78 */     allOccupations.put(20, "Professional");
/*  79 */     allOccupations.put(21, "Retail");
/*  80 */     allOccupations.put(22, "Retired");
/*  81 */     allOccupations.put(23, "Science & Research");
/*  82 */     allOccupations.put(24, "Sports");
/*  83 */     allOccupations.put(25, "Technical");
/*  84 */     allOccupations.put(26, "University Student");
/*  85 */     allOccupations.put(27, "Web Building");
/*  86 */     allOccupations.put(99, "Other Services");
/*     */   }
/*     */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.setting.enumerations.OccupationEnum
 * JD-Core Version:    0.6.0
 */