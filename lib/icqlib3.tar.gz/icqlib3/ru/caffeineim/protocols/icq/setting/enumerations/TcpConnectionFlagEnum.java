/*    */ package ru.caffeineim.protocols.icq.setting.enumerations;
/*    */ 
/*    */ public class TcpConnectionFlagEnum
/*    */ {
/*    */   public static final int FIREWALL = 1;
/*    */   public static final int SOCKS = 2;
/*    */   public static final int NORMAL = 4;
/*    */   public static final int ICQ2GO = 6;
/*    */   private int tcpConnectionFlag;
/*    */ 
/*    */   public TcpConnectionFlagEnum(int tcpConnectionFlag)
/*    */   {
/* 32 */     this.tcpConnectionFlag = tcpConnectionFlag;
/*    */   }
/*    */ 
/*    */   public int getTcpConnectionFlag() {
/* 36 */     return this.tcpConnectionFlag;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 40 */     String ret = "";
/* 41 */     switch (this.tcpConnectionFlag) {
/*    */     case 1:
/* 43 */       ret = "Firewall";
/* 44 */       break;
/*    */     case 2:
/* 46 */       ret = "Socks";
/* 47 */       break;
/*    */     case 4:
/* 49 */       ret = "Normal";
/* 50 */       break;
/*    */     case 6:
/* 52 */       ret = "ICQ2Go";
/*    */     case 3:
/*    */     case 5:
/*    */     }
/* 56 */     return ret;
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.setting.enumerations.TcpConnectionFlagEnum
 * JD-Core Version:    0.6.0
 */