/*    */ package ru.caffeineim.protocols.icq.setting.enumerations;
/*    */ 
/*    */ public class GenderEnum
/*    */ {
/*    */   public static final int UNKNOWN = 0;
/*    */   public static final int MALE = 2;
/*    */   public static final int FEMALE = 1;
/*    */   private int gender;
/*    */ 
/*    */   public GenderEnum(int gender)
/*    */   {
/* 31 */     this.gender = gender;
/*    */   }
/*    */ 
/*    */   public int getGender() {
/* 35 */     return this.gender;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 39 */     String ret = "";
/* 40 */     switch (this.gender) {
/*    */     case 0:
/* 42 */       ret = "UNKNOWN";
/* 43 */       break;
/*    */     case 2:
/* 45 */       ret = "Male";
/* 46 */       break;
/*    */     case 1:
/* 48 */       ret = "Female";
/*    */     }
/*    */ 
/* 52 */     return ret;
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.setting.enumerations.GenderEnum
 * JD-Core Version:    0.6.0
 */