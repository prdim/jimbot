/*     */ package ru.caffeineim.protocols.icq.setting.enumerations;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class TimeZoneEnum
/*     */ {
/*  26 */   private static EnumerationsMap timezones = new EnumerationsMap();
/*     */   private int timezone;
/*     */ 
/*     */   public TimeZoneEnum(int timezone)
/*     */   {
/*  84 */     this.timezone = timezone;
/*     */   }
/*     */ 
/*     */   public int getTimeZone() {
/*  88 */     return this.timezone;
/*     */   }
/*     */ 
/*     */   public String toString() {
/*  92 */     if (timezones.containsKey(getTimeZone())) {
/*  93 */       return (String)timezones.get(getTimeZone());
/*     */     }
/*     */ 
/*  96 */     return "";
/*     */   }
/*     */ 
/*     */   public static Map getAllTimeZonesMap()
/*     */   {
/* 105 */     return timezones;
/*     */   }
/*     */ 
/*     */   public static String[] getAllTimeZones()
/*     */   {
/* 113 */     return (String[])(String[])timezones.values().toArray(new String[timezones.size()]);
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  29 */     timezones.put(-100, "Unspecified");
/*  30 */     timezones.put(24, "GMT-12:00 Eniwetok; Kwajalein");
/*  31 */     timezones.put(23, "GMT-11:30");
/*  32 */     timezones.put(22, "GMT-11:00 Midway Island; Samoa");
/*  33 */     timezones.put(21, "GMT-10:30");
/*  34 */     timezones.put(20, "GMT-10:00 Hawaii");
/*  35 */     timezones.put(19, "GMT-9:30");
/*  36 */     timezones.put(18, "GMT-9:00 Alaska");
/*  37 */     timezones.put(17, "GMT-8:30");
/*  38 */     timezones.put(16, "GMT-8:00 Pacific Time; Tijuana");
/*  39 */     timezones.put(15, "GMT-7:30");
/*  40 */     timezones.put(14, "GMT-7:00 Arizona; Mountain Time");
/*  41 */     timezones.put(13, "GMT-6:30");
/*  42 */     timezones.put(12, "GMT-6:00 Central Time; Central America; Saskatchewan");
/*  43 */     timezones.put(11, "GMT-5:30");
/*  44 */     timezones.put(10, "GMT-5:00 Eastern Time; Bogota; Lima; Quito");
/*  45 */     timezones.put(9, "GMT-4:30");
/*  46 */     timezones.put(8, "GMT-4:00 Atlantic Time; Santiago; Caracas; La Paz");
/*  47 */     timezones.put(7, "GMT-3:30 Newfoundland");
/*  48 */     timezones.put(6, "GMT-3:00 Greenland; Buenos Aires; Georgetown");
/*  49 */     timezones.put(5, "GMT-2:30");
/*  50 */     timezones.put(4, "GMT-2:00 Mid-Atlantic");
/*  51 */     timezones.put(3, "GMT-1:30");
/*  52 */     timezones.put(2, "GMT-1:00 Cape Verde Islands; Azores");
/*  53 */     timezones.put(1, "GMT-0:30");
/*  54 */     timezones.put(0, "GMT+0:00 London; Dublin; Edinburgh; Lisbon; Casablanca");
/*  55 */     timezones.put(-1, "GMT+0:30");
/*  56 */     timezones.put(-2, "GMT+1:00 Central European Time; West Central Africa; Warsaw");
/*  57 */     timezones.put(-3, "GMT+1:30");
/*  58 */     timezones.put(-4, "GMT+2:00 Jerusalem; Helsinki; Harare; Cairo; Bucharest; Athens");
/*  59 */     timezones.put(-5, "GMT+2:30");
/*  60 */     timezones.put(-6, "GMT+3:00 Moscow; St. Petersburg; Nairobi; Kuwait; Baghdad");
/*  61 */     timezones.put(-7, "GMT+3:30 Tehran");
/*  62 */     timezones.put(-8, "GMT+4:00 Baku; Tbilisi; Yerevan; Abu Dhabi; Muscat");
/*  63 */     timezones.put(-9, "GMT+4:30 Kabul");
/*  64 */     timezones.put(-10, "GMT+5:00 Calcutta; Chennai; Mumbai; New Delhi; Ekaterinburg");
/*  65 */     timezones.put(-11, "GMT+5:30");
/*  66 */     timezones.put(-12, "GMT+6:00 Astana; Dhaka; Almaty; Novosibirsk; Sri Jayawardenepura");
/*  67 */     timezones.put(-13, "GMT+6:30 Rangoon");
/*  68 */     timezones.put(-14, "GMT+7:00 Bankok; Hanoi; Jakarta; Krasnoyarsk");
/*  69 */     timezones.put(-15, "GMT+7:30");
/*  70 */     timezones.put(-16, "GMT+8:00 Perth; Taipei; Singapore; Hong Kong; Beijing");
/*  71 */     timezones.put(-17, "GMT+8:30");
/*  72 */     timezones.put(-18, "GMT+9:00 Tokyo; Osaka; Seoul; Sapporo; Yakutsk");
/*  73 */     timezones.put(-19, "GMT+9:30 Darwin; Adelaide");
/*  74 */     timezones.put(-20, "GMT+10:00 East Australia; Guam; Vladivostok");
/*  75 */     timezones.put(-21, "GMT+10:30");
/*  76 */     timezones.put(-22, "GMT+11:00 Magadan; Solomon Is.; New Caledonia");
/*  77 */     timezones.put(-23, "GMT+11:30");
/*  78 */     timezones.put(-24, "GMT+12:00 Auckland; Wellington; Fiji; Kamchatka; Marshall Is.");
/*     */   }
/*     */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.setting.enumerations.TimeZoneEnum
 * JD-Core Version:    0.6.0
 */