/*     */ package ru.caffeineim.protocols.icq.setting.enumerations;
/*     */ 
/*     */ public class MessageTypeEnum
/*     */ {
/*     */   public static final int PLAIN_MESSAGE = 1;
/*     */   public static final int CHAT_REQUEST = 2;
/*     */   public static final int FILE_REQUEST = 3;
/*     */   public static final int URL = 4;
/*     */   public static final int UNKNOWN = 5;
/*     */   public static final int AUTHORIZATION_REQUEST = 6;
/*     */   public static final int AUTHORIZATION_REJECTED = 7;
/*     */   public static final int AUTHORIZATION_ACCEPTED = 8;
/*     */   public static final int XSTATUS_MESSAGE = 26;
/*     */   public static final int USER_ADDED_YOU = 12;
/*     */   public static final int WEB_PAGER_MESSAGE = 13;
/*     */   public static final int EMAIL_EXPRESS_MESSAGE = 14;
/*     */   public static final int CONTACT_LIST = 19;
/*     */   public static final int REQUEST_AWAY_MESSAGE = 232;
/*     */   public static final int REQUEST_OCCUPIED_MESSAGE = 233;
/*     */   public static final int REQUEST_NA_MESSAGE = 234;
/*     */   public static final int REQUEST_DND_MESSAGE = 235;
/*     */   public static final int REQUEST_FREE_FOR_CHAT_MESSAGE = 236;
/*     */   private int type;
/*     */ 
/*     */   public MessageTypeEnum(int type)
/*     */   {
/*  47 */     this.type = type;
/*     */   }
/*     */ 
/*     */   public int getType() {
/*  51 */     return this.type;
/*     */   }
/*     */ 
/*     */   public String toString() {
/*  55 */     String ret = "";
/*  56 */     switch (this.type) {
/*     */     case 1:
/*  58 */       ret = "Plain message";
/*  59 */       break;
/*     */     case 2:
/*  61 */       ret = "Chat request";
/*  62 */       break;
/*     */     case 3:
/*  64 */       ret = "File request";
/*  65 */       break;
/*     */     case 4:
/*  67 */       ret = "Url";
/*  68 */       break;
/*     */     case 5:
/*  70 */       ret = "Unknown";
/*  71 */       break;
/*     */     case 6:
/*  73 */       ret = "Authorization request";
/*  74 */       break;
/*     */     case 26:
/*  76 */       ret = "XStatus message";
/*  77 */       break;
/*     */     case 7:
/*  79 */       ret = "Authorization rejected";
/*  80 */       break;
/*     */     case 8:
/*  82 */       ret = "Authorization accepted";
/*  83 */       break;
/*     */     case 12:
/*  85 */       ret = "User Added you";
/*  86 */       break;
/*     */     case 13:
/*  88 */       ret = "Web pager message";
/*  89 */       break;
/*     */     case 14:
/*  91 */       ret = "Email express message";
/*  92 */       break;
/*     */     case 19:
/*  94 */       ret = "Contact list";
/*  95 */       break;
/*     */     case 232:
/*  97 */       ret = "Request away message";
/*  98 */       break;
/*     */     case 233:
/* 100 */       ret = "Request occupied message";
/* 101 */       break;
/*     */     case 234:
/* 103 */       ret = "Request NA message";
/* 104 */       break;
/*     */     case 235:
/* 106 */       ret = "Request DND message";
/* 107 */       break;
/*     */     case 236:
/* 109 */       ret = "Request free for chat message";
/*     */     }
/*     */ 
/* 113 */     return ret;
/*     */   }
/*     */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.setting.enumerations.MessageTypeEnum
 * JD-Core Version:    0.6.0
 */