/*    */ package ru.caffeineim.protocols.icq.setting.enumerations;
/*    */ 
/*    */ public class IdleTimeEnum
/*    */ {
/*    */   public static final int START_IDLE_TIME = 60;
/*    */   public static final int STOP_IDLE_TIME = 0;
/*    */   private int idleTimeMode;
/*    */ 
/*    */   public IdleTimeEnum(int idleTimeMode)
/*    */   {
/* 30 */     this.idleTimeMode = idleTimeMode;
/*    */   }
/*    */ 
/*    */   public int getIdleTimeMode() {
/* 34 */     return this.idleTimeMode;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 38 */     String ret = "";
/* 39 */     switch (this.idleTimeMode) {
/*    */     case 60:
/* 41 */       ret = "Idle time started";
/* 42 */       break;
/*    */     case 0:
/* 44 */       ret = "Idle time stopped";
/*    */     }
/*    */ 
/* 48 */     return ret;
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.setting.enumerations.IdleTimeEnum
 * JD-Core Version:    0.6.0
 */