/*    */ package ru.caffeineim.protocols.icq.setting.enumerations;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class PostBackgroundEnum
/*    */ {
/*    */   public static final int UNSPECIFIED = 0;
/*    */   public static final int ELEMENTARY_SCHOOL = 300;
/*    */   public static final int HIGH_SCHOOL = 301;
/*    */   public static final int COLLEGE = 302;
/*    */   public static final int UNIVERSITY = 303;
/*    */   public static final int MILITARY = 304;
/*    */   public static final int PAST_WORK_PLACE = 305;
/*    */   public static final int PAST_ORGANIZATION = 306;
/*    */   public static final int OTHER = 399;
/* 36 */   private static EnumerationsMap allPostbackground = new EnumerationsMap();
/*    */   private int postbackground;
/*    */ 
/*    */   public PostBackgroundEnum(int postbackground)
/*    */   {
/* 52 */     this.postbackground = postbackground;
/*    */   }
/*    */ 
/*    */   public int getPostBackground() {
/* 56 */     return this.postbackground;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 60 */     if (allPostbackground.containsKey(getPostBackground())) {
/* 61 */       return (String)allPostbackground.get(getPostBackground());
/*    */     }
/*    */ 
/* 64 */     return "";
/*    */   }
/*    */ 
/*    */   public static Map getAllPostBackgroundMap()
/*    */   {
/* 73 */     return allPostbackground;
/*    */   }
/*    */ 
/*    */   public static String[] getAllPostBackgrounds()
/*    */   {
/* 81 */     return (String[])(String[])allPostbackground.values().toArray(new String[allPostbackground.size()]);
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/* 38 */     allPostbackground.put(0, "Unspecified");
/* 39 */     allPostbackground.put(300, "Elementary school");
/* 40 */     allPostbackground.put(301, "High school");
/* 41 */     allPostbackground.put(302, "College");
/* 42 */     allPostbackground.put(303, "University");
/* 43 */     allPostbackground.put(304, "Military");
/* 44 */     allPostbackground.put(305, "Past work place");
/* 45 */     allPostbackground.put(306, "Past organization");
/* 46 */     allPostbackground.put(399, "Other");
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.setting.enumerations.PostBackgroundEnum
 * JD-Core Version:    0.6.0
 */