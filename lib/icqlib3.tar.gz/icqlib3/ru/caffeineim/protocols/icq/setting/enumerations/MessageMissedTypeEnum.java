/*    */ package ru.caffeineim.protocols.icq.setting.enumerations;
/*    */ 
/*    */ public class MessageMissedTypeEnum
/*    */ {
/*    */   public static final int MESSAGE_INVALID = 0;
/*    */   public static final int MESSAGE_TOO_LARGE = 1;
/*    */   public static final int MESSAGE_RATE_EXCEEDED = 2;
/*    */   public static final int SENDER_TOO_EVIL = 3;
/*    */   public static final int USER_TOO_EVIL = 4;
/*    */   public static final int UNKNOWN = 5;
/*    */   private int error;
/*    */ 
/*    */   public MessageMissedTypeEnum(int error)
/*    */   {
/* 34 */     this.error = error;
/*    */   }
/*    */ 
/*    */   public int getError() {
/* 38 */     return this.error;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 42 */     switch (this.error) {
/*    */     case 0:
/* 44 */       return "message invalid";
/*    */     case 1:
/* 46 */       return "message too large";
/*    */     case 2:
/* 48 */       return "message rate exceeded";
/*    */     case 3:
/* 50 */       return "sender too evil";
/*    */     case 4:
/* 52 */       return "you are too evil";
/*    */     }
/* 54 */     return "unknown error: " + this.error;
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.setting.enumerations.MessageMissedTypeEnum
 * JD-Core Version:    0.6.0
 */