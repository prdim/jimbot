/*    */ package ru.caffeineim.protocols.icq.setting.enumerations;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class MaritalStatusEnum
/*    */ {
/*    */   public static final int UNSPECIFIED = 0;
/*    */   public static final int SINGLE = 10;
/*    */   public static final int CLOSE_RELATIONSHIPS = 11;
/*    */   public static final int ENGAGED = 12;
/*    */   public static final int MARRIED = 20;
/*    */   public static final int DIVORCED = 30;
/*    */   public static final int SEPARATED = 31;
/*    */   public static final int WIDOWED = 40;
/* 35 */   private static EnumerationsMap allMaritalStatuses = new EnumerationsMap();
/*    */   private int maritalstatus;
/*    */ 
/*    */   public MaritalStatusEnum(int maritalstatus)
/*    */   {
/* 50 */     this.maritalstatus = maritalstatus;
/*    */   }
/*    */ 
/*    */   public int getMaritalStatus() {
/* 54 */     return this.maritalstatus;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 58 */     if (allMaritalStatuses.containsKey(getMaritalStatus())) {
/* 59 */       return (String)allMaritalStatuses.get(getMaritalStatus());
/*    */     }
/*    */ 
/* 62 */     return "";
/*    */   }
/*    */ 
/*    */   public static Map getAllMaritalStatusMap()
/*    */   {
/* 71 */     return allMaritalStatuses;
/*    */   }
/*    */ 
/*    */   public static String[] getAllMaritalStatuses()
/*    */   {
/* 79 */     return (String[])(String[])allMaritalStatuses.values().toArray(new String[allMaritalStatuses.size()]);
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/* 37 */     allMaritalStatuses.put(0, "Unspecified");
/* 38 */     allMaritalStatuses.put(10, "Single");
/* 39 */     allMaritalStatuses.put(11, "Close Relationships");
/* 40 */     allMaritalStatuses.put(12, "Engaged");
/* 41 */     allMaritalStatuses.put(20, "Married");
/* 42 */     allMaritalStatuses.put(30, "Divorced");
/* 43 */     allMaritalStatuses.put(31, "Separated");
/* 44 */     allMaritalStatuses.put(40, "Widowed");
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.setting.enumerations.MaritalStatusEnum
 * JD-Core Version:    0.6.0
 */