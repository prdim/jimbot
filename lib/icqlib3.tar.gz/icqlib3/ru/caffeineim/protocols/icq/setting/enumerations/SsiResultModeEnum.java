/*    */ package ru.caffeineim.protocols.icq.setting.enumerations;
/*    */ 
/*    */ public class SsiResultModeEnum
/*    */ {
/*    */   public static final int NO_ERRORS = 0;
/*    */   public static final int NOT_FOUND_IN_LIST = 2;
/*    */   public static final int ALLREADY_EXISTS = 3;
/*    */   public static final int ERROR_ADDING_ITEM = 10;
/*    */   public static final int LIMIT_OF_ITEMS_EXCEEDED = 12;
/*    */   public static final int TRYING_ADD_ICQ_TO_AIM = 13;
/*    */   public static final int CANT_ADD_BECAUSE_REQUEST_AUTH = 14;
/*    */   private int result;
/*    */ 
/*    */   public SsiResultModeEnum(int result)
/*    */   {
/* 35 */     this.result = result;
/*    */   }
/*    */ 
/*    */   public int getResult() {
/* 39 */     return this.result;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 43 */     String ret = "";
/* 44 */     if (this.result == 0) {
/* 45 */       ret = "No errors (success)";
/*    */     }
/* 47 */     if (this.result == 2) {
/* 48 */       ret = "Item you want to modify not found in list";
/*    */     }
/* 50 */     if (this.result == 3) {
/* 51 */       ret = "Item you want to add allready exists";
/*    */     }
/* 53 */     if (this.result == 10) {
/* 54 */       ret = "Error adding item (invalid id, allready in list, invalid data)";
/*    */     }
/* 56 */     if (this.result == 12) {
/* 57 */       ret = "Can't add item. Limit for this type of items exceeded";
/*    */     }
/* 59 */     if (this.result == 13) {
/* 60 */       ret = "Trying to add ICQ contact to an AIM list";
/*    */     }
/* 62 */     if (this.result == 14) {
/* 63 */       ret = "Can't add this contact because it requires authorization";
/*    */     }
/* 65 */     return ret;
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.setting.enumerations.SsiResultModeEnum
 * JD-Core Version:    0.6.0
 */