/*     */ package ru.caffeineim.protocols.icq.setting.enumerations;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class LanguagesEnum
/*     */ {
/*     */   public static final int NONE = 0;
/*     */   public static final int AFRIKAANS = 55;
/*     */   public static final int ALBANIAN = 58;
/*     */   public static final int ARABIC = 1;
/*     */   public static final int ARMENIAN = 59;
/*     */   public static final int AZERBAIJANI = 68;
/*     */   public static final int BELORUSSIAN = 72;
/*     */   public static final int BHOJPURI = 2;
/*     */   public static final int BOSNIAN = 56;
/*     */   public static final int BULGARIAN = 3;
/*     */   public static final int BURMESE = 4;
/*     */   public static final int CANTONESE = 5;
/*     */   public static final int CATALAN = 6;
/*     */   public static final int CHAMORRO = 61;
/*     */   public static final int CHIMESE = 7;
/*     */   public static final int CROATIAN = 8;
/*     */   public static final int CZECH = 9;
/*     */   public static final int DANISH = 10;
/*     */   public static final int DUTH = 11;
/*     */   public static final int ENGLISH = 12;
/*     */   public static final int ESPERANTO = 13;
/*     */   public static final int ESTONIAN = 14;
/*     */   public static final int FARCI = 15;
/*     */   public static final int FINNISH = 16;
/*     */   public static final int FRENCH = 17;
/*     */   public static final int GAELIC = 18;
/*     */   public static final int GERMAN = 19;
/*     */   public static final int GREEK = 20;
/*     */   public static final int GUJARATI = 70;
/*     */   public static final int HEBREW = 21;
/*     */   public static final int HINDI = 22;
/*     */   public static final int HUNGARIAN = 23;
/*     */   public static final int ICELANDIC = 24;
/*     */   public static final int INDONESIAN = 25;
/*     */   public static final int ITALIAN = 26;
/*     */   public static final int JAPANESE = 27;
/*     */   public static final int KHMER = 28;
/*     */   public static final int KOREAN = 29;
/*     */   public static final int KURDISH = 69;
/*     */   public static final int LAO = 30;
/*     */   public static final int LATVIAN = 31;
/*     */   public static final int LITHUANIAN = 32;
/*     */   public static final int MACEDONIAN = 65;
/*     */   public static final int MALAY = 33;
/*     */   public static final int MANDARIN = 63;
/*     */   public static final int MONGOLIAN = 62;
/*     */   public static final int NORWEGIAN = 34;
/*     */   public static final int PERSIAN = 57;
/*     */   public static final int POLISH = 35;
/*     */   public static final int PORTUGUESE = 36;
/*     */   public static final int PUNJABI = 60;
/*     */   public static final int ROMANIAN = 37;
/*     */   public static final int RUSSIAN = 38;
/*     */   public static final int SERBO_CROATIAN = 39;
/*     */   public static final int SINDHI = 66;
/*     */   public static final int SLOVAK = 40;
/*     */   public static final int SLOVENIAN = 41;
/*     */   public static final int SOMALI = 42;
/*     */   public static final int SPANISH = 43;
/*     */   public static final int SWAHILI = 44;
/*     */   public static final int SWEDISH = 45;
/*     */   public static final int TAGALOG = 46;
/*     */   public static final int TAIWANESS = 64;
/*     */   public static final int TAMIL = 71;
/*     */   public static final int TATAR = 47;
/*     */   public static final int THAI = 48;
/*     */   public static final int TURKISH = 49;
/*     */   public static final int UKRAINIAN = 50;
/*     */   public static final int URDU = 51;
/*     */   public static final int VIETNAMESE = 52;
/*     */   public static final int WELSH = 67;
/*     */   public static final int YIDDISH = 53;
/*     */   public static final int YORUBA = 45;
/* 103 */   private static EnumerationsMap allLanguages = new EnumerationsMap();
/*     */   private int lang;
/*     */ 
/*     */   public LanguagesEnum(int lang)
/*     */   {
/* 183 */     this.lang = lang;
/*     */   }
/*     */ 
/*     */   public int getLanguage() {
/* 187 */     return this.lang;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 191 */     if (allLanguages.containsKey(getLanguage())) {
/* 192 */       return (String)allLanguages.get(getLanguage());
/*     */     }
/* 194 */     return "";
/*     */   }
/*     */ 
/*     */   public static Map getAllLanguagesMap()
/*     */   {
/* 202 */     return allLanguages;
/*     */   }
/*     */ 
/*     */   public static String[] getAllLanguages()
/*     */   {
/* 210 */     List languages = new ArrayList();
/* 211 */     languages.addAll(allLanguages.values());
/* 212 */     Collections.sort(languages);
/*     */ 
/* 214 */     return (String[])(String[])languages.toArray(new String[languages.size()]);
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/* 105 */     allLanguages.put(0, "None");
/* 106 */     allLanguages.put(55, "Afrikaans");
/* 107 */     allLanguages.put(58, "Albanian");
/* 108 */     allLanguages.put(1, "Arabic");
/* 109 */     allLanguages.put(59, "Armenian");
/* 110 */     allLanguages.put(68, "Azerbaijani");
/* 111 */     allLanguages.put(72, "Belorussian");
/* 112 */     allLanguages.put(2, "Bhojpuri");
/* 113 */     allLanguages.put(56, "Bosnian");
/* 114 */     allLanguages.put(3, "Bulgarian");
/* 115 */     allLanguages.put(4, "Burmese");
/* 116 */     allLanguages.put(5, "Cantonese");
/* 117 */     allLanguages.put(6, "Catalan");
/* 118 */     allLanguages.put(61, "Chamorro");
/* 119 */     allLanguages.put(7, "Chinese");
/* 120 */     allLanguages.put(8, "Croatian");
/* 121 */     allLanguages.put(9, "Czech");
/* 122 */     allLanguages.put(10, "Danish");
/* 123 */     allLanguages.put(11, "Dutch");
/* 124 */     allLanguages.put(12, "English");
/* 125 */     allLanguages.put(13, "Esperanto");
/* 126 */     allLanguages.put(14, "Estonian");
/* 127 */     allLanguages.put(15, "Farci");
/* 128 */     allLanguages.put(16, "Finnish");
/* 129 */     allLanguages.put(17, "French");
/* 130 */     allLanguages.put(18, "Gaelic");
/* 131 */     allLanguages.put(19, "German");
/* 132 */     allLanguages.put(20, "Greek");
/* 133 */     allLanguages.put(70, "Gujarati");
/* 134 */     allLanguages.put(21, "Hebrew");
/* 135 */     allLanguages.put(22, "Hindi");
/* 136 */     allLanguages.put(23, "Hungarian");
/* 137 */     allLanguages.put(24, "Icelandic");
/* 138 */     allLanguages.put(25, "Indonesian");
/* 139 */     allLanguages.put(26, "Italian");
/* 140 */     allLanguages.put(27, "Japanese");
/* 141 */     allLanguages.put(28, "Khmer");
/* 142 */     allLanguages.put(29, "Korean");
/* 143 */     allLanguages.put(69, "Kurdish");
/* 144 */     allLanguages.put(30, "Lao");
/* 145 */     allLanguages.put(31, "Latvian");
/* 146 */     allLanguages.put(32, "Lithuanian");
/* 147 */     allLanguages.put(65, "Macedonian");
/* 148 */     allLanguages.put(33, "Malay");
/* 149 */     allLanguages.put(63, "Mandarin");
/* 150 */     allLanguages.put(62, "Mongolian");
/* 151 */     allLanguages.put(34, "Norwegian");
/* 152 */     allLanguages.put(57, "Persian");
/* 153 */     allLanguages.put(35, "Polish");
/* 154 */     allLanguages.put(36, "Portuguese");
/* 155 */     allLanguages.put(60, "Punjabi");
/* 156 */     allLanguages.put(37, "Romanian");
/* 157 */     allLanguages.put(38, "Russian");
/* 158 */     allLanguages.put(39, "Serbo-Croatian");
/* 159 */     allLanguages.put(66, "Sindhi");
/* 160 */     allLanguages.put(40, "Slovak");
/* 161 */     allLanguages.put(41, "Slovenian");
/* 162 */     allLanguages.put(42, "Somali");
/* 163 */     allLanguages.put(43, "Spanish");
/* 164 */     allLanguages.put(44, "Swahili");
/* 165 */     allLanguages.put(45, "Swedish");
/* 166 */     allLanguages.put(46, "Tagalog");
/* 167 */     allLanguages.put(64, "Taiwaness");
/* 168 */     allLanguages.put(71, "Tamil");
/* 169 */     allLanguages.put(47, "Tatar");
/* 170 */     allLanguages.put(48, "Thai");
/* 171 */     allLanguages.put(49, "Turkish");
/* 172 */     allLanguages.put(50, "Ukrainian");
/* 173 */     allLanguages.put(51, "Urdu");
/* 174 */     allLanguages.put(52, "Vietnamese");
/* 175 */     allLanguages.put(67, "Welsh");
/* 176 */     allLanguages.put(53, "Yiddish");
/* 177 */     allLanguages.put(45, "Yoruba");
/*     */   }
/*     */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.setting.enumerations.LanguagesEnum
 * JD-Core Version:    0.6.0
 */