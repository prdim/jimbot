/*    */ package ru.caffeineim.protocols.icq.setting.enumerations;
/*    */ 
/*    */ import java.util.TreeMap;
/*    */ 
/*    */ public class EnumerationsMap extends TreeMap
/*    */ {
/*    */   private static final long serialVersionUID = -3553407280131250204L;
/*    */ 
/*    */   public void put(int key, Object value)
/*    */   {
/* 29 */     super.put(new Integer(key), value);
/*    */   }
/*    */ 
/*    */   public boolean containsKey(int key) {
/* 33 */     return super.containsKey(new Integer(key));
/*    */   }
/*    */ 
/*    */   public Object get(int key) {
/* 37 */     return super.get(new Integer(key));
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.setting.enumerations.EnumerationsMap
 * JD-Core Version:    0.6.0
 */