/*    */ package ru.caffeineim.protocols.icq;
/*    */ 
/*    */ import java.util.Vector;
/*    */ 
/*    */ public abstract class DataContainer extends DataField
/*    */ {
/*    */   private Vector dataFieldVector;
/*    */   private byte[] dataFieldByteAray;
/*    */   private int dataFieldLen;
/*    */   private boolean dataFieldModified;
/*    */   protected boolean headerModified;
/*    */ 
/*    */   public DataContainer()
/*    */   {
/* 33 */     this.dataFieldVector = new Vector(0);
/* 34 */     this.dataFieldLen = 0;
/* 35 */     this.dataFieldModified = true;
/* 36 */     this.headerModified = true;
/*    */   }
/*    */   public abstract byte[] getHeaderByteArray();
/*    */ 
/*    */   public void addDataField(DataField data) {
/* 42 */     this.dataFieldVector.addElement(data);
/* 43 */     this.dataFieldLen += data.getByteArray().length;
/* 44 */     this.dataFieldModified = true;
/*    */   }
/*    */ 
/*    */   protected Object elementAt(int i) {
/* 48 */     return this.dataFieldVector.elementAt(i);
/*    */   }
/*    */ 
/*    */   public byte[] getDataFieldByteArray() {
/* 52 */     if (this.dataFieldModified) {
/* 53 */       int position = 0;
/* 54 */       this.dataFieldByteAray = new byte[this.dataFieldLen];
/*    */ 
/* 56 */       for (int i = 0; i < this.dataFieldVector.size(); i++) {
/* 57 */         DataField obj = (DataField)this.dataFieldVector.elementAt(i);
/* 58 */         System.arraycopy(obj.getByteArray(), 0, this.dataFieldByteAray, position, obj.getByteArray().length);
/*    */ 
/* 60 */         position += obj.getByteArray().length;
/*    */       }
/* 62 */       this.dataFieldModified = false;
/*    */     }
/*    */ 
/* 65 */     return this.dataFieldByteAray;
/*    */   }
/*    */ 
/*    */   public byte[] getByteArray() {
/* 69 */     if ((this.headerModified) || (this.dataFieldModified)) {
/* 70 */       this.byteArray = new byte[getHeaderByteArray().length + this.dataFieldLen];
/*    */ 
/* 72 */       System.arraycopy(getHeaderByteArray(), 0, this.byteArray, 0, getHeaderByteArray().length);
/*    */ 
/* 75 */       System.arraycopy(getDataFieldByteArray(), 0, this.byteArray, getHeaderByteArray().length, getDataFieldByteArray().length);
/*    */ 
/* 78 */       this.headerModified = false;
/*    */     }
/*    */ 
/* 81 */     return this.byteArray;
/*    */   }
/*    */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.DataContainer
 * JD-Core Version:    0.6.0
 */