/*     */ package ru.caffeineim.protocols.icq;
/*     */ 
/*     */ public class Tlv extends DataContainer
/*     */ {
/*     */   private static final int TLV_HEADER_SIZE = 4;
/*     */   private RawData type;
/*     */   private RawData length;
/*     */   private byte[] headerByteArray;
/*     */ 
/*     */   public Tlv(int type)
/*     */   {
/*  37 */     this.headerByteArray = new byte[4];
/*     */ 
/*  39 */     this.type = new RawData(type, 2);
/*     */   }
/*     */ 
/*     */   public Tlv(RawData value, int tlvType) {
/*  43 */     this(tlvType);
/*     */ 
/*  45 */     appendRawDataToTlv(value);
/*     */   }
/*     */ 
/*     */   public Tlv(Tlv value, int tlvType) {
/*  49 */     this(tlvType);
/*     */ 
/*  51 */     appendTlvToTlv(value);
/*     */   }
/*     */ 
/*     */   public Tlv(String string, int tlvType)
/*     */   {
/*  61 */     this(new RawData(string), tlvType);
/*     */   }
/*     */ 
/*     */   public Tlv(int val, int tlvType)
/*     */   {
/*  71 */     this(new RawData(val), tlvType);
/*     */   }
/*     */ 
/*     */   public Tlv(int val, int forcedLenght, int tlvType)
/*     */   {
/*  81 */     this(new RawData(val, forcedLenght), tlvType);
/*     */   }
/*     */ 
/*     */   public Tlv(byte[] array, int start) {
/*  85 */     this.headerByteArray = new byte[4];
/*  86 */     this.headerModified = true;
/*  87 */     byte[] typeArray = new byte[2];
/*  88 */     byte[] lengthArray = new byte[2];
/*     */ 
/*  91 */     System.arraycopy(array, start, typeArray, 0, 2);
/*  92 */     this.type = new RawData(typeArray);
/*  93 */     System.arraycopy(array, start + 2, lengthArray, 0, 2);
/*  94 */     this.length = new RawData(lengthArray);
/*  95 */     byte[] valueArray = new byte[getLength()];
/*  96 */     System.arraycopy(array, start + 4, valueArray, 0, getLength());
/*  97 */     appendRawDataToTlv(new RawData(valueArray));
/*     */   }
/*     */ 
/*     */   public void appendRawDataToTlv(RawData data) {
/* 101 */     addDataField(data);
/*     */   }
/*     */ 
/*     */   public void appendTlvToTlv(Tlv tlv) {
/* 105 */     addDataField(tlv);
/*     */   }
/*     */ 
/*     */   public byte[] getHeaderByteArray() {
/* 109 */     if (this.headerModified)
/*     */     {
/* 111 */       this.length = new RawData(getDataFieldByteArray().length, 2);
/*     */ 
/* 113 */       System.arraycopy(this.type.getByteArray(), 0, this.headerByteArray, 0, this.type.getByteArray().length);
/*     */ 
/* 116 */       System.arraycopy(this.length.getByteArray(), 0, this.headerByteArray, 2, this.length.getByteArray().length);
/*     */ 
/* 118 */       this.headerModified = false;
/*     */     }
/*     */ 
/* 121 */     return this.headerByteArray;
/*     */   }
/*     */ 
/*     */   public int getType()
/*     */   {
/* 128 */     return this.type.getValue();
/*     */   }
/*     */ 
/*     */   public int getLength()
/*     */   {
/* 135 */     return this.length.getValue();
/*     */   }
/*     */ 
/*     */   public int getValue()
/*     */   {
/* 142 */     return ((RawData)elementAt(0)).getValue();
/*     */   }
/*     */ 
/*     */   public String getStringValue()
/*     */   {
/* 149 */     return ((RawData)elementAt(0)).getStringValue();
/*     */   }
/*     */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.Tlv
 * JD-Core Version:    0.6.0
 */