/*     */ package ru.caffeineim.protocols.icq;
/*     */ 
/*     */ import ru.caffeineim.protocols.icq.exceptions.RawDataBadForcedLenghtException;
/*     */ 
/*     */ public class RawData extends DataField
/*     */ {
/*     */   public static final int BYTE_LENGHT = 1;
/*     */   public static final int WORD_LENGHT = 2;
/*     */   public static final int DWORD_LENGHT = 4;
/*     */   private int value;
/*  36 */   private int forcedLenght = 0;
/*  37 */   private String stringValue = null;
/*  38 */   private boolean reversed = false;
/*     */ 
/*     */   public RawData(int value, int forcedLenght)
/*     */   {
/*  48 */     this.value = value;
/*  49 */     this.forcedLenght = forcedLenght;
/*     */ 
/*  51 */     long maxValue = 0L;
/*  52 */     for (int i = 0; i < forcedLenght; i++) {
/*  53 */       maxValue = maxValue << 8 | 0xFF;
/*     */     }
/*  55 */     if (value <= maxValue)
/*  56 */       insert(value, forcedLenght);
/*     */     else
/*  58 */       throw new RawDataBadForcedLenghtException(value + " cannot fit in " + forcedLenght + " Byte(s).");
/*     */   }
/*     */ 
/*     */   public RawData(int value)
/*     */   {
/*  69 */     this.value = value;
/*     */ 
/*  71 */     long maxValue = 255L;
/*  72 */     int i = 1;
/*  73 */     while (maxValue < value) {
/*  74 */       maxValue = maxValue << 8 | 0xFF;
/*  75 */       i++;
/*     */     }
/*  77 */     insert(value, i);
/*     */   }
/*     */ 
/*     */   public RawData(String string)
/*     */   {
/*  86 */     this.stringValue = string;
/*  87 */     insertString(string);
/*     */   }
/*     */ 
/*     */   public RawData(byte[] array) {
/*  91 */     this.byteArray = array;
/*  92 */     this.value = getByte(array);
/*  93 */     this.stringValue = new String(this.byteArray);
/*     */   }
/*     */ 
/*     */   public RawData(byte[] value, int start, int len) {
/*  97 */     byte[] tmp = new byte[len];
/*  98 */     System.arraycopy(value, start, tmp, 0, len);
/*     */ 
/* 100 */     this.byteArray = tmp;
/* 101 */     this.value = getByte(tmp);
/* 102 */     this.stringValue = new String(tmp);
/*     */   }
/*     */ 
/*     */   private static int getByte(byte[] array) {
/* 106 */     int result = 0;
/* 107 */     for (int i = 0; i < array.length; i++) {
/* 108 */       long shift = (array.length - (i + 1)) * 8;
/* 109 */       long mask = 255 << (int)shift;
/* 110 */       result = (int)(result | array[i] << (int)shift & mask);
/*     */     }
/* 112 */     return result;
/*     */   }
/*     */ 
/*     */   private void insert(int value, int len) {
/* 116 */     this.byteArray = new byte[len];
/* 117 */     for (int i = 0; i < len; i++)
/* 118 */       this.byteArray[i] = (byte)(value >> (len - 1 - i) * 8 & 0xFF);
/*     */   }
/*     */ 
/*     */   private void insertString(String string)
/*     */   {
/* 123 */     this.byteArray = new byte[string.length()];
/* 124 */     for (int i = 0; i < string.length(); i++)
/* 125 */       this.byteArray[i] = (byte)string.charAt(i);
/*     */   }
/*     */ 
/*     */   public void invertIndianness()
/*     */   {
/* 130 */     byte[] tmp = new byte[this.byteArray.length];
/* 131 */     for (int i = 0; i < this.byteArray.length; i++) {
/* 132 */       tmp[i] = this.byteArray[(this.byteArray.length - 1 - i)];
/*     */     }
/* 134 */     this.byteArray = tmp;
/* 135 */     this.reversed = true;
/*     */   }
/*     */ 
/*     */   public int getValue()
/*     */   {
/* 143 */     if (this.reversed) {
/* 144 */       this.value = 0;
/* 145 */       for (int i = 0; i < this.byteArray.length; i++) {
/* 146 */         this.value = (int)(this.value | this.byteArray[i] << (this.byteArray.length - 1 - i) * 8 & 255L << (this.byteArray.length - 1 - i) * 8);
/*     */       }
/*     */ 
/* 149 */       this.reversed = false;
/*     */     }
/*     */ 
/* 152 */     return this.value;
/*     */   }
/*     */ 
/*     */   public int getForcedLenght()
/*     */   {
/* 160 */     return this.forcedLenght;
/*     */   }
/*     */ 
/*     */   public String getStringValue()
/*     */   {
/* 168 */     if ((this.stringValue == null) || (this.reversed == true)) {
/* 169 */       this.stringValue = new String(this.byteArray);
/*     */     }
/* 171 */     this.reversed = false;
/*     */ 
/* 173 */     return this.stringValue;
/*     */   }
/*     */ 
/*     */   public String toStringValue()
/*     */   {
/* 181 */     return String.valueOf(getValue());
/*     */   }
/*     */ 
/*     */   public byte[] getByteArray()
/*     */   {
/* 189 */     return this.byteArray;
/*     */   }
/*     */ }

/* Location:           /windows/jim bot/Black_Kot/0.4.0 sqllite/lib/icqlib3.jar
 * Qualified Name:     ru.caffeineim.protocols.icq.RawData
 * JD-Core Version:    0.6.0
 */